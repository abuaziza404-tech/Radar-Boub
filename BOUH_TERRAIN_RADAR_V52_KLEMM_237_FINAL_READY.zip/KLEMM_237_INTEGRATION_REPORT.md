# BOUH V52 Klemm 237 Integration

- Base preserved: V52 Field Core.
- Added: Klemm KCL reference layer with 237 sites.
- Files added:
  - apps/web/public/data/klemm_sites_237.json
  - apps/web/public/data/klemm_sites_237.csv
- UI added: Klemm button, filter buttons, nearest Klemm site report.
- Status: historical/reference KCL layer, not raw spectral pixel proof.
