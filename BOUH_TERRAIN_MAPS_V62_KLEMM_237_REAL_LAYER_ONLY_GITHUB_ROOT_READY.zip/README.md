# BOUH Terrain Maps V62 — Klemm 237 Real Layer Only

- Maps-only application.
- Radar/score/heavy target cells removed from UI.
- Contains only the real Klemm 237 layer supplied by `klemm_sites_237.json` and `klemm_sites_237.csv`.
- No fabricated/public-memory sites added.
- Embedded KML reference: `reference/klemm_sudan_gold_sites_organized_important.kml`.
- Dataset status: historical/reference KCL layer, not raw spectral pixel proof.

Validation:
- JSON sites: 237
- CSV rows: 237
