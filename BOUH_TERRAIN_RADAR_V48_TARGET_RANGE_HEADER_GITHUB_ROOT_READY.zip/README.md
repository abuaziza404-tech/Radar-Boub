# بوح التضاريس V48 Live Field Refined

هذه الحزمة جاهزة للرفع إلى GitHub Actions وبناء APK مباشرة.

## أهم تطويرات V48
- رفع الإصدار الداخلي إلى `versionCode 44` و `versionName 45.0.0-alpine-command-interface`.
- تثبيت اسم التطبيق الظاهر بعد التثبيت: **بوح التضاريس**.
- تحديث GitHub Actions ليبحث عن حزمة V48 فقط ويعرض اسم V48 في صفحة Actions.
- إضافة فحص جاهزية الميدان V48:
  - GPS
  - قاعدة البيانات
  - الإنترنت / Offline
  - الأهداف المحفوظة
  - نقاط المسار
  - حالة التصدير
- إضافة خطة مهمة ذكية V48 ترتب الأهداف حسب الدرجة ثم القرب.
- إضافة خريطة حرارية Heatmap للنتائج من قاعدة الخلايا.
- إضافة تقرير HTML احترافي قابل للمشاركة بجانب JSON/CSV/KML/GPX/GeoJSON.
- تحسين رسائل الواجهة لتعرض V48 Live Field Refined.
- الحفاظ على بنية WebView + Android Bridge الحالية لتثبيت التطوير بسرعة دون كسر النظام.

## طريقة الرفع إلى GitHub
1. ارفع هذا الملف في جذر المستودع:
   `BOUH_TERRAIN_RADAR_V48_PRO_FIELD_INTELLIGENCE_GITHUB_ROOT_READY.zip`
2. أنشئ الملف:
   `.github/workflows/build-apk.yml`
3. استخدم ملف workflow الموجود داخل الحزمة أو انسخ محتواه من `.github/workflows/build-apk.yml`.
4. ادخل تبويب Actions وشغل:
   `Build BOUH Terrain Radar V48 APK`

## ملاحظة
`applicationId` بقي كما هو `com.bouh.terrainradar.v41` حتى يمكن تثبيت V48 كتحديث فوق النسخ السابقة. الاسم الظاهر للمستخدم هو **بوح التضاريس**.

## V48 Live Field Refined
- تطبيق الواجهة المطلوبة بصرياً: بطاقة إحداثيات علوية، شريحة هوية بوح التضاريس، رادار ثلاثي الحلقات، ملخص رادار دائم، وشريط أوامر سفلي عربي.
- تحديث حي للـ Score / Structure / Alteration / FeOx / Drainage من قاعدة البيانات.
- HUD ميداني: UTM تقريبي، ارتفاع، دقة GPS، وحالة Online/Offline.
- الإبقاء على أنظمة الأهداف والمسارات والتصدير والتقارير وHeatmap وKML/GPX/CSV/GeoJSON/HTML.


## V48 Live Field Refined
- Compact coordinate header and raised placement.
- Smaller radar summary with live score/meta updates while moving the map.
- Polished footer with developer signature.
- Security and field readiness notes added in docs/V48_LIVE_FIELD_REFINED_SECURITY.md.


## V48 Target Range Header
- عرض النطاق المستهدف داخل بطاقة الإحداثيات العلوية.
- إزاحة شريحة اسم التطبيق عن الإحداثيات.
- تقليل حجم عناصر الواجهة وتحسين ترتيبها.
