# قواعد قرار بوح داخل التطبيق

1. Structure → Pattern → Alteration → Confirmation → Decision.
2. لا FeOx-only كهدف قوي.
3. لا Target-B ولا ذهب مؤكد بدون GPZ/recovered gold/assay.
4. KCL/Klemm مرجع فقط وليس إثبات ذهب.
5. خرائط Esri/Hybrid/Streets للعرض والملاحة وليست مصدر بكسلات طيفية.
6. إذا كانت النقطة بعيدة عن أقرب خلية متاحة تظهر Outside Coverage/HOLD.
7. لا Math.random ولا نتائج عشوائية.
