# BOUH Terrain Radar V26 Ahmed Pro
## بوح التضاريس V26 | المطور أحمد أبوعزيزه الرشيدي

حزمة Android جاهزة للرفع إلى GitHub Actions.

## أهم التحديثات
- خريطة GPS حقيقية داخل التطبيق باستخدام osmdroid.
- طبقات خرائط:
  - Streets
  - Hybrid map
  - Esri Satellite
- دبوس رادار متحرك:
  - اضغط على الخريطة أو اسحب الدبوس.
  - عند توقف الدبوس يتم تحليل أقرب خلية/هدف من قواعد SQLite المحلية.
- قواعد بيانات محلية:
  - BOUH_V21_CENTER_MOBILE.db
  - BOUH_V21_NORTH_MOBILE.db
  - BOUH_V21_SOUTH_MOBILE.db
- مساعد نظام عربي:
  - يرد محلياً.
  - يفهم أسئلة الإحداثيات، GPZ، FeOx، الطبقات، Target-B، وطريقة عمل الرادار.
  - صفحة إعدادات لربط API اختياري لاحقاً.
- أيقونة جديدة وهوية بوح ذهبية/داكنة.
- Workflow يبني APK تلقائياً.

## قاعدة الصدق
التطبيق لا يقول "ذهب مؤكد" ولا يرفع Target-B بدون GPZ/recovered gold/assay.  
التحليل من أقرب خلية/هدف داخل قاعدة البيانات، وليس من لون الخريطة.

## طريقة الرفع
ارفع محتوى ZIP مفكوكاً إلى جذر المستودع بحيث تظهر:
- settings.gradle
- build.gradle
- app/
- .github/
- README.md

ثم:
Actions → Build BOUH Terrain Radar V26 Ahmed Pro APK → Run workflow

## استبدال قواعد البيانات
ضع قواعدك الكاملة بنفس الأسماء داخل:
app/src/main/assets/databases/

ويجب أن تحتوي جدول targets أو عدّل MainActivity لقراءة جدولك الحقيقي.
