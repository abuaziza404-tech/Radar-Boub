package com.bouh.terrainradar;

import android.Manifest;
import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.Typeface;
import android.location.*;
import android.text.method.ScrollingMovementMethod;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.io.*;
import java.util.*;
import org.osmdroid.config.Configuration;
import org.osmdroid.tileprovider.tilesource.*;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.*;
import org.osmdroid.views.overlay.*;
import org.osmdroid.views.overlay.mylocation.*;

public class MainActivity extends Activity {
    int bg=Color.rgb(5,8,13), card=Color.rgb(17,25,38), gold=Color.rgb(184,135,45), gold2=Color.rgb(245,194,92);
    int green=Color.rgb(102,187,106), orange=Color.rgb(255,183,77), red=Color.rgb(239,83,80), text=Color.WHITE;
    LinearLayout root, panel, nav;
    TextView header, status, resultBox, chatLog;
    Button bMap,bRadar,bChat,bSettings,bStreets,bHybrid,bEsri,bMyLoc,bAnalyze,bSend,bSave,bArbaat;
    EditText latInput, lonInput, chatInput, endpointInput, keyInput, modelInput;
    MapView map;
    Marker pin;
    MyLocationNewOverlay myLocationOverlay;
    SharedPreferences prefs;
    ArrayList<Target> allTargets = new ArrayList<>();
    String currentLayer = "Esri Satellite";
    TileSourceFactory tileFactory;

    static class Target {
        String id, region, classification, model, indicators, source;
        double lat, lon; int score;
    }
    static class Hit {
        Target t; double meters; boolean inside;
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs=getSharedPreferences("bouh_v26", MODE_PRIVATE);
        Configuration.getInstance().setUserAgentValue(getPackageName());
        if(Build.VERSION.SDK_INT>=23) requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 10);
        loadDatabases();
        showMap();
    }

    TextView tv(String s, int sp, int color, int style) {
        TextView v=new TextView(this);
        v.setText(s); v.setTextSize(sp); v.setTextColor(color); v.setTypeface(Typeface.DEFAULT, style);
        v.setGravity(Gravity.RIGHT); v.setTextDirection(View.TEXT_DIRECTION_RTL); v.setPadding(12,8,12,8);
        return v;
    }
    Button btn(String s) {
        Button b=new Button(this); b.setText(s); b.setAllCaps(false); b.setTextColor(Color.WHITE); b.setTextSize(13);
        b.setBackgroundColor(Color.rgb(86,62,21)); return b;
    }
    EditText input(String h) {
        EditText e=new EditText(this); e.setHint(h); e.setHintTextColor(Color.rgb(155,165,180)); e.setTextColor(Color.WHITE);
        e.setGravity(Gravity.RIGHT); e.setTextDirection(View.TEXT_DIRECTION_RTL); e.setBackgroundColor(Color.rgb(24,36,54)); e.setPadding(12,8,12,8);
        return e;
    }
    LinearLayout card() {
        LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(14,14,14,14); l.setBackgroundColor(card);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.setMargins(8,8,8,8); l.setLayoutParams(lp); return l;
    }
    void frame(String title) {
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(bg); root.setPadding(6,6,6,6);
        header=tv("بوح التضاريس V26 | " + title + "\nالمطور: أحمد أبوعزيزه الرشيدي", 17, gold2, Typeface.BOLD);
        header.setGravity(Gravity.CENTER); root.addView(header, new LinearLayout.LayoutParams(-1,-2));
        nav=new LinearLayout(this); nav.setOrientation(LinearLayout.HORIZONTAL);
        bMap=btn("الخريطة"); bRadar=btn("الرادار"); bChat=btn("المساعد"); bSettings=btn("الإعدادات");
        nav.addView(bMap); nav.addView(bRadar); nav.addView(bChat); nav.addView(bSettings); root.addView(nav, new LinearLayout.LayoutParams(-1,-2));
        setContentView(root);
        bMap.setOnClickListener(v->showMap()); bRadar.setOnClickListener(v->showRadar()); bChat.setOnClickListener(v->showChat()); bSettings.setOnClickListener(v->showSettings());
    }

    void showMap() {
        frame("خرائط GPS ورادار الدبوس");
        map=new MapView(this); map.setMultiTouchControls(true); map.setBuiltInZoomControls(false);
        map.getController().setZoom(11.5); map.getController().setCenter(new GeoPoint(19.88,36.74));
        root.addView(map, new LinearLayout.LayoutParams(-1,0,1));

        panel=new LinearLayout(this); panel.setOrientation(LinearLayout.VERTICAL); panel.setBackgroundColor(Color.rgb(10,16,25)); panel.setPadding(6,6,6,6);
        LinearLayout row1=new LinearLayout(this); row1.setOrientation(LinearLayout.HORIZONTAL);
        bStreets=btn("Streets"); bHybrid=btn("Hybrid map"); bEsri=btn("Esri Satellite"); bMyLoc=btn("GPS"); bArbaat=btn("أربعات");
        row1.addView(bStreets); row1.addView(bHybrid); row1.addView(bEsri); row1.addView(bMyLoc); row1.addView(bArbaat);
        panel.addView(row1);
        status=tv("حرّك الدبوس أو اضغط على الخريطة لتحليل أقرب خلية/هدف من قاعدة بيانات بوح.",14,Color.WHITE,Typeface.NORMAL);
        status.setTextIsSelectable(true); panel.addView(status);
        root.addView(panel,new LinearLayout.LayoutParams(-1,-2));

        setupMapLayer("Esri Satellite");
        setupPin(new GeoPoint(19.973186,36.745590));
        addTargetMarkers();

        MapEventsOverlay events = new MapEventsOverlay(new MapEventsReceiver() {
            public boolean singleTapConfirmedHelper(GeoPoint p) { movePinAndAnalyze(p); return true; }
            public boolean longPressHelper(GeoPoint p) { movePinAndAnalyze(p); return true; }
        });
        map.getOverlays().add(events);

        bStreets.setOnClickListener(v->setupMapLayer("Streets"));
        bHybrid.setOnClickListener(v->setupMapLayer("Hybrid map"));
        bEsri.setOnClickListener(v->setupMapLayer("Esri Satellite"));
        bArbaat.setOnClickListener(v->{ GeoPoint p=new GeoPoint(19.973186,36.745590); map.getController().animateTo(p); map.getController().setZoom(14.0); movePinAndAnalyze(p); });
        bMyLoc.setOnClickListener(v->goMyLocation());
        analyzePoint(pin.getPosition());
    }

    void setupMapLayer(String layer) {
        currentLayer=layer;
        if(layer.equals("Esri Satellite")) {
            XYTileSource esri = new XYTileSource("Esri Satellite", 0, 19, 256, ".jpg",
                new String[]{"https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/"});
            map.setTileSource(esri);
        } else if(layer.equals("Hybrid map")) {
            // Hybrid practical mode: OSM-based roads/labels with satellite-ready control; replace with local MBTiles or premium provider if available.
            map.setTileSource(TileSourceFactory.MAPNIK);
        } else {
            map.setTileSource(TileSourceFactory.MAPNIK);
        }
        if(status!=null) status.setText("طبقة الخريطة الحالية: " + currentLayer + " | التحليل مستقل عن لون الخريطة ويقرأ من قاعدة البيانات المحلية.");
        map.invalidate();
    }

    void setupPin(GeoPoint p) {
        pin=new Marker(map);
        pin.setPosition(p);
        pin.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM);
        pin.setTitle("دبوس رادار بوح");
        pin.setSnippet("اسحبني لتحليل الأرض");
        pin.setDraggable(true);
        pin.setOnMarkerDragListener(new Marker.OnMarkerDragListener() {
            public void onMarkerDrag(Marker marker) { status.setText("الدبوس يتحرك: " + fmt(marker.getPosition().getLatitude()) + ", " + fmt(marker.getPosition().getLongitude())); }
            public void onMarkerDragEnd(Marker marker) { analyzePoint(marker.getPosition()); }
            public void onMarkerDragStart(Marker marker) {}
        });
        map.getOverlays().add(pin);
    }

    void addTargetMarkers() {
        for(Target t: allTargets) {
            Marker m=new Marker(map);
            m.setPosition(new GeoPoint(t.lat,t.lon));
            m.setTitle(t.id);
            m.setSnippet(t.classification + " | " + t.score + " | " + t.model);
            m.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM);
            map.getOverlays().add(m);
        }
    }

    void movePinAndAnalyze(GeoPoint p) {
        pin.setPosition(p); map.getController().animateTo(p); analyzePoint(p); map.invalidate();
    }

    void goMyLocation() {
        try {
            LocationManager lm=(LocationManager)getSystemService(LOCATION_SERVICE);
            if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION},10); return;
            }
            Location loc=lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if(loc==null) loc=lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            if(loc!=null) {
                GeoPoint p=new GeoPoint(loc.getLatitude(), loc.getLongitude());
                map.getController().setZoom(15.0); movePinAndAnalyze(p);
            } else status.setText("لم أجد موقع GPS حالياً. فعّل الموقع وانتظر ثواني ثم اضغط GPS.");
        } catch(Exception e) { status.setText("تعذر قراءة GPS: " + e.getMessage()); }
    }

    void showRadar() {
        frame("تحليل الإحداثيات");
        ScrollView sv=new ScrollView(this); LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); sv.addView(c); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout box=card();
        latInput=input("Latitude مثال 19.973186");
        lonInput=input("Longitude مثال 36.745590");
        bAnalyze=btn("حلل الإحداثية من قاعدة بيانات بوح");
        resultBox=tv("أدخل الإحداثية ثم اضغط التحليل.",15,Color.WHITE,Typeface.NORMAL); resultBox.setTextIsSelectable(true);
        box.addView(latInput); box.addView(lonInput); box.addView(bAnalyze); box.addView(resultBox); c.addView(box);
        bAnalyze.setOnClickListener(v->{
            double lat=parse(latInput.getText().toString(),999);
            double lon=parse(lonInput.getText().toString(),999);
            if(lat==999||lon==999) { resultBox.setText("الإحداثيات غير صحيحة."); return; }
            resultBox.setText(buildDecisionText(new GeoPoint(lat,lon)));
        });
    }

    void showChat() {
        frame("مساعد نظام بوح");
        ScrollView sv=new ScrollView(this); LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); sv.addView(c); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout box=card();
        chatLog=tv("المساعد: جاهز. اسألني عن الرادار، الطبقات، المؤشرات، GPZ، أو نتيجة إحداثية.\n",15,Color.WHITE,Typeface.NORMAL);
        chatLog.setMovementMethod(new ScrollingMovementMethod()); chatLog.setTextIsSelectable(true);
        chatInput=input("اكتب سؤالك هنا...");
        bSend=btn("إرسال");
        box.addView(chatLog); box.addView(chatInput); box.addView(bSend); c.addView(box);
        bSend.setOnClickListener(v->sendChat());
    }

    void sendChat() {
        String q=chatInput.getText().toString().trim();
        if(q.length()==0) return;
        String a=assistantReply(q);
        chatLog.append("\nأنت: " + q + "\nالمساعد: " + a + "\n");
        chatInput.setText("");
        try { ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(chatInput.getWindowToken(),0); } catch(Exception e){}
    }

    String assistantReply(String q) {
        String x=q.toLowerCase(Locale.ROOT);
        if(x.contains("احداث")||x.contains("إحداث")||x.contains("lat")||x.contains("lon")) {
            double[] ll=extractLatLon(x);
            if(ll!=null) return buildDecisionText(new GeoPoint(ll[0],ll[1]));
            return "اكتب الإحداثية بصيغة: 19.973186, 36.745590 وسأحللها من أقرب خلية/هدف داخل قاعدة بوح.";
        }
        if(x.contains("طبقة")||x.contains("خريطة")||x.contains("esri")||x.contains("hybrid")) {
            return "الخرائط ثلاث طبقات: Streets للطرق، Hybrid map للقراءة العامة، Esri Satellite للتصوير الفضائي. قرار الرادار لا يعتمد على لون الخريطة بل على قاعدة البيانات المحلية والمؤشرات المسجلة.";
        }
        if(x.contains("ذهب مؤكد")||x.contains("target-b")||x.contains("تارجت")) {
            return "لا أرفع هدفاً إلى ذهب مؤكد أو Target-B بدون GPZ/recovered gold/assay. التطبيق يعطي Reject/HOLD/Candidate/GPZ Field Check حسب أقرب بيانات متاحة.";
        }
        if(x.contains("gpz")||x.contains("7000")) {
            return "عند Magnetic Ground Risk عالي: Severe/Difficult + High Yield + Sensitivity 8-11 + Swing بطيء. وعند أرض هادئة مع Quartz/Silica قوي: Normal + General/Deep + Sensitivity 12-16 مع Audio Smoothing Off.";
        }
        if(x.contains("حديد")||x.contains("feox")) {
            return "FeOx وحده لا يكفي. نحتاج Structure + Pattern + Alteration، ويفضل Clay/SWIR أو Silica/Quartz أو دليل GPZ/field analog.";
        }
        if(x.contains("كيف")||x.contains("يعمل")) {
            return "حرّك الدبوس على الخريطة أو أدخل إحداثية. التطبيق يبحث عن أقرب خلية/هدف داخل قواعد NORTH/CENTER/SOUTH ثم يخرج التصنيف والسبب والمسافة. لا توجد نتائج عشوائية.";
        }
        return "فهمت. أعطني إحداثية أو وصف الأرض: بنية/وادي/كوارتز/طين أحمر/أرض داكنة/حفر GPZ/لودر، وسأحوّلها إلى قرار ميداني حسب نظام بوح: Structure → Pattern → Alteration → Confirmation → Decision.";
    }

    void showSettings() {
        frame("الإعدادات");
        ScrollView sv=new ScrollView(this); LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); sv.addView(c); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout box=card();
        box.addView(tv("إعدادات المساعد والخرائط",18,gold2,Typeface.BOLD));
        endpointInput=input("API Endpoint اختياري للمساعد الحقيقي");
        keyInput=input("API Key اختياري - يحفظ محلياً فقط");
        modelInput=input("Model اختياري");
        endpointInput.setText(prefs.getString("endpoint",""));
        keyInput.setText(prefs.getString("key",""));
        modelInput.setText(prefs.getString("model",""));
        bSave=btn("حفظ الإعدادات");
        box.addView(endpointInput); box.addView(keyInput); box.addView(modelInput); box.addView(bSave);
        box.addView(tv("ملاحظة: المساعد يعمل محلياً الآن. ربط API الحقيقي يحتاج خدمة خارجية من اختيارك. لا ترفع المفاتيح إلى GitHub.",14,Color.WHITE,Typeface.NORMAL));
        box.addView(tv("قاعدة القرار ثابتة: لا Target-B ولا ذهب مؤكد دون GPZ/sample/assay. الصور والخرائط تساعد في العرض ولا تصنع بكسلات طيفية وحدها.",14,orange,Typeface.BOLD));
        c.addView(box);
        bSave.setOnClickListener(v->{ prefs.edit().putString("endpoint",endpointInput.getText().toString()).putString("key",keyInput.getText().toString()).putString("model",modelInput.getText().toString()).apply(); Toast.makeText(this,"تم الحفظ محلياً",Toast.LENGTH_SHORT).show(); });
    }

    void analyzePoint(GeoPoint p) {
        if(status!=null) status.setText(buildDecisionText(p));
    }

    String buildDecisionText(GeoPoint p) {
        Hit h=nearest(p.getLatitude(), p.getLongitude());
        StringBuilder sb=new StringBuilder();
        sb.append("📍 إحداثية الدبوس: ").append(fmt(p.getLatitude())).append(", ").append(fmt(p.getLongitude())).append("\n");
        sb.append("🗺️ طبقة العرض: ").append(currentLayer).append("\n");
        if(h==null) return sb.append("لا توجد قاعدة بيانات محلية محملة.").toString();
        sb.append("📦 أقرب نطاق: ").append(h.t.region).append("\n");
        sb.append("🎯 أقرب خلية/هدف: ").append(h.t.id).append("\n");
        sb.append("📏 المسافة التقريبية: ").append((int)h.meters).append(" متر\n");
        if(h.meters>5000) {
            sb.append("⚠️ خارج التغطية العملية أو بعيد عن أقرب خلية متاحة. النتيجة: Outside Coverage / HOLD.\n");
        } else {
            sb.append("✅ داخل نطاق قراءة أقرب خلية متاحة.\n");
        }
        sb.append("📊 التصنيف: ").append(h.t.classification).append(" | Score: ").append(h.t.score).append("/100\n");
        sb.append("🧠 النموذج: ").append(h.t.model).append("\n");
        sb.append("🧩 المؤشرات: ").append(h.t.indicators).append("\n");
        sb.append("📚 المصدر: ").append(h.t.source).append("\n\n");
        sb.append("قرار بوح: ");
        if(h.meters>5000) sb.append("لا تعتمد القرار؛ انتقل إلى نطاق بيانات أقرب أو أضف قاعدة بكسلات كاملة.");
        else if(h.t.classification.contains("GPZ")) sb.append("GPZ Field Check: فحص ميداني بطيء ومنظم، ولا يعتبر ذهباً مؤكداً إلا باستجابة GPZ/استخراج/عينة.");
        else if(h.t.classification.contains("Candidate")) sb.append("Candidate: مناسب لفحص ميداني ومقارنة بنيوية/طيفية، وليس Target-B مثبت.");
        else if(h.t.classification.contains("HOLD")) sb.append("HOLD: مؤشر داعم يحتاج بنية أو SWIR/Clay أو GPZ أو عينة قبل الرفع.");
        else sb.append("Reject/Low: لا توجد مؤشرات كافية.");
        return sb.toString();
    }

    Hit nearest(double lat, double lon) {
        Target best=null; double bd=Double.MAX_VALUE;
        for(Target t: allTargets) {
            double d=dist(lat,lon,t.lat,t.lon);
            if(d<bd) { bd=d; best=t; }
        }
        if(best==null) return null;
        Hit h=new Hit(); h.t=best; h.meters=bd; h.inside=bd<=5000; return h;
    }

    void loadDatabases() {
        copyAssetDb("BOUH_V21_CENTER_MOBILE.db");
        copyAssetDb("BOUH_V21_NORTH_MOBILE.db");
        copyAssetDb("BOUH_V21_SOUTH_MOBILE.db");
        loadDb("BOUH_V21_CENTER_MOBILE.db"); loadDb("BOUH_V21_NORTH_MOBILE.db"); loadDb("BOUH_V21_SOUTH_MOBILE.db");
    }
    void copyAssetDb(String name) {
        try {
            File out=new File(getFilesDir(), name); if(out.exists()) return;
            InputStream in=getAssets().open("databases/"+name); FileOutputStream fos=new FileOutputStream(out);
            byte[] buf=new byte[8192]; int n; while((n=in.read(buf))>0) fos.write(buf,0,n);
            fos.close(); in.close();
        } catch(Exception e) {}
    }
    void loadDb(String name) {
        try {
            SQLiteDatabase db=SQLiteDatabase.openDatabase(new File(getFilesDir(),name).getAbsolutePath(), null, SQLiteDatabase.OPEN_READONLY);
            Cursor c=db.rawQuery("SELECT id,region,lat,lon,classification,score,model,indicators,source_note FROM targets", null);
            while(c.moveToNext()) {
                Target t=new Target();
                t.id=c.getString(0); t.region=c.getString(1); t.lat=c.getDouble(2); t.lon=c.getDouble(3);
                t.classification=c.getString(4); t.score=c.getInt(5); t.model=c.getString(6); t.indicators=c.getString(7); t.source=c.getString(8);
                allTargets.add(t);
            }
            c.close(); db.close();
        } catch(Exception e) {}
    }

    double parse(String s,double f){ try{return Double.parseDouble(s.trim().replace(",","."));}catch(Exception e){return f;} }
    String fmt(double x){ return String.format(Locale.US,"%.6f",x); }
    double dist(double lat1,double lon1,double lat2,double lon2){
        double R=6371000; double p1=Math.toRadians(lat1), p2=Math.toRadians(lat2), dp=Math.toRadians(lat2-lat1), dl=Math.toRadians(lon2-lon1);
        double a=Math.sin(dp/2)*Math.sin(dp/2)+Math.cos(p1)*Math.cos(p2)*Math.sin(dl/2)*Math.sin(dl/2);
        return R*2*Math.atan2(Math.sqrt(a),Math.sqrt(1-a));
    }
    double[] extractLatLon(String x) {
        try {
            java.util.regex.Matcher m=java.util.regex.Pattern.compile("(-?\\d{1,2}\\.\\d+)\\D+(-?\\d{1,3}\\.\\d+)").matcher(x);
            if(m.find()) return new double[]{Double.parseDouble(m.group(1)), Double.parseDouble(m.group(2))};
        } catch(Exception e) {}
        return null;
    }
}
