# BOUH Decision Rules

1. Structure -> Pattern -> Alteration -> Confirmation -> Decision.
2. No gold proof without GPZ recovered gold, sample, assay, and QA/QC.
3. No Target-B inside this mobile app by default.
4. FeOx-only is noise / sample at most, not a strong target.
5. KCL is a reference computational layer, not spectral proof.
6. Sentinel uint8 visual/derived support is relative support only, not physical reflectance.
7. Outside coverage must be shown clearly.
