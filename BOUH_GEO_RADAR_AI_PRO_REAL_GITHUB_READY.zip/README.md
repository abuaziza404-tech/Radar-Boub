# BOUH Geo Radar AI Pro Real

تطبيق Android ميداني حقيقي كبداية قوية لمنظومة بوح:

- خرائط GPS فعلية عبر osmdroid / OpenStreetMap.
- تكبير وتصغير ولمس وتحريك مباشر.
- رادار يقرأ قواعد SQLite محلية من `assets/databases`.
- مساعد بوح يعمل محلياً، ويمكن ربطه بـ API من داخل صفحة الإعدادات.
- لا يستخدم `Math.random`.
- لا يرفع `Target-B` ولا يقول ذهب مؤكد بدون GPZ/sample/assay.
- Sentinel uint8/KCL طبقات دعم فقط وليست إثبات ذهب.

## البناء عبر GitHub Actions

ارفع محتوى هذه الحزمة مفكوكاً إلى جذر المستودع، وليس ملف ZIP وحده، ثم ادخل:

Actions -> Build BOUH Geo Radar AI Pro Real APK -> Run workflow

ستجد APK في Artifacts باسم:

`BOUH-GEO-RADAR-AI-PRO-REAL-debug-apk`

## استبدال قواعد البيانات

ضع قواعدك الكاملة بدل الملفات الحالية مع الحفاظ على الأسماء:

- `app/src/main/assets/databases/BOUH_V21_NORTH_MOBILE.db`
- `app/src/main/assets/databases/BOUH_V21_CENTER_MOBILE.db`
- `app/src/main/assets/databases/BOUH_V21_SOUTH_MOBILE.db`

الأعمدة المفضلة في جدول `targets`:

`id, zone, lat, lon, score, class, evidence`

والتطبيق لديه قراءة مرنة للأسماء القريبة مثل latitude/longitude/final_score.

## تفعيل مساعد AI متصل

من داخل التطبيق:

الإعدادات -> API Endpoint + API Key + Model -> حفظ

Endpoint يجب أن يكون متوافقاً مع Chat Completions.

بدون API يعمل المساعد محلياً بقواعد بوح الأساسية.
