package com.bouh.georadarai;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.osmdroid.config.Configuration;
import org.osmdroid.tileprovider.tilesource.TileSourceFactory;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.Marker;

import java.util.List;

public class MainActivity extends Activity implements LocationListener {
    private MapView map;
    private TextView resultText;
    private LinearLayout chatList;
    private EditText chatInput;
    private EditText latInput;
    private EditText lonInput;
    private EditText apiEndpoint;
    private EditText apiKey;
    private EditText apiModel;
    private FrameLayout content;
    private LocalDataStore store;
    private DecisionEngine engine;
    private BouhAssistant assistant;
    private LocationManager locationManager;
    private RadarDecision lastDecision;

    private final int bg = Color.rgb(5, 8, 11);
    private final int panel = Color.rgb(13, 21, 27);
    private final int gold = Color.rgb(217, 174, 86);
    private final int green = Color.rgb(92, 202, 141);
    private final int text = Color.rgb(235, 239, 232);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        Configuration.getInstance().load(getApplicationContext(), PreferenceManager.getDefaultSharedPreferences(getApplicationContext()));
        store = new LocalDataStore(this);
        store.load();
        engine = new DecisionEngine();
        assistant = new BouhAssistant(this);
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        buildShell();
        showMap();
        requestLocation();
    }

    private void buildShell() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bg);
        setContentView(root);

        TextView title = new TextView(this);
        title.setText("BOUH Geo Radar AI\nخرائط GPS + رادار جيولوجي + مساعد تحليل");
        title.setTextColor(gold);
        title.setTextSize(18);
        title.setGravity(Gravity.CENTER);
        title.setPadding(14, 14, 14, 10);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setPadding(8, 4, 8, 8);
        root.addView(nav, new LinearLayout.LayoutParams(-1, -2));
        addNav(nav, "الخريطة", v -> showMap());
        addNav(nav, "الرادار", v -> showRadar());
        addNav(nav, "المساعد", v -> showChat());
        addNav(nav, "الإعدادات", v -> showSettings());

        content = new FrameLayout(this);
        root.addView(content, new LinearLayout.LayoutParams(-1, 0, 1));
    }

    private void addNav(LinearLayout nav, String label, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(Color.WHITE);
        b.setTextSize(13);
        b.setBackground(round(Color.rgb(30, 42, 49), 18));
        b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
        lp.setMargins(4, 0, 4, 0);
        nav.addView(b, lp);
    }

    private void showMap() {
        content.removeAllViews();
        FrameLayout frame = new FrameLayout(this);
        map = new MapView(this);
        map.setTileSource(TileSourceFactory.MAPNIK);
        map.setMultiTouchControls(true);
        map.getController().setZoom(10.0);
        map.getController().setCenter(new GeoPoint(19.88, 36.75));
        frame.addView(map, new FrameLayout.LayoutParams(-1, -1));

        for (TargetPoint t : store.getTargets()) {
            Marker m = new Marker(map);
            m.setPosition(new GeoPoint(t.lat, t.lon));
            m.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM);
            m.setTitle(t.id + " | " + t.className);
            m.setSnippet("Score: " + t.score + "\n" + t.evidence);
            map.getOverlays().add(m);
        }

        LinearLayout box = overlayPanel();
        Button gps = smallButton("اذهب إلى موقعي GPS");
        gps.setOnClickListener(v -> centerMyLocation());
        Button arbaat = smallButton("أربعات");
        arbaat.setOnClickListener(v -> centerAt(19.973186, 36.745590, 13.0));
        Button plus = smallButton("+"); plus.setOnClickListener(v -> map.getController().zoomIn());
        Button minus = smallButton("-"); minus.setOnClickListener(v -> map.getController().zoomOut());
        box.addView(gps); box.addView(arbaat); box.addView(plus); box.addView(minus);
        frame.addView(box);

        content.addView(frame);
    }

    private void showRadar() {
        content.removeAllViews();
        ScrollView sv = new ScrollView(this);
        LinearLayout box = verticalPanel(18);
        sv.addView(box);
        TextView h = heading("رادار بوح الميداني");
        box.addView(h);
        box.addView(label("أدخل الإحداثيات أو استخدم GPS. الحكم لا يقول ذهب مؤكد، بل يحدد قابلية الفحص الميداني."));
        latInput = input("Latitude مثال: 19.973186");
        lonInput = input("Longitude مثال: 36.745590");
        box.addView(latInput); box.addView(lonInput);
        Button analyze = actionButton("حلّل النقطة");
        analyze.setOnClickListener(v -> analyzeManual());
        Button gps = actionButton("حلّل موقعي الحالي GPS");
        gps.setOnClickListener(v -> analyzeGps());
        box.addView(analyze); box.addView(gps);
        resultText = label("النتيجة ستظهر هنا.");
        resultText.setTextSize(15);
        resultText.setBackground(round(Color.rgb(10, 18, 22), 20));
        resultText.setPadding(14, 14, 14, 14);
        box.addView(resultText, new LinearLayout.LayoutParams(-1, -2));
        content.addView(sv);
    }

    private void showChat() {
        content.removeAllViews();
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(10, 10, 10, 10);
        root.setBackgroundColor(bg);
        ScrollView sv = new ScrollView(this);
        chatList = new LinearLayout(this);
        chatList.setOrientation(LinearLayout.VERTICAL);
        sv.addView(chatList);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1));
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        chatInput = input("اسأل مساعد بوح...");
        Button send = actionButton("إرسال");
        send.setOnClickListener(v -> sendChat());
        row.addView(chatInput, new LinearLayout.LayoutParams(0, -2, 1));
        row.addView(send, new LinearLayout.LayoutParams(-2, -2));
        root.addView(row);
        content.addView(root);
        addChat("المساعد", "جاهز. أستطيع قراءة آخر نتيجة رادار، شرح القرار، اقتراح خطة GPZ، أو الدردشة عبر API إذا أدخلته من الإعدادات.");
    }

    private void showSettings() {
        content.removeAllViews();
        SharedPreferences p = getSharedPreferences("ai", MODE_PRIVATE);
        ScrollView sv = new ScrollView(this);
        LinearLayout box = verticalPanel(18);
        sv.addView(box);
        box.addView(heading("إعدادات المساعد والخرائط"));
        box.addView(label("لجعل المساعد يتكلم ويرد بقوة عبر الإنترنت: أدخل Endpoint متوافق مع Chat Completions + API Key. بدون ذلك يعمل المساعد محلياً بقواعد بوح."));
        apiEndpoint = input("API Endpoint مثال: https://api.example.com/v1/chat/completions");
        apiKey = input("API Key");
        apiModel = input("Model مثال: gpt-4o-mini");
        apiEndpoint.setText(p.getString("endpoint", ""));
        apiKey.setText(p.getString("key", ""));
        apiModel.setText(p.getString("model", "gpt-4o-mini"));
        box.addView(apiEndpoint); box.addView(apiKey); box.addView(apiModel);
        Button save = actionButton("حفظ إعدادات AI");
        save.setOnClickListener(v -> {
            p.edit().putString("endpoint", apiEndpoint.getText().toString())
                    .putString("key", apiKey.getText().toString())
                    .putString("model", apiModel.getText().toString()).apply();
            Toast.makeText(this, "تم الحفظ", Toast.LENGTH_SHORT).show();
        });
        box.addView(save);
        box.addView(label("البيانات المحلية المطلوبة داخل الحزمة:\nassets/databases/BOUH_V21_NORTH_MOBILE.db\nassets/databases/BOUH_V21_CENTER_MOBILE.db\nassets/databases/BOUH_V21_SOUTH_MOBILE.db\n\nالخرائط الحالية تستخدم OSM GPS مع كاش تلقائي. يمكن تطويرها لاحقاً إلى MBTiles/Esri cache إذا وضعت ملفات tiles محلية."));
        content.addView(sv);
    }

    private void analyzeManual() {
        try {
            double lat = Double.parseDouble(latInput.getText().toString().trim());
            double lon = Double.parseDouble(lonInput.getText().toString().trim());
            setDecision(engine.analyze(lat, lon, store.getTargets()));
        } catch (Exception e) {
            Toast.makeText(this, "أدخل إحداثيات صحيحة", Toast.LENGTH_SHORT).show();
        }
    }

    private void analyzeGps() {
        Location loc = getLastLocation();
        if (loc == null) { Toast.makeText(this, "لم يتم التقاط GPS بعد", Toast.LENGTH_SHORT).show(); return; }
        setDecision(engine.analyze(loc.getLatitude(), loc.getLongitude(), store.getTargets()));
    }

    private void setDecision(RadarDecision d) {
        lastDecision = d;
        assistant.setLastDecision(d);
        if (resultText != null) {
            resultText.setText("الحالة: " + d.status
                    + "\nداخل التغطية: " + (d.insideCoverage ? "نعم" : "لا")
                    + "\nالنطاق: " + d.zone
                    + "\nأقرب خلية: " + d.nearestId
                    + "\nالمسافة: " + Math.round(d.distanceMeters) + " م"
                    + "\nScore محلي: " + d.score
                    + "\n\n" + d.explanation);
        }
    }

    private void sendChat() {
        String q = chatInput.getText().toString().trim();
        if (q.isEmpty()) return;
        chatInput.setText("");
        addChat("أنت", q);
        assistant.ask(q, reply -> runOnUiThread(() -> addChat("المساعد", reply)));
    }

    private void addChat(String who, String msg) {
        if (chatList == null) return;
        TextView t = label(who + ":\n" + msg);
        t.setBackground(round(who.equals("أنت") ? Color.rgb(29, 48, 61) : Color.rgb(16, 27, 31), 18));
        t.setPadding(14, 12, 14, 12);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 6, 0, 6);
        chatList.addView(t, lp);
    }

    private void requestLocation() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 7);
            return;
        }
        try { locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 3000, 3, this); } catch (Exception ignored) {}
    }

    private Location getLastLocation() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return null;
        try {
            Location gps = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            Location net = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            return gps != null ? gps : net;
        } catch (Exception e) { return null; }
    }

    private void centerMyLocation() {
        Location loc = getLastLocation();
        if (loc == null || map == null) { Toast.makeText(this, "GPS غير جاهز", Toast.LENGTH_SHORT).show(); return; }
        centerAt(loc.getLatitude(), loc.getLongitude(), 15.0);
    }

    private void centerAt(double lat, double lon, double zoom) {
        if (map != null) { map.getController().setZoom(zoom); map.getController().animateTo(new GeoPoint(lat, lon)); }
    }

    @Override public void onLocationChanged(Location location) { }
    @Override public void onProviderEnabled(String provider) { }
    @Override public void onProviderDisabled(String provider) { }
    @Override public void onStatusChanged(String provider, int status, Bundle extras) { }
    @Override protected void onResume() { super.onResume(); if (map != null) map.onResume(); }
    @Override protected void onPause() { super.onPause(); if (map != null) map.onPause(); }

    private LinearLayout overlayPanel() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(10,10,10,10); l.setBackground(round(Color.argb(215, 7, 12, 16), 20));
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.RIGHT); lp.setMargins(8, 8, 8, 8); l.setLayoutParams(lp); return l;
    }
    private LinearLayout verticalPanel(int pad) { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(pad,pad,pad,pad); l.setBackgroundColor(bg); return l; }
    private TextView heading(String s) { TextView t = label(s); t.setTextColor(gold); t.setTextSize(20); return t; }
    private TextView label(String s) { TextView t = new TextView(this); t.setText(s); t.setTextColor(text); t.setTextSize(14); t.setPadding(8,8,8,8); return t; }
    private EditText input(String hint) { EditText e = new EditText(this); e.setHint(hint); e.setHintTextColor(Color.rgb(145,154,154)); e.setTextColor(Color.WHITE); e.setSingleLine(false); e.setBackground(round(Color.rgb(18,27,33), 16)); e.setPadding(14,8,14,8); return e; }
    private Button actionButton(String s) { Button b = new Button(this); b.setText(s); b.setTextColor(Color.rgb(10,12,12)); b.setTextSize(14); b.setBackground(round(gold, 18)); return b; }
    private Button smallButton(String s) { Button b = actionButton(s); b.setTextSize(12); return b; }
    private GradientDrawable round(int color, int radius) { GradientDrawable g = new GradientDrawable(); g.setColor(color); g.setCornerRadius(radius); g.setStroke(1, Color.argb(80, 255,255,255)); return g; }
}
