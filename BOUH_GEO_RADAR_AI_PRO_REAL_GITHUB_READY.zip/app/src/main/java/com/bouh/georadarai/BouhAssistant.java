package com.bouh.georadarai;

import android.content.Context;
import android.content.SharedPreferences;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class BouhAssistant {
    public interface Callback { void onReply(String text); }

    private final Context context;
    private RadarDecision lastDecision;

    public BouhAssistant(Context context) { this.context = context; }

    public void setLastDecision(RadarDecision d) { this.lastDecision = d; }

    public void ask(String userMessage, Callback cb) {
        SharedPreferences p = context.getSharedPreferences("ai", Context.MODE_PRIVATE);
        String endpoint = p.getString("endpoint", "").trim();
        String key = p.getString("key", "").trim();
        String model = p.getString("model", "gpt-4o-mini").trim();
        if (!endpoint.isEmpty() && !key.isEmpty()) {
            callApi(endpoint, key, model, userMessage, cb);
        } else {
            cb.onReply(localReply(userMessage));
        }
    }

    private String localReply(String msg) {
        String m = msg == null ? "" : msg.toLowerCase();
        String contextLine = "";
        if (lastDecision != null) {
            contextLine = "\n\nآخر قراءة للرادار:\n- الحالة: " + lastDecision.status
                    + "\n- النطاق: " + lastDecision.zone
                    + "\n- أقرب خلية: " + lastDecision.nearestId
                    + "\n- المسافة: " + Math.round(lastDecision.distanceMeters) + " م"
                    + "\n- السبب: " + lastDecision.explanation;
        }
        if (m.contains("gpz") || m.contains("جهاز") || m.contains("إعداد")) {
            return "إعداد GPZ المقترح ميدانياً يعتمد على خطر الأرض المغناطيسي. إذا كانت الأرض سوداء/بازلتية/لاتريتية وصوتها مزعج: Ground Type = Difficult/Severe، Gold Mode = High Yield، Sensitivity 8-11، Audio Smoothing Low/On، وسرعة مشي بطيئة. إذا كانت الأرض كوارتزية هادئة: Normal، General/Deep، Sensitivity 12-16، Audio Smoothing Off." + contextLine;
        }
        if (m.contains("هدف") || m.contains("نقطة") || m.contains("ذهب")) {
            return "لا أرفع أي نقطة كذهب مؤكد داخل التطبيق. القرار الصحيح: Reject / HOLD / Candidate / GPZ Field Check. الهدف الميداني الأقوى هو الذي يجمع بنية + نمط + تغير حلمائي/كوارتز أو regolith trap + تأكيد GPZ أو عينة. FeOx وحده لا يكفي، وKCL مرجع لا إثبات." + contextLine;
        }
        if (m.contains("خارج") || m.contains("تغطية")) {
            return "إذا ظهرت Outside Coverage فمعناها أن النقطة خارج قواعد NORTH/CENTER/SOUTH الموجودة داخل التطبيق أو بعيدة عن أقرب خلية موثقة. لا تستخدم الحكم خارج التغطية إلا بعد إضافة قاعدة بيانات النطاق." + contextLine;
        }
        return "أنا مساعد بوح داخل التطبيق. أستطيع شرح قراءة الرادار، مقارنة النقاط، اقتراح خطة GPZ، وتفسير سبب Reject/HOLD/Candidate/GPZ Field Check. عند ربط API من الإعدادات أتحول إلى مساعد دردشة حقيقي متصل؛ وبدونه أعمل محلياً بقواعد بوح الأساسية." + contextLine;
    }

    private void callApi(String endpoint, String key, String model, String userMessage, Callback cb) {
        new Thread(() -> {
            try {
                URL url = new URL(endpoint);
                HttpURLConnection c = (HttpURLConnection) url.openConnection();
                c.setRequestMethod("POST");
                c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                c.setRequestProperty("Authorization", "Bearer " + key);
                c.setConnectTimeout(20000);
                c.setReadTimeout(45000);
                c.setDoOutput(true);
                String system = "أنت مساعد بوح التضاريس الجيولوجي. لا تقول ذهب مؤكد إلا بدليل GPZ أو عينة أو assay. التزم Structure Pattern Alteration Confirmation Decision.";
                String safeUser = json(userMessage);
                String body = "{\"model\":\"" + json(model) + "\",\"messages\":[{\"role\":\"system\",\"content\":\"" + json(system) + "\"},{\"role\":\"user\",\"content\":\"" + safeUser + "\"}],\"temperature\":0.2}";
                OutputStream os = c.getOutputStream();
                os.write(body.getBytes(StandardCharsets.UTF_8));
                os.close();
                BufferedReader br = new BufferedReader(new InputStreamReader(
                        c.getResponseCode() >= 400 ? c.getErrorStream() : c.getInputStream(), StandardCharsets.UTF_8));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) sb.append(line);
                br.close();
                String raw = sb.toString();
                String reply = extractContent(raw);
                cb.onReply(reply.isEmpty() ? "وصل رد API لكن لم أستطع قراءة content. الرد الخام مختصر: " + raw.substring(0, Math.min(300, raw.length())) : reply);
            } catch (Exception e) {
                cb.onReply("تعذر الاتصال بالمساعد السحابي: " + e.getMessage() + "\nسأعمل محلياً الآن:\n" + localReply(userMessage));
            }
        }).start();
    }

    private String extractContent(String raw) {
        String marker = "\"content\":";
        int i = raw.indexOf(marker);
        if (i < 0) return "";
        int start = raw.indexOf('"', i + marker.length());
        if (start < 0) return "";
        StringBuilder out = new StringBuilder();
        boolean esc = false;
        for (int k = start + 1; k < raw.length(); k++) {
            char ch = raw.charAt(k);
            if (esc) {
                if (ch == 'n') out.append('\n');
                else out.append(ch);
                esc = false;
            } else if (ch == '\\') esc = true;
            else if (ch == '"') break;
            else out.append(ch);
        }
        return out.toString();
    }

    private String json(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "");
    }
}
