package com.bouh.georadarai;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class LocalDataStore {
    private final Context context;
    private final List<TargetPoint> targets = new ArrayList<>();

    public LocalDataStore(Context context) {
        this.context = context;
    }

    public void load() {
        targets.clear();
        loadDb("BOUH_V21_NORTH_MOBILE.db");
        loadDb("BOUH_V21_CENTER_MOBILE.db");
        loadDb("BOUH_V21_SOUTH_MOBILE.db");
        if (targets.isEmpty()) loadFallbackTargets();
    }

    public List<TargetPoint> getTargets() {
        return targets;
    }

    private void loadDb(String assetName) {
        SQLiteDatabase db = null;
        try {
            File out = new File(context.getFilesDir(), assetName);
            if (!out.exists() || out.length() == 0) copyAsset(assetName, out);
            db = SQLiteDatabase.openDatabase(out.getAbsolutePath(), null, SQLiteDatabase.OPEN_READONLY);
            Cursor c = db.rawQuery("SELECT name FROM sqlite_master WHERE type='table'", null);
            boolean hasTargets = false;
            while (c.moveToNext()) if ("targets".equalsIgnoreCase(c.getString(0))) hasTargets = true;
            c.close();
            if (!hasTargets) return;
            Cursor t = db.rawQuery("SELECT * FROM targets", null);
            while (t.moveToNext()) {
                String id = getString(t, "id", "target_id", "name");
                String zone = getString(t, "zone", "region", "domain");
                double lat = getDouble(t, "lat", "latitude", "y");
                double lon = getDouble(t, "lon", "lng", "longitude", "x");
                double score = getDouble(t, "score", "final_score", "bouh_score");
                String cls = getString(t, "class", "class_name", "decision", "target_class");
                String evidence = getString(t, "evidence", "reason", "description", "notes");
                if (lat != 0 && lon != 0) targets.add(new TargetPoint(id, zone, lat, lon, score, cls, evidence));
            }
            t.close();
        } catch (Exception ignored) {
        } finally {
            if (db != null) db.close();
        }
    }

    private void copyAsset(String assetName, File out) throws Exception {
        InputStream is = context.getAssets().open("databases/" + assetName);
        FileOutputStream os = new FileOutputStream(out);
        byte[] buf = new byte[8192];
        int n;
        while ((n = is.read(buf)) > 0) os.write(buf, 0, n);
        os.close();
        is.close();
    }

    private String getString(Cursor c, String... names) {
        for (String n : names) {
            int idx = c.getColumnIndex(n);
            if (idx >= 0 && !c.isNull(idx)) return c.getString(idx);
        }
        return "";
    }

    private double getDouble(Cursor c, String... names) {
        for (String n : names) {
            int idx = c.getColumnIndex(n);
            if (idx >= 0 && !c.isNull(idx)) return c.getDouble(idx);
        }
        return 0.0;
    }

    private void loadFallbackTargets() {
        targets.add(new TargetPoint("T1", "ARBAAT", 19.973186, 36.745590, 0.86, "GPZ Field Check", "Nugget/placer + dark regolith trap; field-check only."));
        targets.add(new TargetPoint("T2", "ARBAAT", 19.881313, 36.808758, 0.84, "Candidate", "GH/GV alteration cluster; requires field confirmation."));
        targets.add(new TargetPoint("T3", "ARBAAT", 19.983058, 36.776401, 0.82, "Candidate", "Structural jog / mountain-feeder core; requires GPZ/geochem."));
        targets.add(new TargetPoint("P01", "REGIONAL", 20.669096, 36.428073, 0.70, "HOLD", "GH/GV alteration-cluster from v4 regional screening."));
        targets.add(new TargetPoint("P02", "REGIONAL", 20.927345, 36.490000, 0.69, "HOLD", "GH/GV alteration-cluster from v4 regional screening."));
    }
}
