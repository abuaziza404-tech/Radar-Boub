package com.bouh.georadarai;

public class TargetPoint {
    public final String id;
    public final String zone;
    public final double lat;
    public final double lon;
    public final double score;
    public final String className;
    public final String evidence;

    public TargetPoint(String id, String zone, double lat, double lon, double score, String className, String evidence) {
        this.id = id;
        this.zone = zone;
        this.lat = lat;
        this.lon = lon;
        this.score = score;
        this.className = className;
        this.evidence = evidence;
    }
}
