package com.bouh.georadarai;

public class RadarDecision {
    public final boolean insideCoverage;
    public final String zone;
    public final String status;
    public final String nearestId;
    public final double distanceMeters;
    public final double score;
    public final String explanation;
    public final TargetPoint point;

    public RadarDecision(boolean insideCoverage, String zone, String status, String nearestId, double distanceMeters, double score, String explanation, TargetPoint point) {
        this.insideCoverage = insideCoverage;
        this.zone = zone;
        this.status = status;
        this.nearestId = nearestId;
        this.distanceMeters = distanceMeters;
        this.score = score;
        this.explanation = explanation;
        this.point = point;
    }
}
