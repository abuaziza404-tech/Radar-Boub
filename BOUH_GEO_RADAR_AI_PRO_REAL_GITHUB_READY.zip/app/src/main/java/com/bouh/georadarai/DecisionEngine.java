package com.bouh.georadarai;

import java.util.List;

public class DecisionEngine {
    public RadarDecision analyze(double lat, double lon, List<TargetPoint> targets) {
        if (targets == null || targets.isEmpty()) {
            return new RadarDecision(false, "NONE", "Outside Coverage", "", 0, 0,
                    "لا توجد قواعد بيانات محلية محملة. ضع قواعد V21/V25 داخل assets/databases ثم أعد البناء.", null);
        }
        TargetPoint nearest = null;
        double best = Double.MAX_VALUE;
        for (TargetPoint t : targets) {
            double d = GeoMath.distanceMeters(lat, lon, t.lat, t.lon);
            if (d < best) { best = d; nearest = t; }
        }
        boolean inside = best <= 1500.0;
        String status;
        if (!inside) status = "Outside Coverage";
        else if (nearest.score >= 0.82) status = "GPZ Field Check";
        else if (nearest.score >= 0.74) status = "Candidate";
        else if (nearest.score >= 0.55) status = "HOLD";
        else status = "Reject";
        String explanation;
        if (!inside) {
            explanation = "النقطة خارج نطاق الخلايا/الأهداف المحلية المتاحة. لا يتم إصدار حكم ذهبي خارج التغطية.";
        } else {
            explanation = "أقرب خلية/هدف: " + nearest.id + "، المسافة التقريبية " + Math.round(best) + " م. "
                    + "القرار مبني على Structure → Pattern → Alteration → Confirmation → Decision. "
                    + "لا يوجد Gold Proof داخل التطبيق بدون GPZ/sample/assay. " + nearest.evidence;
        }
        return new RadarDecision(inside, nearest != null ? nearest.zone : "NONE", status,
                nearest != null ? nearest.id : "", best, nearest != null ? nearest.score : 0, explanation, nearest);
    }
}
