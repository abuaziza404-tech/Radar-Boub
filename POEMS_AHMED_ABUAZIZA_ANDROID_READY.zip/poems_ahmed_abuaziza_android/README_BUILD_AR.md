# قصائد أحمد أبوعزيزه

تطبيق Android عربي RTL احترافي لتنظيم القصائد وإضافة النصوص وحفظها محليًا.

## الهوية
- اسم التطبيق: قصائد أحمد أبوعزيزه
- Package: com.ahmedabuaziza.poems
- المطور: أحمد أبوعزيزه الرشيدي
- Developer: Ahmed Abu Aziza Al-Rashidi

## الوظائف
- صفحة رئيسية منظمة.
- بحث داخل القصائد.
- أقسام للقصائد.
- إضافة قصيدة.
- تعديل قصيدة.
- حذف قصيدة.
- المفضلة.
- قراءة القصيدة بواجهة قارئ.
- تصدير JSON.
- استيراد JSON.
- نسخ قصيدة أو كامل الديوان.
- حفظ محلي داخل WebView localStorage.

## البناء
يفضل البناء عبر GitHub Actions أو Android Studio.

```bash
chmod +x ./gradlew
./gradlew assembleDebug --no-daemon --stacktrace
```

المخرج:
```text
app/build/outputs/apk/debug/app-debug.apk
```

## ملاحظة
الحزمة خفيفة ولا تحتوي على Backend. كل البيانات محفوظة محليًا داخل الهاتف.
