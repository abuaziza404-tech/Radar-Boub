# BUILD_LOG

تم تجهيز مشروع Android جاهز للبناء.

## قيود البيئة
لم يتم بناء APK داخل هذه البيئة لعدم توفر Android SDK محليًا.

## أمر البناء
```bash
chmod +x ./gradlew
./gradlew assembleDebug --no-daemon --stacktrace
```

## GitHub Actions
workflow موجود داخل:
.github/workflows/build-apk.yml
