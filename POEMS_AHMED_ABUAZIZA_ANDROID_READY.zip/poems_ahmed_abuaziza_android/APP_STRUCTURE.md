# APP_STRUCTURE

## الواجهة
- الرئيسية: عرض القصائد والإحصاءات والبحث والأقسام.
- إضافة: نموذج إضافة/تعديل قصيدة.
- المفضلة: قصائد مميزة.
- الديوان: تصدير/استيراد/نسخ/حذف.
- حول: معلومات التطبيق والمطور.

## البيانات
تخزن القصائد محليًا في localStorage بالمفتاح:
ahmed_abuaziza_poems_v1

## نموذج القصيدة
```json
{
  "id": "string",
  "title": "string",
  "category": "string",
  "occasion": "string",
  "tags": ["string"],
  "body": "string",
  "favorite": false,
  "createdAt": "ISO_DATE"
}
```
