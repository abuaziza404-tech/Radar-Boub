@echo off
where gradle >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  gradle %*
  exit /b %ERRORLEVEL%
)
echo Gradle was not found on PATH. Install Gradle 8.7 or use Android Studio.
exit /b 127
