# BOUH Terrain Radar V33 Dense Sentinel Radar

تطوير حسب طلب الرادار العددي:
- الحفاظ على الخرائط والهيكل الحالي.
- إضافة عداد رقمي دائري مثل شاشة الرادار.
- تحليل مباشر عند تحريك الخريطة في وضع المركز.
- عرض شريط علوي للمؤشرات:
  احتمال عالي جداً / احتمال عالي / احتمال متوسط / احتمال ضعيف.
- ذكر نوع المؤشر المكتشف ونوع الذهب المتوقع.
- إعادة بناء قاعدة SQLite من ملفات Sentinel-2 الثلاثة المرفوعة بكثافة عالية.

## قاعدة البيانات
- مصدر البيانات: BOUH_CENTER_ZONE.zip + BOUH_NORTH_ZONE.zip + BOUH_SOUTH_ZONE.zip
- كل نطاق يحتوي 12 باند Sentinel-2 raw TIFF.
- grid_step_pixels = 10
- dense cells = 92250
- SQLite integrity = ok

## المؤشرات المحسوبة من الباندات
- FeOx = B04 / B02
- Clay/SWIR = B11 / B12
- SWIR_ND = (B11-B12)/(B11+B12)
- NDVI mask = (B08-B04)/(B08+B04)
- Edge/Texture proxy = gradient من B11
- Drainage/Bare proxy
- Magnetic ground proxy من texture + dryness
- Lithology favorability proxy

## قاعدة الصدق
النسب والدرجات مبنية من البكسلات والباندات المرفوعة كـ Prospectivity / Field-check.
لا تؤكد الذهب اقتصادياً إلا GPZ/recovered gold/assay/QAQC.
