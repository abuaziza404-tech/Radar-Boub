Decision Engine V30 = 0.25 Structure + 0.20 Alteration + 0.15 FeOx + 0.15 Drainage + 0.10 Magnetic Proxy + 0.10 Lithology + 0.05 Historical + GPZ Boost + Distance Decay.

FeOx-only is downgraded to HOLD. No confirmed gold.
