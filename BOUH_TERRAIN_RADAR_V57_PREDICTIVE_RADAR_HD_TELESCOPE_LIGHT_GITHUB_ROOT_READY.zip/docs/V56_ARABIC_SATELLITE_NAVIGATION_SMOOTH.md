# BOUH Terrain Radar V56 Arabic Satellite Navigation Smooth

- واجهة عربية RTL.
- رادار وعدّاد ظاهر دائماً.
- خرائط محلية Offline: RGB و SWIR.
- خرائط أقمار اختيارية Online: Google Satellite و Esri World Imagery.
- طبقة طرق OSM اختيارية للملاحة.
- ملاحة ميدانية: GPS، أقرب هدف قوي، اتجاه ومسافة.
- تحسين السلاسة: تقليل النقاط المعروضة، تحميل tiles عند الحاجة، throttled render/analyze.
- قاعدة التحليل الداخلية محفوظة ولا تعطي Score عشوائي خارج التغطية.
