{
  "zone_meta": {
    "center": {
      "crs": "EPSG:4326",
      "width": 1229,
      "height": 2500,
      "bounds": [
        36.09832763671876,
        18.443135757230912,
        37.27111816406251,
        20.689322775663335
      ],
      "wgs84_bounds": {
        "west": 36.09832763671876,
        "east": 37.27111816406251,
        "south": 18.443135757230912,
        "north": 20.689322775663335
      }
    },
    "north": {
      "crs": "EPSG:4326",
      "width": 1229,
      "height": 2500,
      "bounds": [
        35.98495468025546,
        19.508616310319184,
        37.15774520759921,
        21.739678698995803
      ],
      "wgs84_bounds": {
        "west": 35.98495468025546,
        "east": 37.15774520759921,
        "south": 19.508616310319184,
        "north": 21.739678698995803
      }
    },
    "south": {
      "crs": "EPSG:4326",
      "width": 1229,
      "height": 2500,
      "bounds": [
        36.61647038303276,
        16.618150998762626,
        37.78926091037651,
        18.888473188510254
      ],
      "wgs84_bounds": {
        "west": 36.61647038303276,
        "east": 37.78926091037651,
        "south": 16.618150998762626,
        "north": 18.888473188510254
      }
    }
  },
  "cell_count": 246,
  "manifest": {
    "product": "BOUH V25 Fixed Weighted Composite KMZ",
    "type": "Single merged GroundOverlay layer + optional hidden points",
    "data_tag": "[بيانات حقيقية] for TIFF pixel values; fixed visualization proxy",
    "bounds_epsg4326": {
      "west": 35.98495468025546,
      "south": 16.61837229696988,
      "east": 37.78946801402847,
      "north": 21.739678698995803
    },
    "weights": {
      "05_score_heat_final_support": 0.3,
      "03_alteration_clay_feox_dark": 0.35,
      "02_feox": 0.2,
      "04_swir_dry_rock": 0.15,
      "01_true_color": 0.0
    },
    "recommended_use": "Always-on field composite over satellite base; do not stack older 01/02/03/04/05 layers above it.",
    "decision_limit": "Candidate / HOLD / Field-check only; no Gold Confirmed, no Target-B without GPZ/sample/assay/recovered_gold.",
    "nodata_handling": "Alpha transparent, no black rectangles intended."
  }
}