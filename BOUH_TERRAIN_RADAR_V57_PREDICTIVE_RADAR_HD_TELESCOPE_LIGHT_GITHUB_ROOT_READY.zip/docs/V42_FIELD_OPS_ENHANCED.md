# V42 Field Ops Enhanced

## Systems Added
1. Field status dashboard.
2. Saved targets with notes, visit status, and persisted LocalStorage.
3. Nearest target ranking from native SQLite cells.
4. CSV, KML, GeoJSON, and JSON export through Android native storage.
5. Track KML export.
6. Native app log file and log viewer.
7. Improved score response: confidence, bearing, direction, nearest cell coordinates.
8. Safer manifest and fixed GitHub Actions.

## Export Location
Android writes exported files to:

`Android/data/com.bouh.terrainradar.v41/files/exports/`

## Native Bridge API
- `BOUH.fieldStatus()`
- `BOUH.dbSummary()`
- `BOUH.nearestTargets(lat, lon, limit, minScore, filter)`
- `BOUH.writeExport(filename, content)`
- `BOUH.readLogs()`

## Governance
This app does not confirm gold. It ranks field-check prospects only.
