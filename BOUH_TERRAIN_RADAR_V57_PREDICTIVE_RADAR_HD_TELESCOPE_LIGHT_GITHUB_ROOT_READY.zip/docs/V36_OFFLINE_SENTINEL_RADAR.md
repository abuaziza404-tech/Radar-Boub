# BOUH Terrain Radar V36 Offline Sentinel Radar

تطوير دفعة واحدة:
- إضافة طبقات أوفلاين حقيقية من باندات Sentinel-2 المرفوعة:
  - Offline Sentinel RGB = B04/B03/B02
  - Offline Sentinel SWIR = B12/B08/B04
- هذه الطبقات تعمل بدون إنترنت لأنها محفوظة داخل التطبيق كـ image overlays.
- الإبقاء على Satellite و Hybrid عند توفر الإنترنت.
- الرادار يدور ويحلل تلقائياً كل 1.5 ثانية عند تشغيل المسح.
- العداد الرقمي والنسبة والاحتمال تظهر من أقرب خلية في SQLite.
- الحفاظ على LandMask وحذف خلايا البحر.
- الحفاظ على تركيز CENTER وشمال/جنوب كنقاط مهمة فقط.
- لا تغيير جوهري في الهيكل، فقط تحسين التشغيل والطبقات.

## قاعدة البيانات
SQLite integrity_check = ok
Cells = 25027
Stats = [('A2_LOADER_EXPANSION', 1, 80), ('A6_MOUNTAIN_FEEDER', 1, 78), ('ARB_T3_STRUCTURAL_JOG', 1, 80), ('CENTER', 24028, 93), ('NORTH', 521, 91), ('SOUTH', 475, 85)]

## ملاحظة مهمة
Offline Sentinel ليست Google Earth عالية الدقة، لكنها طبقة حقيقية من الباندات المرفوعة وتعمل أوفلاين. 
Satellite/Hybrid تحتاج إنترنت أو كاش سابق.
