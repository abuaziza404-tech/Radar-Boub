# BOUH Terrain Radar V39 AlpineQuest Zoom HD Layers

تطوير V39:
- تعديل شريط التكبير/التصغير ليصبح أبيض شفاف وأوسع وأقرب لنمط AlpineQuest Pro.
- إحداثيات عشرية في سطر واحد بدون كتابة Lat/Lon:
  20.020776° N 36.768080° E
- تحسين سلاسة التكبير والتصغير وتقليل القفزات والتعليق.
- تقليل الشريط/الخلفية السوداء أثناء الزووم عبر تعطيل fade واستخدام keepBuffer/reuseTiles قدر الإمكان.
- إضافة طبقات:
  Google Satellite HD
  Google Hybrid HD
  Esri World Imagery HD
  Esri Clarity
  NASA GIBS Recent TrueColor
  OSM Humanitarian Detail
  Offline Sentinel RGB/SWIR
- NASA Recent طبقة شبه مباشرة لكنها إقليمية وليست HD أرضية.
- خرائط الإنترنت تعتمد على توفر الخدمة والكاش؛ Offline Sentinel تبقى داخل التطبيق ولا تختفي.

SQLite integrity_check = ok
DB cells = 25027
