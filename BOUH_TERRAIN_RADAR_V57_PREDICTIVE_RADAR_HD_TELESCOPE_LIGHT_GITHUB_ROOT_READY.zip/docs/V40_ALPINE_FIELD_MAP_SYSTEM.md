# BOUH Terrain Radar V40 Alpine Field Map System

تطبيق تفاصيل واجهة الخرائط الميدانية:
- صناديق معلومات أعلى الشاشة للإحداثيات والخريطة والزووم والمقياس.
- شريط تكبير جانبي + / slider / -.
- مركز الخريطة يفتح قائمة أدوات: تحليل رادار، إنشاء معلم، نسخ الإحداثية.
- شريط سفلي من خمس فئات: التطبيق، الخرائط، المعالم، GPS، الاتجاه.
- خرائط وطبقات: Google Satellite/Hybrid، Esri، Esri Clarity، NASA Recent، OSM Detail، Offline Sentinel.
- قائمة معالم مع إنشاء واستيراد KML/KMZ.
- GPS والحساسات.
- الحفاظ على رادار بوح وقاعدة SQLite.

SQLite integrity_check = ok
DB cells = 25027
