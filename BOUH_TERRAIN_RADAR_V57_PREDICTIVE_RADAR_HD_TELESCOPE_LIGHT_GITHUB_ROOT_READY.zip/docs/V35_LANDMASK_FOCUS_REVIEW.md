# BOUH Terrain Radar V35 LandMask Focus

تطوير حسب الملاحظات الأخيرة:
- حذف خلايا البحر/الماء من قاعدة الرادار باستخدام NDWI/MNDWI/B8 water rejection.
- التركيز الكامل على نطاق CENTER.
- NORTH و SOUTH يحتويان على أعلى الخلايا/النقاط المهمة فقط.
- الحفاظ على الخرائط والهيكل، مع تبسيط طبقات الخرائط إلى Satellite و Hybrid فقط.
- تغيير علامة Crosshair/+ إلى أحمر فاتح.
- الحفاظ على السلاسة: لا يتم رسم كل الخلايا، بل أهم Hotspots فقط.
- تصحيح احتمالية النقاط الضعيفة: FeOx-only يتم تخفيضه، والبحر محذوف.

## إحصاء قاعدة V35
SQLite integrity_check = ok
Total cells after LandMask/focus = 25027
Hotspot markers candidates = 336
Stats = [('A2_LOADER_EXPANSION', 1, 80.0, 80), ('A6_MOUNTAIN_FEEDER', 1, 78.0, 78), ('ARB_T3_STRUCTURAL_JOG', 1, 80.0, 80), ('CENTER', 24028, 46.261236890294654, 93), ('NORTH', 521, 69.26487523992323, 91), ('SOUTH', 475, 66.49684210526316, 85)]

## ملخص النطاقات
{
  "CENTER": {
    "width": 1229,
    "height": 2500,
    "step": 10,
    "mode": "center",
    "cells": 24028,
    "land_before_filter": 30554,
    "valid_before_landmask": 30750
  },
  "NORTH": {
    "width": 1229,
    "height": 2500,
    "step": 10,
    "mode": "priority",
    "cells": 521,
    "land_before_filter": 30485,
    "valid_before_landmask": 30749
  },
  "SOUTH": {
    "width": 1229,
    "height": 2500,
    "step": 10,
    "mode": "priority",
    "cells": 475,
    "land_before_filter": 30423,
    "valid_before_landmask": 30748
  }
}

## قاعدة الصدق
الدرجات والنسب مبنية من الباندات المرفوعة كـ Prospectivity / Field-check.
لا يوجد تأكيد ذهب دون GPZ/recovered gold/assay/QAQC.
