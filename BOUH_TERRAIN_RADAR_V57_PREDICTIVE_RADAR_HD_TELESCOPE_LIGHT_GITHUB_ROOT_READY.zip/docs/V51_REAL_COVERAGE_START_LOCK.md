# BOUH Terrain Radar V51 — Real Coverage Start Lock

## Fixes
- Corrected the wrong startup longitude that opened the app outside Sudan.
- Startup now opens inside the operational Arbaat / West Port Sudan real coverage area.
- Added HOME / CENTER / NORTH / SOUTH quick buttons.
- Added map maximum bounds around the three real coverage zones.
- Kept V49/V50 REAL coverage logic: no target result outside the SQLite cell coverage.

## Startup home
- HOME: 19.973186, 36.745590 [from stored BOUH operational memory / user project context]
- CENTER real-coverage mean: 19.540408, 36.665146 [computed from SQLite cells]
- NORTH real-coverage mean: 20.788098, 36.488618 [computed from SQLite cells]
- SOUTH real-coverage mean: 17.600168, 37.224774 [computed from SQLite cells]

## Database
- BOUH_V30_REAL_3ZONES.db retained.
- 25,027 analysis cells available.
