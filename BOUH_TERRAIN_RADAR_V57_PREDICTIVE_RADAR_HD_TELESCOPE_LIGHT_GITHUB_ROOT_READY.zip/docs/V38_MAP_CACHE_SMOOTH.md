# BOUH Terrain Radar V38 Map Cache Smooth

تطوير V38:
- ضبط الخرائط حتى لا تختفي عند التكبير: Offline Sentinel RGB/SWIR ثابتة كـ ImageOverlay محلية.
- إضافة Google Satellite و Hybrid بزووم أعلى عند توفر الإنترنت، مع Esri كبديل.
- تحسين WebView cache لتبقى المناطق المفتوحة قدر الإمكان أثناء التصفح اللاحق.
- تكبير/تصغير أكثر سلاسة، بدون تسرع وتعليق.
- تصغير خط الإحداثيات وترتيبها: Latitude ثم Longitude.
- إضافة سطر ارتفاع تقريبي بالأمتار تحت الإحداثيات، ويقرأ GPS altitude عند توفره.
- استمرار الرادار والعداد وقاعدة SQLite.

ملاحظة: لا يمكن ضمان كاش كامل لكل خرائط Google/Esri بدون نظام MBTiles محلي، لكن هذه النسخة تحسن الكاش الداخلي وتضمن طبقات Offline Sentinel داخل التطبيق.

SQLite integrity_check = ok
DB cells = 25027
