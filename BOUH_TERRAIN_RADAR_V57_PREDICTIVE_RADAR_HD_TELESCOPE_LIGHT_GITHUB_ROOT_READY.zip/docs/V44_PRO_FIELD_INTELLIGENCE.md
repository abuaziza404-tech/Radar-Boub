# بوح التضاريس V44 Pro Field Intelligence

هذه الحزمة جاهزة للرفع إلى GitHub Actions وبناء APK مباشرة.

## أهم تطويرات V44
- رفع الإصدار الداخلي إلى `versionCode 44` و `versionName 44.0.0-pro-field-intelligence`.
- تثبيت اسم التطبيق الظاهر بعد التثبيت: **بوح التضاريس**.
- تحديث GitHub Actions ليبحث عن حزمة V44 فقط ويعرض اسم V44 في صفحة Actions.
- إضافة فحص جاهزية الميدان V44:
  - GPS
  - قاعدة البيانات
  - الإنترنت / Offline
  - الأهداف المحفوظة
  - نقاط المسار
  - حالة التصدير
- إضافة خطة مهمة ذكية V44 ترتب الأهداف حسب الدرجة ثم القرب.
- إضافة خريطة حرارية Heatmap للنتائج من قاعدة الخلايا.
- إضافة تقرير HTML احترافي قابل للمشاركة بجانب JSON/CSV/KML/GPX/GeoJSON.
- تحسين رسائل الواجهة لتعرض V44 Pro Field Intelligence.
- الحفاظ على بنية WebView + Android Bridge الحالية لتثبيت التطوير بسرعة دون كسر النظام.

## طريقة الرفع إلى GitHub
1. ارفع هذا الملف في جذر المستودع:
   `BOUH_TERRAIN_RADAR_V44_PRO_FIELD_INTELLIGENCE_GITHUB_ROOT_READY.zip`
2. أنشئ الملف:
   `.github/workflows/build-apk.yml`
3. استخدم ملف workflow الموجود داخل الحزمة أو انسخ محتواه من `.github/workflows/build-apk.yml`.
4. ادخل تبويب Actions وشغل:
   `Build BOUH Terrain Radar V44 APK`

## ملاحظة
`applicationId` بقي كما هو `com.bouh.terrainradar.v41` حتى يمكن تثبيت V44 كتحديث فوق النسخ السابقة. الاسم الظاهر للمستخدم هو **بوح التضاريس**.
