# BOUH Terrain Radar V53 Final Offline Pro

نسخة أوفلاين حقيقية: لا Leaflet CDN، لا Google/Esri/OSM tiles، لا INTERNET permission. تبدأ في أربعات/غرب بورتسودان، والخريطة غير مقفلة، والرادار ظاهر دائماً.
