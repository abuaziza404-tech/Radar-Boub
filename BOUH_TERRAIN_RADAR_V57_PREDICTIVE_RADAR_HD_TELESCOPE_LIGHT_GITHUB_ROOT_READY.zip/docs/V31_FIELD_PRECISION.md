# BOUH Terrain Radar V31 Field Precision 5m

تطوير V31 بناءً على ملاحظات الواجهة:
- زيادة الزووم والتكبير حتى مستوى ميداني أعلى داخل Leaflet.
- زر "تكبير ميداني 5m".
- مؤشر مركز Crosshair لتصفح الخرائط بدقة.
- وضعان: تحليل من مركز الشاشة أو من الدبوس.
- زر تثبيت نقطة على الخريطة.
- رادار دائري 50m حول المركز/الدبوس مع شعاع دوران.
- طبقات أقرب لأسلوب AlpineQuest / Google Earth:
  Esri Satellite, Hybrid + Labels, Topographic, Relief, OpenTopo, Streets.
- التحليل ما زال من SQLite المبنية من النطاقات الثلاثة.

مهم: دقة 5m في التطبيق هي دقة عرض/تصفح عند توفر صور قمر صناعي عالية الجودة، وليست دقة إثبات ذهب من Sentinel-2. الذهب لا يؤكد إلا بـ GPZ/recovered gold/assay/QAQC.
