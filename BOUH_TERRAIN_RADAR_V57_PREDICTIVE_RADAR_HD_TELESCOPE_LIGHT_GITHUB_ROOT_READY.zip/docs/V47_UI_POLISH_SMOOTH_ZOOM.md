
# V47 UI Polish Smooth Zoom
- Reduced top coordinate card width and height.
- Repositioned brand chip away from coordinate area.
- Reduced radar summary into a compact rectangular layout.
- Refined right-side mission buttons spacing.
- Reduced zoom control background size.
- Added smooth animated zoom for slider and +/- buttons.
