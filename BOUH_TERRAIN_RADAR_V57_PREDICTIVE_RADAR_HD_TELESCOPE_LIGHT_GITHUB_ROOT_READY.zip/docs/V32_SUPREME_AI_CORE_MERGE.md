# BOUH Terrain Radar V32 Supreme AI Core Merged

تم دمج الحزمة الجديدة:
`bouh-supreme-android-ai-core-v0.2.0.zip`

داخل تطبيق V31 Field Precision مع الحفاظ على:
- قاعدة النطاقات الثلاثة Sentinel-2 raw-band SQLite.
- رادار 50m.
- تكبير/تصفح 5m display.
- خرائط Esri/Hybrid/Topo/Relief/OpenTopo/Streets.
- مساعد عربي داخل التطبيق.

## ما تم دمجه من AI Core
- BouhKillMatrixEngine
- EvidenceValidator
- AiGuardrailFilter
- IPI / UGPS Calculators
- BouhPromptLibrary
- GlobalLearningEngine
- Governance docs and tests as reference files

## أثر الدمج داخل التطبيق
- صفحة جديدة: AI Core.
- مساعد النظام يشرح الحوكمة والـ Kill Matrix والـ Guardrails.
- SQLite metadata يحتوي معلومات AI Core.
- ملف أصول:
  app/src/main/assets/BOUH_SUPREME_AI_CORE_v0_2_0_rules.json
- مستندات مصدرية داخل:
  docs/BOUH_SUPREME_AI_CORE_v0_2_0/

## قاعدة الصدق
كل النتائج Field-check / Prospectivity فقط.
لا ذهب مؤكد دون GPZ/recovered gold/assay/QAQC.
لا Target-B من AI وحده.
FeOx-only = HOLD / Low HOLD.
Visual/KMZ/PNG/JPG = دعم بصري فقط.

## البناء
ارفع محتوى ZIP مفكوكاً إلى GitHub ثم شغل:
Actions → Build BOUH Terrain Radar V32 Supreme AI Core APK
