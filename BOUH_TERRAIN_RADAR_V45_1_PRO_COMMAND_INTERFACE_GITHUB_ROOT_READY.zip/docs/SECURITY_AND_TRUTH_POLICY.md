# Security and Truth Policy

- لا يوجد تأكيد ذهب اقتصادي داخل التطبيق.
- النتائج Field-check / Prospectivity فقط.
- لا Target-B مؤكد دون GPZ/recovered gold/assay/QAQC.
- قاعدة SQLite محلية.
- التخزين الكامل لخرائط Google/Esri يحتاج MBTiles/ترخيص مزود؛ التطبيق يستخدم كاش WebView وطبقات Offline Sentinel.
