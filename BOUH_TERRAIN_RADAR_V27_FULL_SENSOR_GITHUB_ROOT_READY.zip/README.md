# BOUH Terrain Radar V27 Full Sensor
## بوح التضاريس V27 | المطور أحمد أبوعزيزه الرشيدي

نسخة Android مستقرة للبناء عبر GitHub Actions.

- Native Android WebView + Java SQLite Bridge.
- خرائط حقيقية عند توفر الإنترنت: Streets / Hybrid map / Esri Satellite.
- الرادار يعمل محلياً من SQLite حتى لو تعذر تحميل الخريطة.
- دبوس متحرك وتحليل مباشر.
- مساعد نظام عربي محلي.
- حساسات هاتف مساندة.
- لا Math.random ولا أهداف وهمية.

## رفع GitHub
ارفع محتوى ZIP مفكوكاً إلى جذر المستودع ثم شغّل:
Actions → Build BOUH Terrain Radar V27 Full Sensor APK → Run workflow

## قواعد البيانات
ضع قواعدك الكاملة في:
app/src/main/assets/databases/
بنفس أسماء:
BOUH_V21_CENTER_MOBILE.db
BOUH_V21_NORTH_MOBILE.db
BOUH_V21_SOUTH_MOBILE.db
