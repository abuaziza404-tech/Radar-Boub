# Decision Engine
Structure → Pattern → Alteration → Confirmation → Decision

No FeOx-only strong target.
No Target-B / confirmed gold without GPZ/recovered gold/assay/QAQC.
No random scoring.
Use nearest SQLite cell/target only.
