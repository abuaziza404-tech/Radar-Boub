const CACHE='bouh-suite-pro-gh-v1';
const ASSETS=['/','/index.html','/public/style.css','/public/shared.js','/shared/data/ready_targets.json','/shared/data/ready_targets.geojson','/shared/data/ready_targets.csv'];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS)).catch(()=>{})));
self.addEventListener('fetch',e=>e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request).then(resp=>{const c=resp.clone();caches.open(CACHE).then(cache=>cache.put(e.request,c)).catch(()=>{});return resp}).catch(()=>r))));
