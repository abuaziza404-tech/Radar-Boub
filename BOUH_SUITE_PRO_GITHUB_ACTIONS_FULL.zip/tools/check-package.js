const fs=require('fs');
const required=['index.html','apps/navigator-pro/index.html','apps/target-selector-pro/index.html','apps/cloud-analysis-center/index.html','apps/core-knowledge-vault/index.html','shared/data/ready_targets.json','.github/workflows/deploy-pages.yml'];
let ok=true; for(const f of required){if(!fs.existsSync(f)){console.error('Missing',f);ok=false}else console.log('OK',f)}
process.exit(ok?0:1);
