# BOUH Suite Pro — GitHub Actions Full Package

بوح التضاريس | منظومة أبوعزيزة  
Developer: أحمد أبوعزيزه الرشيدي

## ماذا تحتوي الحزمة؟

هذه الحزمة تطبق طلبك كأربعة تطبيقات منفصلة داخل مشروع واحد:

1. `apps/navigator-pro`  
   تطبيق ملاحة للسيارة والمشي: Satellite, GPS, targets, dirt roads/old tracks concept, wells/stations/landmarks كطبقات خفيفة.

2. `apps/target-selector-pro`  
   تطبيق اختيار النقاط الجاهزة: Target map, filters, evidence card, status, source level, GPZ strategy.

3. `apps/cloud-analysis-center`  
   تطبيق سحابي starter للتحليل والاستكشاف وإنتاج Ready Target Packs.

4. `apps/core-knowledge-vault`  
   تطبيق نواة المشروع: القواعد، RAW Registry، Gold Proof Ladder، GPZ، KCL/Klemm، الأنالوجات.

## تشغيل محلي سريع

افتح:

`index.html`

أو ارفع كامل الحزمة إلى GitHub.

## GitHub Actions

توجد 3 ملفات:

- `.github/workflows/deploy-pages.yml`  
  ينشر الموقع على GitHub Pages.

- `.github/workflows/build-release-package.yml`  
  ينتج ZIP كـ artifact.

- `.github/workflows/android-webview-assets.yml`  
  ينتج حزمة أصول جاهزة لتغليف Android WebView.

## مبدأ الأداء

تطبيقات الميدان لا تحمل GeoTIFF أو Sentinel/Landsat/ASTER/DEM خام.  
هي تعرض نتائج جاهزة وخفيفة فقط.

## بيانات البداية

عدد الأهداف الجاهزة: 6  
عدد المناطق: 2
