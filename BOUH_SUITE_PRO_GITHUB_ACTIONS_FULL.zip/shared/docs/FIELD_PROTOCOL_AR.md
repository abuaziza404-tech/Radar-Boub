# Field Protocol

- لا تعتمد على FeOx وحده.
- No Structure + No Clay/Silica = HOLD/Reject.
- GPZ-positive analog لا يُرفض بسبب ضعف البنية الإقليمية وحدها.
- الحفر تثبت النموذج، لكنها لا تكون هدف البحث.
