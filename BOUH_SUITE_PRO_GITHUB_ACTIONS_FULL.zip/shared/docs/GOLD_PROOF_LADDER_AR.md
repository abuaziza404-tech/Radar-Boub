# Gold Proof Ladder

1. Predicted
2. Analysis-confirmed
3. Field-check-ready
4. GPZ-confirmed
5. Assay-confirmed
6. Confirmed gold system
