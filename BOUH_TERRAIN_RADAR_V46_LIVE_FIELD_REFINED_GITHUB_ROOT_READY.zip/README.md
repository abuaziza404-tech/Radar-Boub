# بوح التضاريس V46 Live Field Refined

هذه الحزمة جاهزة للرفع إلى GitHub Actions وبناء APK مباشرة.

## أهم تطويرات V46
- رفع الإصدار الداخلي إلى `versionCode 44` و `versionName 45.0.0-alpine-command-interface`.
- تثبيت اسم التطبيق الظاهر بعد التثبيت: **بوح التضاريس**.
- تحديث GitHub Actions ليبحث عن حزمة V46 فقط ويعرض اسم V46 في صفحة Actions.
- إضافة فحص جاهزية الميدان V46:
  - GPS
  - قاعدة البيانات
  - الإنترنت / Offline
  - الأهداف المحفوظة
  - نقاط المسار
  - حالة التصدير
- إضافة خطة مهمة ذكية V46 ترتب الأهداف حسب الدرجة ثم القرب.
- إضافة خريطة حرارية Heatmap للنتائج من قاعدة الخلايا.
- إضافة تقرير HTML احترافي قابل للمشاركة بجانب JSON/CSV/KML/GPX/GeoJSON.
- تحسين رسائل الواجهة لتعرض V46 Live Field Refined.
- الحفاظ على بنية WebView + Android Bridge الحالية لتثبيت التطوير بسرعة دون كسر النظام.

## طريقة الرفع إلى GitHub
1. ارفع هذا الملف في جذر المستودع:
   `BOUH_TERRAIN_RADAR_V46_PRO_FIELD_INTELLIGENCE_GITHUB_ROOT_READY.zip`
2. أنشئ الملف:
   `.github/workflows/build-apk.yml`
3. استخدم ملف workflow الموجود داخل الحزمة أو انسخ محتواه من `.github/workflows/build-apk.yml`.
4. ادخل تبويب Actions وشغل:
   `Build BOUH Terrain Radar V46 APK`

## ملاحظة
`applicationId` بقي كما هو `com.bouh.terrainradar.v41` حتى يمكن تثبيت V46 كتحديث فوق النسخ السابقة. الاسم الظاهر للمستخدم هو **بوح التضاريس**.

## V46 Live Field Refined
- تطبيق الواجهة المطلوبة بصرياً: بطاقة إحداثيات علوية، شريحة هوية بوح التضاريس، رادار ثلاثي الحلقات، ملخص رادار دائم، وشريط أوامر سفلي عربي.
- تحديث حي للـ Score / Structure / Alteration / FeOx / Drainage من قاعدة البيانات.
- HUD ميداني: UTM تقريبي، ارتفاع، دقة GPS، وحالة Online/Offline.
- الإبقاء على أنظمة الأهداف والمسارات والتصدير والتقارير وHeatmap وKML/GPX/CSV/GeoJSON/HTML.


## V46 Live Field Refined
- Compact coordinate header and raised placement.
- Smaller radar summary with live score/meta updates while moving the map.
- Polished footer with developer signature.
- Security and field readiness notes added in docs/V46_LIVE_FIELD_REFINED_SECURITY.md.
