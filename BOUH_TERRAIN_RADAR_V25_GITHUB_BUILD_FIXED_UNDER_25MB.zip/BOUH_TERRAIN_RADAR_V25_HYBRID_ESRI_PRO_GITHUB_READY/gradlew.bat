@echo off
setlocal
set APP_HOME=%~dp0
where gradle >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  gradle %*
  exit /b %ERRORLEVEL%
)
if exist "%APP_HOME%gradle\wrapper\gradle-wrapper.jar" (
  java -cp "%APP_HOME%gradle\wrapper\gradle-wrapper.jar" org.gradle.wrapper.GradleWrapperMain %*
  exit /b %ERRORLEVEL%
)
echo Gradle command not found. Install Gradle 8.7+ or build with GitHub Actions.
exit /b 127
