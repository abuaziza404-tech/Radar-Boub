#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if command -v gradle >/dev/null 2>&1; then
  gradle assembleDebug --no-daemon
else
  echo "gradle command not found. Install Gradle 8.7+ and Android SDK, or run GitHub Actions workflow .github/workflows/build-apk.yml" >&2
  exit 127
fi
echo "APK: app/build/outputs/apk/debug/app-debug.apk"
