# FIELD_NAVIGATION_ARCHITECTURE_AR.md

## بنية النظام الجديدة

تم تنظيم التطبيق كمزيج بين:

1. Map Engine
2. Field Navigator
3. Data Manager
4. BOUH Radar Decision Engine

## Map Engine

- Base maps:
  - Esri Satellite
  - Esri World Imagery
  - Hybrid Satellite Labels
  - OSM Cache
  - Topographic Cache
  - Offline MBTiles

- Overlays:
  - Heatmap
  - Targets
  - Klemm
  - User waypoints
  - Tracks

قاعدة مهمة:
الخرائط والـ heatmap طبقات عرض فقط، ولا تدخل في قرار الرادار.

## Field Navigator

أضيفت تبويبات تشغيل ميداني:

- الخرائط
- الطبقات
- GPS
- النقاط Waypoints
- المسارات Tracks
- استيراد/تصدير
- حالة البيانات

## GPS

يدعم:

- تحديد موقعي مرة واحدة
- تتبع GPS مباشر
- حفظ نقطة من الموقع
- بدء/إيقاف مسار
- عرض الدقة عند توفرها

## Waypoints

تدعم:

- إضافة نقطة من مركز الشاشة
- فتح نقطة
- تعديل الاسم
- إضافة ملاحظات
- حذف
- تصدير KML
- تصدير CSV

## Tracks

تدعم:

- بدء تسجيل مسار
- تسجيل نقاط أثناء حركة GPS أو مركز الشاشة
- إيقاف وحفظ
- فتح المسار
- حذف
- تصدير KML
- تصدير CSV

## KML/KMZ

- KML مدعوم داخل الواجهة.
- KMZ ملف مضغوط، ويحتاج فك الضغط إلى KML في هذا الإصدار.
- KML/KMZ لا يدخل في score الرادار.
- Klemm/KCL يبقى مرجعاً فقط.

## BOUH Radar

يبقى كما هو:

Structure → Pattern → Alteration → Confirmation → Decision

قراراته المسموحة:

- Candidate
- HOLD
- LOW HOLD
- Reject
- Outside coverage

ممنوع:

- ترقية ميدانية بدون GPZ/sample/assay/recovered_gold
- تأكيد ذهب نهائي بدون عينة/assay/recovered_gold
- FeOx-only كهدف قوي
- Klemm كإثبات ذهب

## تاريخ التحديث

2026-05-31 06:13:11 UTC
