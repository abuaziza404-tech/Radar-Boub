# SIZE_BUDGET_25MB_REPORT.md

Date: 2026-05-31 06:51:37 UTC

## Goal
Keep the delivered package under 25MB.

## Actions
- Compressed splash asset from PNG to optimized JPG.
- Removed unused old V13/V14/V15/V19/V20 data files from runtime assets.
- Removed unused old UI images.
- Kept the three original SQLite V21 databases required by the radar.
- Kept Satellite + Hybrid map system only.
- Kept Klemm reference KML because it is small and part of the field reference library.

## Raw runtime assets kept
- `app/src/main/assets/index.html`
- `app/src/main/assets/databases/BOUH_V21_NORTH_MOBILE.db`
- `app/src/main/assets/databases/BOUH_V21_CENTER_MOBILE.db`
- `app/src/main/assets/databases/BOUH_V21_SOUTH_MOBILE.db`
- `app/src/main/assets/reference/klemm_sudan_gold_sites_organized_important.kml`
- `app/src/main/assets/ui/brand/bouh_splash_v25_1.jpg`

## CI guard
GitHub Actions now checks:
```bash
BYTES="$(stat -c%s app/build/outputs/apk/debug/app-debug.apk)"
MAX=$((25 * 1024 * 1024))
if [ "$BYTES" -gt "$MAX" ]; then exit 1; fi
```

Final ZIP size is under 25MB.
