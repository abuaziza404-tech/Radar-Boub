# لا تستبدل محرك الرادار بهذا الكود التجريبي

الكود الذي يحتوي على:
- random-number generator calls
- geologicalMatrix ثابتة
- LandMask يعتمد على lng فقط
- Leaflet من CDN خارجي

لا يصلح كنسخة بوح التضاريس الحقيقية.

نسخة V18.1 تحافظ على:
- APP_DATA الحقيقي
- Pixel/Grid Reader
- LandMask
- Field Audit
- QA Targets
- MapServer محلي
- MBTiles
- KML/CSV/GeoJSON Export

أي قيمة رادار يجب أن تأتي من بيانات مدمجة أو ملف خام/محسوب، وليس من توليد عشوائي.
