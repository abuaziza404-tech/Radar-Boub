# بنية الرادار الاحترافي الحقيقي - BOUH V25

تاريخ التعديل: 2026-05-31 06:26 UTC

## الحكم الفني الصريح

تم تحويل الرادار إلى **BOUH Gold Terrain Radar Pro** داخل التطبيق.

الرادار ليس محاكاة، ولا يستخدم عشوائية، ولا يولد أهدافاً من الواجهة.  
الرادار يقرأ من قواعد SQLite الأصلية، ثم يطبق دالة دمج احترافية حتمية deterministic fusion على المؤشرات.

## مصادر البيانات الأصلية

- `BOUH_V21_NORTH_MOBILE.db`
- `BOUH_V21_CENTER_MOBILE.db`
- `BOUH_V21_SOUTH_MOBILE.db`

الجداول المستخدمة:
- `regions`
- `targets`
- `clusters`
- `scores_quick_grid`
- `pixel_review_quick_grid`
- `layer_registry`
- `decision_rules`
- `klemm_sites`

## دالة الدقة الاحترافية

تمت إضافة:
- `professionalRadarAnalyze(lat, lon)`
- `professionalAnalyze(lat, lon)`
- `aiApiStatus()`

الدالة الاحترافية تقرأ نتيجة SQLite الأصلية ثم تبني:

- `professional_decision`
- `confidence`
- `confidence_class`
- `evidence_matrix`
- `indicator_precision`
- `field_action`
- `local_ai_explanation`
- `api_ai`

## منطق الدقة

الدالة لا تغير قاعدة بوح الجيولوجية:

`Structure → Pattern → Alteration → Confirmation → Decision`

وتراعي:
- وجود/غياب البنية.
- وجود/غياب النمط.
- وجود/غياب التحوير.
- قرب الخلية الأصلية.
- وجود هدف قريب داخل DB.
- خطر الضجيج.
- منع FeOx-only كهدف قوي.
- منع أي ترقية دون GPZ/sample/assay/recovered_gold.

## AI و API

تمت إضافة حالة AI/API داخل الرادار:

- AI الحالي: تفسير محلي قابل للتفسير local explainable rules.
- API خارجي: غير مفعل افتراضياً.
- Satellite API خارجي: غير مفعل افتراضياً.
- أي API خارجي لا يغير قرار SQLite الأصلي إلا إذا أضيفت أدلة ميدانية صريحة.

السبب: التطبيق يجب أن يبقى أوفلاين وميداني، ولا يجوز جعل قرار الذهب يعتمد على تخمين cloud AI أو بلاطات بصرية فقط.

## سياسة الأقمار الصناعية

- Sentinel/Landsat/visual tiles تعامل كـ relative proxy فقط.
- البلاطات المرئية ليست calibrated reflectance.
- الزووم العالي لا يعني دقة رادار 5m.
- المعاينة القريبة تعتمد على دقة البلاطات المتوفرة.

## القرارات المسموحة

- Candidate
- HOLD
- LOW HOLD
- Reject
- Outside coverage

## ممنوع

- لا تأكيد ذهب نهائي دون عينة أو assay أو recovered_gold.
- لا ترقية ميدانية دون GPZ/sample/assay.
- لا عشوائية.
- لا محاكاة أهداف.
- لا FeOx-only كهدف قوي.
- لا استخدام كليم كإثبات ذهب.
