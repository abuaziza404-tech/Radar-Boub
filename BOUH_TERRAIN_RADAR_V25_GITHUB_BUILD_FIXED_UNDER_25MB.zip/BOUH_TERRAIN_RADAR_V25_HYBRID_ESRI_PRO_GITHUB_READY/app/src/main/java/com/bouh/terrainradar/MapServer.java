package com.bouh.terrainradar;

import android.content.Context;
import android.content.res.AssetManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URL;
import java.net.HttpURLConnection;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MapServer {
    public static final int PORT = 8765;
    // Allows online tile acquisition when network exists, while always serving cached tiles first.
    // This is the AlpineQuest-style behavior requested: view online once, reuse offline later.
    private static final boolean OFFLINE_ONLY = true;
    private final Context context;
    private ServerSocket serverSocket;
    private volatile boolean running = false;
    private SQLiteDatabase mbtilesDb;
    private final Map<String, SQLiteDatabase> heatmapDbs = new LinkedHashMap<>();
    
    private final ExecutorService threadPool = Executors.newFixedThreadPool(4);

    private final Map<String, byte[]> memoryCache = new LinkedHashMap<String, byte[]>(256, 0.75f, true) {
        @Override
        protected boolean removeEldestEntry(Map.Entry<String, byte[]> eldest) {
            return size() > 320;
        }
    };

    public MapServer(Context context) {
        this.context = context.getApplicationContext();
    }

    public void start() {
        if (running) return;
        running = true;
        new Thread(() -> {
            try {
                prepareMbtiles();
                // Heatmap MBTiles are prepared lazily per requested layer to avoid loading every map at startup.
                serverSocket = new ServerSocket(PORT);
                while (running) {
                    final Socket socket = serverSocket.accept();
                    threadPool.execute(() -> handle(socket));
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }, "BOUH-MapServer").start();
    }

    public void stop() {
        running = false;
        try { if (serverSocket != null) serverSocket.close(); } catch (Exception ignored) {}
        try { if (mbtilesDb != null) mbtilesDb.close(); } catch (Exception ignored) {}
        try { for (SQLiteDatabase db : heatmapDbs.values()) { if (db != null) db.close(); } } catch (Exception ignored) {}
        
        threadPool.shutdownNow();
    }

    private void prepareMbtiles() {
        try {
            File mb = new File(context.getFilesDir(), "offline.mbtiles");
            if (!mb.exists()) {
                try {
                    InputStream in = context.getAssets().open("maps/offline.mbtiles");
                    FileOutputStream out = new FileOutputStream(mb);
                    byte[] buf = new byte[1024 * 64];
                    int n;
                    while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                    in.close();
                    out.close();
                } catch (Exception noBundledMbtiles) {
                    // No MBTiles file bundled. XYZ asset tiles may still work.
                }
            }
            if (mb.exists()) {
                mbtilesDb = SQLiteDatabase.openDatabase(mb.getAbsolutePath(), null, SQLiteDatabase.OPEN_READONLY);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private synchronized SQLiteDatabase getHeatmapDb(String key) {
        SQLiteDatabase existing = heatmapDbs.get(key);
        if (existing != null && existing.isOpen()) return existing;
        if ("north".equals(key)) prepareNamedHeatmap("north", "maps/v21_north_heatmap.mbtiles", "v21_north_heatmap.mbtiles");
        else if ("center".equals(key)) prepareNamedHeatmap("center", "maps/v21_center_heatmap.mbtiles", "v21_center_heatmap.mbtiles");
        else if ("south".equals(key)) prepareNamedHeatmap("south", "maps/v21_south_heatmap.mbtiles", "v21_south_heatmap.mbtiles");
        return heatmapDbs.get(key);
    }

    private void prepareAllHeatmapMbtiles() {
        prepareNamedHeatmap("north", "maps/v21_north_heatmap.mbtiles", "v21_north_heatmap.mbtiles");
        prepareNamedHeatmap("center", "maps/v21_center_heatmap.mbtiles", "v21_center_heatmap.mbtiles");
        prepareNamedHeatmap("south", "maps/v21_south_heatmap.mbtiles", "v21_south_heatmap.mbtiles");
    }

    private void prepareNamedHeatmap(String key, String assetName, String fileName) {
        try {
            File mb = new File(context.getFilesDir(), fileName);
            if (!mb.exists()) {
                try {
                    InputStream in = context.getAssets().open(assetName);
                    FileOutputStream out = new FileOutputStream(mb);
                    byte[] buf = new byte[1024 * 64];
                    int n;
                    while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                    in.close();
                    out.close();
                } catch (Exception noBundledHeatmap) {
                    return;
                }
            }
            if (mb.exists()) {
                SQLiteDatabase db = SQLiteDatabase.openDatabase(mb.getAbsolutePath(), null, SQLiteDatabase.OPEN_READONLY);
                heatmapDbs.put(key, db);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void handle(Socket socket) {
        try {
            InputStream input = socket.getInputStream();
            ByteArrayOutputStream req = new ByteArrayOutputStream();
            byte[] b = new byte[1024];
            int n = input.read(b);
            if (n <= 0) { send404(socket); return; }
            req.write(b, 0, n);
            String request = req.toString("UTF-8");
            String first = request.split("\r?\n")[0];
            String[] parts = first.split(" ");
            if (parts.length < 2) { send404(socket); return; }

            String path = parts[1];

            if (path.startsWith("/status") || path.startsWith("/health") || path.startsWith("/cache/status")) {
                String payload = path.startsWith("/health")
                        ? "{\"ok\":true,\"app\":\"BOUH Terrain Radar V25 Hybrid Esri Pro\",\"developer\":\"Ahmed Abu Aziza Al-Rashidi\",\"offline\":true}"
                        : cacheStatus();
                byte[] msg = payload.getBytes("UTF-8");
                send200(socket, msg, "application/json");
                return;
            }

            byte[] tile;
            String type = "image/png";
            if (path.startsWith("/v21heatmap/")) {
                String clean = path.substring("/v21heatmap/".length());
                String[] hp = clean.split("/", 2);
                if (hp.length < 2) { sendTransparent(socket); return; }
                String regionKey = hp[0].toLowerCase();
                path = "/" + hp[1];
                if (!path.endsWith(".png") && !path.endsWith(".jpg") && !path.endsWith(".webp")) path = path + ".png";
                SQLiteDatabase hdb = getHeatmapDb(regionKey);
                tile = loadFromSpecificMbtiles(hdb, path);
                type = contentType(path);
            } else if (path.startsWith("/proxy/")) {
                tile = getProxyTile(path);
                type = contentType(path);
            } else {
                if (path.startsWith("/tiles/offline/")) path = path.substring("/tiles/offline".length());
                else if (path.startsWith("/tiles/")) path = path.substring("/tiles".length());
                if (!path.endsWith(".png") && !path.endsWith(".jpg") && !path.endsWith(".webp")) {
                    path = path + ".png";
                }
                tile = getTile(path);
                type = contentType(path);
            }

            if (tile == null) {
                sendTransparent(socket);
            } else {
                send200(socket, tile, type);
            }
        } catch (Exception e) {
            try { sendTransparent(socket); } catch (Exception ignored) {}
        } finally {
            try { socket.close(); } catch (Exception ignored) {}
        }
    }

    private byte[] getProxyTile(String path) {
        try {
            String clean = path.replace("/proxy/", "");
            if (clean.startsWith("/")) clean = clean.substring(1);
            String[] p = clean.split("/");
            if (p.length < 4) return null;
            String provider = normalizeProvider(p[0]);
            String z = p[1], x = p[2], yFile = p[3];
            String y = yFile.replace(".png", "").replace(".jpg", "").replace(".jpeg", "").replace(".webp", "");
            String ext = providerDefaultExt(provider);

            File dir = new File(context.getFilesDir(), "tile_cache/" + provider + "/" + z + "/" + x);
            File cached = new File(dir, y + ext);
            if (cached.exists() && cached.length() > 0) {
                return readFile(cached);
            }

            String url = providerUrl(provider, z, x, y);
            if (url == null) return null;
            if (OFFLINE_ONLY) return null;
            byte[] data = fetchUrl(url);
            if (data != null && data.length > 0) {
                if (!dir.exists()) dir.mkdirs();
                FileOutputStream out = new FileOutputStream(cached);
                out.write(data);
                out.flush();
                out.close();
                return data;
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    private String normalizeProvider(String provider) {
        if ("sat".equals(provider) || "imagery".equals(provider) || "esriImagery".equals(provider)) return "esri";
        if ("hybrid".equals(provider) || "label".equals(provider)) return "labels";
        return provider;
    }

    private String providerDefaultExt(String provider) {
        if ("esri".equals(provider)) return ".jpg";
        return ".png";
    }

    private String providerUrl(String provider, String z, String x, String y) {
        if ("esri".equals(provider)) {
            return "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/" + z + "/" + y + "/" + x;
        }
        if ("labels".equals(provider)) {
            // Transparent labels/roads overlay for Hybrid Satellite.
            return "https://basemaps.cartocdn.com/light_only_labels/" + z + "/" + x + "/" + y + ".png";
        }
        if ("osm".equals(provider)) {
            return "https://tile.openstreetmap.org/" + z + "/" + x + "/" + y + ".png";
        }
        if ("topo".equals(provider)) {
            return "https://tile.opentopomap.org/" + z + "/" + x + "/" + y + ".png";
        }
        if ("carto".equals(provider)) {
            return "https://basemaps.cartocdn.com/light_all/" + z + "/" + x + "/" + y + ".png";
        }
        return null;
    }

    private byte[] fetchUrl(String urlStr) {
        HttpURLConnection conn = null;
        try {
            URL url = new URL(urlStr);
            conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(6000);
            conn.setReadTimeout(9000);
            conn.setRequestProperty("User-Agent", "BOUH-Terrain-Radar/25.0-hybrid-esri (offline cache field app; developer Ahmed Abu Aziza Al-Rashidi)");
            int code = conn.getResponseCode();
            if (code < 200 || code >= 300) return null;
            InputStream in = conn.getInputStream();
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            byte[] buf = new byte[1024 * 32];
            int n;
            while ((n = in.read(buf)) != -1) baos.write(buf, 0, n);
            in.close();
            return baos.toByteArray();
        } catch (Exception e) {
            return null;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private byte[] readFile(File f) {
        try (InputStream in = new java.io.FileInputStream(f);
             ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
            byte[] buf = new byte[1024 * 32];
            int n;
            while ((n = in.read(buf)) != -1) baos.write(buf, 0, n);
            return baos.toByteArray();
        } catch (Exception e) {
            return null;
        }
    }

    private String cacheStatus() {
        File root = new File(context.getFilesDir(), "tile_cache");
        long[] s = countFiles(root);
        return statusJson();
    }


    public String statusJson() {
        File root = new File(context.getFilesDir(), "tile_cache");
        long[] s = countFiles(root);
        return "{\"tiles\":" + s[0] + ",\"bytes\":" + s[1] + ",\"offlineOnly\":true,\"onlineCache\":false,\"networkFetchDisabled\":true,\"providers\":[\"satellite\",\"hybrid_map\",\"local_mbtiles\",\"sqlite_radar\"],\"visibleBaseMaps\":[\"Satellite\",\"Hybrid Map\"],\"routes\":[\"/proxy/sat\",\"/proxy/hybrid\",\"/tiles/offline\",\"/status\",\"/health\"],\"hybrid\":true,\"transparentFallback\":true,\"extraOverlaysVisible\":false,\"loadedHeatmaps\":0,\"mbtiles\":[\"north\",\"center\",\"south\"]}";
    }

    private long[] countFiles(File f) {
        long count = 0, bytes = 0;
        if (f == null || !f.exists()) return new long[]{0,0};
        File[] list = f.listFiles();
        if (list == null) return new long[]{0,0};
        for (File x : list) {
            if (x.isDirectory()) {
                long[] c = countFiles(x);
                count += c[0]; bytes += c[1];
            } else {
                count++; bytes += x.length();
            }
        }
        return new long[]{count,bytes};
    }

    private byte[] getTile(String path) {
        String key = path;
        synchronized (memoryCache) {
            if (memoryCache.containsKey(key)) return memoryCache.get(key);
        }

        byte[] tile = loadFromMbtiles(path);
        if (tile == null) tile = loadFromAssetTiles(path);

        if (tile != null) {
            synchronized (memoryCache) {
                memoryCache.put(key, tile);
            }
        }
        return tile;
    }


    private byte[] loadFromSpecificMbtiles(SQLiteDatabase db, String path) {
        if (db == null) return null;
        try {
            String clean = path.replace(".png", "").replace(".jpg", "").replace(".webp", "");
            if (clean.startsWith("/")) clean = clean.substring(1);
            String[] p = clean.split("/");
            if (p.length < 3) return null;
            int z = Integer.parseInt(p[0]);
            int x = Integer.parseInt(p[1]);
            int y = Integer.parseInt(p[2]);
            byte[] xyz = queryDbMb(db, z, x, y);
            if (xyz != null) return xyz;
            int tmsY = (1 << z) - 1 - y;
            return queryDbMb(db, z, x, tmsY);
        } catch (Exception e) {
            return null;
        }
    }

    private byte[] queryDbMb(SQLiteDatabase db, int z, int x, int y) {
        Cursor c = null;
        try {
            c = db.rawQuery(
                    "SELECT tile_data FROM tiles WHERE zoom_level=? AND tile_column=? AND tile_row=?",
                    new String[]{String.valueOf(z), String.valueOf(x), String.valueOf(y)}
            );
            if (c.moveToFirst()) return c.getBlob(0);
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
        return null;
    }

    private byte[] loadFromMbtiles(String path) {
        if (mbtilesDb == null) return null;
        try {
            String clean = path.replace(".png", "").replace(".jpg", "").replace(".webp", "");
            if (clean.startsWith("/")) clean = clean.substring(1);
            String[] p = clean.split("/");
            if (p.length < 3) return null;
            int z = Integer.parseInt(p[0]);
            int x = Integer.parseInt(p[1]);
            int y = Integer.parseInt(p[2]);

            byte[] xyz = queryMb(z, x, y);
            if (xyz != null) return xyz;

            int tmsY = (1 << z) - 1 - y;
            return queryMb(z, x, tmsY);
        } catch (Exception e) {
            return null;
        }
    }

    private byte[] queryMb(int z, int x, int y) {
        Cursor c = null;
        try {
            c = mbtilesDb.rawQuery(
                    "SELECT tile_data FROM tiles WHERE zoom_level=? AND tile_column=? AND tile_row=?",
                    new String[]{String.valueOf(z), String.valueOf(x), String.valueOf(y)}
            );
            if (c.moveToFirst()) return c.getBlob(0);
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
        return null;
    }

    private byte[] loadFromAssetTiles(String path) {
        String clean = path.startsWith("/") ? path.substring(1) : path;
        String assetPath = "maps/" + clean;
        AssetManager am = context.getAssets();
        try (InputStream is = am.open(assetPath);
             ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
            byte[] buf = new byte[1024 * 32];
            int n;
            while ((n = is.read(buf)) != -1) baos.write(buf, 0, n);
            return baos.toByteArray();
        } catch (Exception e) {
            return null;
        }
    }

    private String contentType(String path) {
        if (path.endsWith(".jpg") || path.endsWith(".jpeg")) return "image/jpeg";
        if (path.endsWith(".webp")) return "image/webp";
        return "image/png";
    }

    private void send200(Socket socket, byte[] data, String type) throws Exception {
        OutputStream out = new BufferedOutputStream(socket.getOutputStream());
        String h = "HTTP/1.1 200 OK\r\n" +
                "Content-Type: " + type + "\r\n" +
                "Access-Control-Allow-Origin: *\r\n" +
                "Cache-Control: max-age=86400\r\n" +
                "Content-Length: " + data.length + "\r\n\r\n";
        out.write(h.getBytes("UTF-8"));
        out.write(data);
        out.flush();
    }

    private void sendTransparent(Socket socket) throws Exception {
        byte[] transparentPng = android.util.Base64.decode(
                "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/p9sAAAAASUVORK5CYII=",
                android.util.Base64.DEFAULT
        );
        send200(socket, transparentPng, "image/png");
    }

    private void send404(Socket socket) throws Exception {
        OutputStream out = socket.getOutputStream();
        String h = "HTTP/1.1 404 Not Found\r\nAccess-Control-Allow-Origin: *\r\nContent-Length: 0\r\n\r\n";
        out.write(h.getBytes("UTF-8"));
        out.flush();
    }
}
