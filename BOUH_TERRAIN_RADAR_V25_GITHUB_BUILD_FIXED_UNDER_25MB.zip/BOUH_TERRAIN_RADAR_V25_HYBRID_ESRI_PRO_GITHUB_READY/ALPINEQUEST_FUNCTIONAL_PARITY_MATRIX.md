# ALPINEQUEST_FUNCTIONAL_PARITY_MATRIX.md

## الغرض

هذا الملف لا يعلن أي علاقة أو نسخ أو مطابقة اسم/شعار/تصميم لتطبيق AlpineQuest Pro.
المقصود هو مطابقة وظيفية ميدانية لمستوى الاستخدام فقط داخل تطبيق مستقل باسم:

- بوح التضاريس V25
- BOUH Terrain Radar V25 Hybrid Esri Pro
- Package: `com.bouh.terrainradar`
- المطور: أحمد أبوعزيزه الرشيدي
- Developer: Ahmed Abu Aziza Al-Rashidi

## مبدأ التنفيذ

تم تحويل الطلب إلى بنية تشغيل مستقلة:

**Field Navigator + Offline Maps + BOUH Candidate Radar**

ولا توجد أي أصول أو شعارات أو واجهات مملوكة لتطبيق آخر.

## Matrix المطابقة الوظيفية

| المجال | المطلوب ميدانياً | التنفيذ داخل BOUH V25 | الحالة |
|---|---|---|---|
| Base maps | قمر صناعي / Hybrid / OSM / Topo | Esri Imagery, Hybrid labels, OSM cache, Topo cache, Offline MBTiles | مضاف |
| Offline MBTiles | خرائط محلية لا تعتمد على الشبكة | `maps/*.mbtiles` عبر `MapServer` | مضاف |
| Tile fallback | عدم ظهور مربعات بيضاء | tile error class + transparent fallback في MapServer | مضاف |
| Cache | فتح منطقة ثم استخدامها لاحقاً | `warmCache()` + cache status | مضاف |
| Layers | فصل Base عن overlays | tabs: الخرائط + الطبقات، heatmap/targets/Klemm/waypoints/tracks منفصلة | مضاف |
| GPS | تحديد الموقع والتتبع | `getCurrentPosition` + `watchPosition` + WebView geolocation permissions | مضاف |
| Coordinates | عرض مركز الشاشة وGPS | Decimal + UTM تقريباً | مضاف |
| Waypoints | حفظ/فتح/تسمية/حذف نقاط | LocalStorage + KML/CSV export | مضاف |
| Tracks | بدء/إيقاف/حفظ مسار | Active track + saved tracks + KML/CSV export | مضاف |
| KML import | استيراد نقاط ومسارات | KML parser داخل الواجهة | مضاف |
| KMZ | ملف مضغوط | مذكور كحد تقني: فك الضغط ثم استيراد KML | محدود |
| KML/KMZ relation to radar | لا تدخل في score | منفصلة عن Decision Engine | مضاف |
| Klemm library | طبقة ومكتبة مستقلة | صفحة كليم مستقلة وتحذير ثابت | مضاف |
| BOUH Radar | Candidate & Field-check | Native SQLite / AndroidBridge / قواعد V21 | موجود |
| Data status | حالة قواعد وخرائط | Diagnostics tab | موجود |
| Field log | سجل قراءة | Export JSON/CSV + Waypoints/Tracks | مضاف جزئياً |
| Identity | تطبيق مستقل | لا يوجد اسم/شعار/تصميم AlpineQuest داخل UI | مؤكد |

## حدود واضحة

- لا يوجد نسخ لاسم أو شعار أو أصول أو UI لتطبيق AlpineQuest.
- لا يتم استخدام AlpineQuest داخل التطبيق أو ملفات التشغيل.
- التشابه فقط في مستوى الوظائف المطلوبة للخرائط والملاحة الميدانية.
- بوح التضاريس يضيف طبقة فريدة: Radar Candidate & Field-check Engine من SQLite المحلي.

## حالة البناء

آخر تحديث: 2026-05-31 06:13:11 UTC

لا يوجد Android SDK داخل بيئة ChatGPT الحالية، لذلك بناء APK الفعلي يتم عبر GitHub Actions أو Android Studio بالأمر:

```bash
./gradlew assembleDebug --no-daemon
```
