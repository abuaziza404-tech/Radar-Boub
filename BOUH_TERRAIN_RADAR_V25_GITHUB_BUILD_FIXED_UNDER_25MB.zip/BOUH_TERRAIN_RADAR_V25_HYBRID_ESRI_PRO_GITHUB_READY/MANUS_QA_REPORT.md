# MANUS_QA_REPORT.md

Date: 2026-05-31 06:51:37 UTC

## GitHub build repair QA
- Workflow path: `.github/workflows/build-apk.yml`
- JDK: 17
- Gradle: 8.7
- Android SDK: platform 34
- Build tools: 34.0.0
- APK size limit: 25MB enforced in CI

## Package identity
- Package name: `com.bouh.terrainradar`
- App label: `بوح التضاريس V25`
- Developer Arabic: `أحمد أبوعزيزه الرشيدي`
- Developer English: `Ahmed Abu Aziza Al-Rashidi`

## JavaScript
- Extracted inline scripts from `app/src/main/assets/index.html`
- `node --check`: OK
- `Math.random`: 0 occurrences

## SQLite integrity

### BOUH_V21_NORTH_MOBILE.db
- integrity_check: `ok`
- targets: 200
- clusters: 25
- pixel_review_quick_grid: 5000
- scores_quick_grid: 5000
- regions: 1
- metadata: 12

### BOUH_V21_CENTER_MOBILE.db
- integrity_check: `ok`
- targets: 200
- clusters: 380
- pixel_review_quick_grid: 4900
- scores_quick_grid: 4900
- regions: 1
- metadata: 12

### BOUH_V21_SOUTH_MOBILE.db
- integrity_check: `ok`
- targets: 200
- clusters: 11
- pixel_review_quick_grid: 5000
- scores_quick_grid: 5000
- regions: 1
- metadata: 12

## Totals
- targets: 600
- clusters: 416
- quick-grid cells: 14900

## Radar restrictions
- No `Target-B`: verified absent in source text.
- No `Gold Confirmed`: verified absent in source text.
- Radar remains Candidate & Field-check Engine, not final proof of gold.
- Satellite + Hybrid Map remain the only field map modes visible in the simplified UI.

## Size
- Raw project file size: 17.68 MB before ZIP compression.
- Final ZIP size is calculated after packaging in `SIZE_BUDGET_25MB_REPORT.md`.
