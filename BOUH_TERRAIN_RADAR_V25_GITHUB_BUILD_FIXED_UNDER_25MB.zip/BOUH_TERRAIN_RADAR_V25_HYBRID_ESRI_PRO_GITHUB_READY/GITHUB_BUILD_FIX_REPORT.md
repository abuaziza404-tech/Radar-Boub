# GITHUB_BUILD_FIX_REPORT.md

Date: 2026-05-31 06:51:37 UTC

## Problem addressed
The previous GitHub package could fail in CI because of fragile Gradle/SDK setup and no explicit APK size guard.

## What changed
1. Workflow now installs Android SDK platform 34 and build-tools 34.0.0.
2. Gradle 8.7 is provided by `gradle/actions/setup-gradle@v4`.
3. `gradlew` was hardened:
   - Uses `gradle` from PATH first.
   - Falls back to wrapper JAR.
   - Falls back to downloading Gradle 8.7 if needed.
4. `compileSdk` changed to 34 for stable GitHub Actions availability.
5. APK output is verified.
6. APK size must be <= 25MB.
7. Unused old assets were removed to reduce APK risk.

## Build command
```bash
./gradlew assembleDebug --no-daemon --stacktrace
```

## Expected artifact
`BOUH-Terrain-Radar-V25-Pro-Radar-Sat-Hybrid-debug-apk`

## Sandbox limitation
No APK was created here because Android SDK/Gradle are not available in this runtime.
