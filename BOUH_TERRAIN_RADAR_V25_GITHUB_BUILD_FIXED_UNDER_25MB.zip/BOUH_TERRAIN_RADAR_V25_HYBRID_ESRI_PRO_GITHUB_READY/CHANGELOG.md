# Changelog

## V25 Hybrid Esri Pro

- Added AlpineQuest-style online-to-offline tile cache.
- Added Satellite, Terrain/Topo, OSM and Carto cache layers.
- Added "save current area" and "save wider area" actions.
- Updated local MapServer to serve cached tiles first and fetch online only when needed.
- Kept V21 MBTiles radar heatmaps and true embedded radar data intact.
- Updated Android versionCode to 240 and versionName to 25.0.0-hybrid-esri-pro.
- Developer fixed as: أحمد أبوعزيزه الرشيدي / Ahmed Abu Aziza Al-Rashidi.

# Changelog

## V23 Offline Pro - 2026-05-30

- تحويل التشغيل الافتراضي إلى Offline Only باستخدام خرائط MBTiles المحلية للنطاقات الثلاثة.
- إزالة الاعتماد الواجهي على طبقات الإنترنت Satellite/OSM/Topo/Carto في قائمة الخرائط.
- إضافة إيماءات خريطة احترافية: سحب، pinch zoom، دوران بإصبعين، وتصفير الدوران بالنقر المزدوج.
- تحسين إسقاط نقاط الرادار والأهداف مع دوران الخريطة حتى تبقى المؤشرات متوافقة بصريًا.
- تثبيت اسم المطور:
  - أحمد أبوعزيزه الرشيدي
  - Ahmed Abu Aziza Al-Rashidi
- تحديث Android Bridge لإرجاع معلومات الإصدار والمطور.
- تحديث حالة الكاش لتوضح أن MBTiles المحلي هو مصدر التشغيل.
- تحديث الإصدار إلى `23.0.0-offline-pro`.

## V22 Pro

- واجهة Pro.
- إعدادات محفوظة محليًا.
- تصدير JSON/CSV.
- خط بصري لأقرب هدف.
- تجهيز GitHub Actions.
