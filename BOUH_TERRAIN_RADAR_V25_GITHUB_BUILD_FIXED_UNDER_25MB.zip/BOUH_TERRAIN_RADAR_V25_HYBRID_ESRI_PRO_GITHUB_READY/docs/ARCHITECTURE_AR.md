# Architecture - BOUH Terrain Radar V23 Offline Pro

## نظرة عامة

التطبيق عبارة عن Android WebView يشغّل واجهة HTML/JS محلية من `assets/index.html`، مع خادم محلي Java على `127.0.0.1:8765` لقراءة خرائط MBTiles المخزنة داخل التطبيق.

**المطور:** أحمد أبوعزيزه الرشيدي  
**Developer:** Ahmed Abu Aziza Al-Rashidi

## مسار البيانات

```plantuml
@startuml
actor User as U
component "Android WebView" as WV
component "index.html / JS Radar" as JS
component "MapServer :8765" as MS
database "V21 embedded data" as DATA
database "V21 MBTiles
North/Center/South" as MBT
database "SQLite assets" as DB

U --> WV : touch / GPS / scan
WV --> JS : local UI
JS --> DATA : analyze targets/grid
JS --> MS : /v21heatmap/{region}/{z}/{x}/{y}.png
MS --> MBT : query tile_data
JS --> DB : packaged reference data
@enduml
```

## الخرائط

- لا تعتمد طبقات الخرائط الأساسية في V23 على الإنترنت.
- الطبقات المتاحة:
  - `autoOffline`
  - `v21north`
  - `v21center`
  - `v21south`
- `MapServer` يعمل بوضع `OFFLINE_ONLY = true`.

## اللمس والإيماءات

- Pointer Events داخل `index.html`.
- خريطة بإصبع واحد: pan.
- خريطة بإصبعين: zoom + bearing rotation.
- تحويل إحداثيات السحب يعوض زاوية الدوران حتى يبقى التحريك طبيعيًا.
- إسقاط نقاط الرادار يطبق الدوران نفسه حول مركز الشاشة.

## الرادار

- `nearestTarget()` يبحث داخل `V21_DATA.allTargets`.
- عند وجود هدف قريب يعرض قراءة هدف مباشر.
- عند عدم وجود هدف مباشر يستخدم `nearestGrid()` من خلايا النطاق.
- لا توجد أهداف مولدة عشوائيًا.

## Android Bridge

يوفر:

- `appInfo()` لإرجاع الإصدار واسم المطور.
- `saveTextFile()` لحفظ تقارير JSON/CSV داخل مجلد التطبيق.

## إصدار Android

- `versionCode`: 230
- `versionName`: 23.0.0-offline-pro


## V24 Alpine Cache Tile Architecture

```plantuml
@startuml
actor User
participant WebView
participant MapServer
participant OnlineTileProvider
collections LocalTileCache
collections V21MBTiles

User -> WebView: فتح طبقة Satellite/Topo أثناء الإنترنت
WebView -> MapServer: /proxy/{provider}/{z}/{x}/{y}.png
MapServer -> LocalTileCache: فحص البلاطة المحفوظة
alt البلاطة موجودة
  LocalTileCache --> MapServer: tile bytes
else غير موجودة والإنترنت متاح
  MapServer -> OnlineTileProvider: تحميل البلاطة
  OnlineTileProvider --> MapServer: tile bytes
  MapServer -> LocalTileCache: حفظ البلاطة
end
MapServer --> WebView: عرض البلاطة

User -> WebView: فتح نفس المنطقة لاحقًا بدون إنترنت
WebView -> MapServer: نفس رابط البلاطة
MapServer -> LocalTileCache: قراءة محلية
MapServer --> WebView: عرض Offline

WebView -> MapServer: /v21heatmap/{region}/{z}/{x}/{y}.png
MapServer -> V21MBTiles: قراءة خرائط الرادار المحلية
V21MBTiles --> MapServer: heatmap tile
@enduml
```

