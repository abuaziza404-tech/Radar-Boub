# تقرير اختبار وإصلاح BOUH Terrain Radar V25.1

## حالة التسليم
- تم تعديل المصدر داخل المشروع الحالي.
- لم يتم إنتاج APK داخل هذه البيئة لأن أدوات Android/Gradle غير مثبتة هنا، ولا يوجد `gradlew` داخل المشروع.
- تم تحديث GitHub Actions للبناء باسم V25.1، ويمكنه إنتاج `app-debug.apk` عند رفع المشروع إلى GitHub أو تشغيله في بيئة Android SDK.

## التغييرات المنفذة
1. إزالة كل ظهور نصي لـ `الدالة العشوائية المحظورة` من ملفات المشروع.
2. تحويل قرار الرادار إلى Native Android Bridge:
   - `AndroidBridge.radarAnalyze(lat, lon)`
   - `AndroidBridge.nearestTarget(lat, lon, maxKm)`
   - `AndroidBridge.diagnostics()`
3. Decision Engine يقرأ من SQLite المحلي فقط:
   - `BOUH_V21_NORTH_MOBILE.db`
   - `BOUH_V21_CENTER_MOBILE.db`
   - `BOUH_V21_SOUTH_MOBILE.db`
4. عند القراءة يتم تحديد:
   - داخل/خارج التغطية.
   - اسم النطاق.
   - أقرب خلية/بكسل من `pixel_review_quick_grid`.
   - أقرب هدف من `targets` عند وجوده ضمن 1.1 كم.
   - المؤشرات الموجودة.
   - سبب الرفع والخفض والبيانات الناقصة.
   - قرار آمن: `Reject / HOLD / Candidate / GPZ Field Check`.
5. منع أي ترقية إلى ترقية ميدانية مؤكدة أو ذهب مؤكد دون دليل ميداني:
   - GPZ
   - sample
   - assay
   - geochem
   - field evidence
6. FeOx-only لا يرفع النتيجة إلى هدف قوي.
7. Klemm/KCL بقي مرجعاً فقط ولا يدخل في قرار الرادار.
8. فصل الخرائط/heatmap عن Decision Engine:
   - طبقات العرض ما زالت في الواجهة.
   - القرار يأتي من SQLite عبر Java فقط.
9. تحسين الأداء:
   - إيقاف تجهيز كل Heatmap MBTiles عند بدء التشغيل.
   - تحميل Heatmap MBTiles عند طلب الطبقة فقط.
   - تعطيل جلب الشبكة داخل MapServer (`OFFLINE_ONLY = true`).
   - إزالة warm cache random query.
10. إضافة شاشة تشخيص داخل التطبيق:
   - حالة قواعد البيانات.
   - عدد الأهداف.
   - عدد الخلايا.
   - حالة الخرائط.
   - آخر خطأ.

## نتائج الفحص الثابت
- الدالة العشوائية المحظورة matches: 0
- JavaScript syntax checks: OK, OK, OK
- Native SQLite bridge present: True
- MapServer offline only: True

## قواعد البيانات

### BOUH_V21_CENTER_MOBILE.db
- Region: BOUH V21 CENTER
- Bounds: (36.09832763671876, 18.443135757230912, 37.27111816406251, 20.689322775663335)
- Size: 2764800 bytes
- Targets: 200
- Cells: 4900
- Quick grid: 4900
- Clusters: 380
- Layers: 13

### BOUH_V21_NORTH_MOBILE.db
- Region: BOUH V21 NORTH Android Lite
- Bounds: (35.98495468025546, 19.508616310319184, 37.15774520759921, 21.739678698995803)
- Size: 2641920 bytes
- Targets: 200
- Cells: 5000
- Quick grid: 5000
- Clusters: 25
- Layers: 8

### BOUH_V21_SOUTH_MOBILE.db
- Region: BOUH V21 SOUTH Android Lite
- Bounds: (36.61647038303276, 16.618150998762626, 37.78926091037651, 18.888473188510254)
- Size: 2650112 bytes
- Targets: 200
- Cells: 5000
- Quick grid: 5000
- Clusters: 11
- Layers: 8

## عينة قراءة من قواعد البيانات

### BOUH_V21_CENTER_MOBILE.db
- Query: lat=19.566229, lon=36.684723
- Nearest pixel: grid=2426, row=1237, col=612, lat=19.577460, lon=36.682814
- Score: 33.9739990234375
- DB decision: Reject
- Why up: Direct pixel quick-grid: rejected by Kill Matrix / insufficient alignment.
- Why down: Reduced by high noise risk.
- Missing: Missing: GPZ/sample/assay/geochemistry; Sentinel TIFF scale reflectance not present in metadata.

### BOUH_V21_NORTH_MOBILE.db
- Query: lat=20.624148, lon=36.571350
- Nearest pixel: grid=2525, row=1258, col=618, lat=20.616562, lon=36.575167
- Score: 60.55000305175781
- DB decision: HOLD
- Why up: structure proxy high; pattern proxy high; surface/regolith support
- Why down: threshold or confirmation not enough
- Missing: GPZ/sample/assay/geochem; QA/SCL; calibrated reflectance scale

### BOUH_V21_SOUTH_MOBILE.db
- Query: lat=17.753312, lon=37.202866
- Nearest pixel: grid=2475, row=1249, col=615, lat=17.753766, lon=37.203820
- Score: 49.5
- DB decision: Low HOLD
- Why up: structure proxy high; pattern proxy high; surface/regolith support
- Why down: threshold or confirmation not enough
- Missing: GPZ/sample/assay/geochem; QA/SCL; calibrated reflectance scale

## محاولة بناء APK
تم تنفيذ محاولة `./gradlew assembleDebug`، لكنها فشلت لأن المشروع المرفوع لا يحتوي Gradle Wrapper (`gradlew`) والبيئة الحالية لا تحتوي أمر `gradle` أو Android SDK.

الأمر الذي يجب تشغيله في بيئة Android:
```bash
gradle assembleDebug --no-daemon
```

أو استخدم GitHub Actions الموجود في:
`.github/workflows/build-apk.yml`

المخرج المتوقع:
`app/build/outputs/apk/debug/app-debug.apk`

## الملفات المعدلة الأساسية
- `app/src/main/java/com/bouh/terrainradar/MainActivity.java`
- `app/src/main/java/com/bouh/terrainradar/MapServer.java`
- `app/src/main/assets/index.html`
- `app/src/main/assets/www/index.html`
- `app/build.gradle`
- `.github/workflows/build-apk.yml`

## ملاحظة صدق مهمة
لم أزعم أن APK تم بناؤه محلياً؛ هذه البيئة لا تملك أدوات Android build. المصدر المعدل جاهز للبناء في GitHub Actions أو Android Studio/Gradle محلي.
