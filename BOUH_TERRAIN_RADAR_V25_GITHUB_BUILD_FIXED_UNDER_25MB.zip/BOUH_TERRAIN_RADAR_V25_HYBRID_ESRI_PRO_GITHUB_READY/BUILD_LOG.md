# BUILD_LOG.md

Build package adjusted for GitHub Actions.

Date: 2026-05-31 06:51:37 UTC

## Fixes applied
- Repaired GitHub Actions workflow to install Android SDK 34 and Build Tools 34.0.0.
- Added Java 17 environment verification.
- Added Gradle 8.7 setup through gradle/actions/setup-gradle.
- Hardened `gradlew` so it uses Gradle from PATH first, then wrapper JAR, then download fallback.
- Reduced compileSdk/buildTools to stable 34 to avoid SDK 35 availability/toolchain mismatch.
- Added `gradle.properties` for stable CI memory and deterministic build behavior.
- Added APK size gate: build fails if `app-debug.apk` exceeds 25MB.
- Reduced assets footprint by compressing the splash image and removing unused old V13/V14/V15/V19/V20 data/UI assets.

## Local environment note
APK was not built inside this ChatGPT sandbox because Android SDK/Gradle are not installed and external Gradle download is blocked.

## Expected GitHub command
```bash
./gradlew assembleDebug --no-daemon --stacktrace
```

## Expected APK
```text
app/build/outputs/apk/debug/app-debug.apk
```
