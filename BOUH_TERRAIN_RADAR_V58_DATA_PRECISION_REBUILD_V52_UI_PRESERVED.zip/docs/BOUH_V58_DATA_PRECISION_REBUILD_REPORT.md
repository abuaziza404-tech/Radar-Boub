# BOUH V58 Data-Precision Rebuild Report

Base application preserved: V52 Final Field Command.
Changed component: SQLite radar database only (app design, HTML, Java bridge, sections and settings preserved).

## Uploaded raw data used
- BOUH_CENTER_ZONE.zip
- BOUH_NORTH_ZONE.zip
- BOUH_SOUTH_ZONE.zip

Each zone contains Sentinel-2 L2A raw TIFF bands:
B01, B02, B03, B04, B05, B06, B07, B08, B8A, B09, B11, B12.

## Ground truth note
This is a raw Sentinel-2 proxy rebuild. The uploaded zips do not contain ASTER SWIR/TIR or DEM.
Therefore silica/quartz/clay are Sentinel-2 proxy indicators, not ASTER-confirmed mineral indices.

## Grid
- Sampling step: 10 pixels.
- CENTER cells: 30750
- NORTH cells: 30750
- SOUTH cells: 30750
- Total grid cells from raw data: 92250
- Legacy field/analog anchors preserved: 3
- Final DB cell count: 92253

## Classification summary
classification  Candidate  GPZ Field Check  HOLD  Reject/Low
zone                                                        
CENTER                426               61  4676       25587
NORTH                1153              202  5532       23863
SOUTH                 399               54  4274       26023

## Decision discipline
No Structure + No Clay/Silica = Reject.
FeOx alone cannot promote a cell into Candidate or GPZ Field Check.
Water/vegetation pixels are retained as ground coverage cells but penalized and normally rejected.

## Added indicator content inside the existing indicators field
- Gossan_QI
- Quartz_QI
- Silica_QI
- Clay_SWIR_QI
- MagneticRisk
- NDVI
- NDWI

## Compatibility
The database schema is kept identical to V52:
cells(id, zone, lat, lon, row, col, classification, final_score, structure_score, alteration_score, feox_score, drainage_score, magnetic_proxy, lithology_score, historical_score, gpz_analog, model, indicators, decision_reason, source_note)

Android code, design, menus, map controls, and settings are not changed.
