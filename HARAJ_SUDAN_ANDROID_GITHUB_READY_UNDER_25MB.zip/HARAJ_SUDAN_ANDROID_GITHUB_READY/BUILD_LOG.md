# BUILD_LOG.md

تم إنشاء مشروع Android مستقل باسم حراج السودان.

## البيئة المستهدفة للبناء

- GitHub Actions
- Java 17
- Android SDK
- Gradle 8.7 manual install
- Android Gradle Plugin 8.5.2
- compileSdk 34

## أمر البناء

```bash
./gradlew assembleDebug --no-daemon --stacktrace
```

أو عبر workflow:

`.github/workflows/build-apk.yml`

## ملاحظة

لم يتم إنتاج APK داخل بيئة ChatGPT بسبب عدم توفر Android SDK/Gradle محليًا.
