package com.abuaziza.kidsarabicai;

import android.annotation.SuppressLint;
import android.app.*;
import android.os.*;
import android.content.*;
import android.webkit.*;
import android.speech.tts.TextToSpeech;
import org.json.*;
import java.util.*;

public class MainActivity extends Activity implements TextToSpeech.OnInitListener {
    WebView web;
    TextToSpeech tts;
    SharedPreferences prefs;

    final String[] letters = {
        "أ|ألف", "ب|باء", "ت|تاء", "ث|ثاء", "ج|جيم", "ح|حاء", "خ|خاء",
        "د|دال", "ذ|ذال", "ر|راء", "ز|زاي", "س|سين", "ش|شين", "ص|صاد",
        "ض|ضاد", "ط|طاء", "ظ|ظاء", "ع|عين", "غ|غين", "ف|فاء", "ق|قاف",
        "ك|كاف", "ل|لام", "م|ميم", "ن|نون", "ه|هاء", "و|واو", "ي|ياء"
    };

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("kids_ai", MODE_PRIVATE);
        tts = new TextToSpeech(this, this);

        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        if (Build.VERSION.SDK_INT >= 21) s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);

        web.addJavascriptInterface(new Bridge(), "KIDS");
        web.setWebViewClient(new WebViewClient());
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
            tts.setLanguage(new Locale("ar"));
            tts.setSpeechRate(0.80f);
        }
    }

    @Override protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }

    String girlPrompt(String letter, String name) {
        return "يا حمدة حامد قولي " + letter + ". " + name + ". أحسنتِ يا حمدة.";
    }

    String boyPrompt(String letter, String name) {
        return "يا حميد حامد قول " + name + ". " + letter + ". أحسنت يا حميد.";
    }

    String girlAllLetters() {
        StringBuilder sb = new StringBuilder("يا حمدة حامد قولي: ");
        for (String item: letters) {
            String[] p = item.split("\\|");
            sb.append(p[0]).append("، ").append(p[1]).append(". ");
        }
        sb.append("ممتاز يا حمدة.");
        return sb.toString();
    }

    String boyAllLetters() {
        StringBuilder sb = new StringBuilder("يا حميد حامد قول: ");
        for (String item: letters) {
            String[] p = item.split("\\|");
            sb.append(p[1]).append(". ").append(p[0]).append(". ");
        }
        sb.append("ممتاز يا حميد.");
        return sb.toString();
    }

    void speak(String text, String teacher) {
        if (tts == null || text == null) return;
        if ("girlTeacher".equals(teacher)) {
            tts.setPitch(1.28f);
            tts.setSpeechRate(0.78f);
        } else {
            tts.setPitch(0.82f);
            tts.setSpeechRate(0.80f);
        }
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "lesson_" + System.currentTimeMillis());
    }

    String assistantAnswer(String q, String teacher) {
        q = q == null ? "" : q.trim().toLowerCase(Locale.ROOT);
        if (q.contains("الحروف") || q.contains("أ ب") || q.contains("ابجد")) return "girlTeacher".equals(teacher) ? girlAllLetters() : boyAllLetters();
        if (q.contains("رقم") || q.contains("أرقام") || q.contains("الارقام")) return "الأرقام: واحد، اثنان، ثلاثة، أربعة، خمسة، ستة، سبعة، ثمانية، تسعة، عشرة.";
        if (q.contains("كلمة") || q.contains("كلمات")) return "كلمات قصيرة: أسد، باب، تمر، ثوب، جمل، حصان، خروف، دجاجة.";
        if (q.contains("حركة") || q.contains("الحركات")) return "الحركات: فتحة، ضمة، كسرة، سكون. أَ، أُ، إِ، أْ.";
        if (q.contains("اختبار")) return "اختبار: ما الحرف بعد باء؟ الجواب تاء. وما الحرف بعد جيم؟ الجواب حاء.";
        if (q.contains("خطة") || q.contains("مراحل")) return "الخطة: الحروف، ثم الحركات، ثم الكلمات، ثم الأرقام، ثم الجمل، ثم القصص.";
        return "أنا المعلم الذكي. أستطيع تعليم الحروف والأرقام والكلمات والحركات والجمل. اختر المعلمة حمدة أو المعلم حميد.";
    }

    public class Bridge {
        @JavascriptInterface public String getLetters() {
            try {
                JSONArray arr = new JSONArray();
                for (int i=0; i<letters.length; i++) {
                    String[] p = letters[i].split("\\|");
                    JSONObject o = new JSONObject();
                    o.put("index", i);
                    o.put("letter", p[0]);
                    o.put("name", p[1]);
                    o.put("example", exampleFor(p[0]));
                    arr.put(o);
                }
                return arr.toString();
            } catch(Exception e) { return "[]"; }
        }

        @JavascriptInterface public void speakLetter(int index, String teacher) {
            if (index < 0 || index >= letters.length) return;
            String[] p = letters[index].split("\\|");
            String text = "girlTeacher".equals(teacher) ? girlPrompt(p[0], p[1]) : boyPrompt(p[0], p[1]);
            speak(text, teacher);
        }

        @JavascriptInterface public void speakAll(String teacher) {
            speak("girlTeacher".equals(teacher) ? girlAllLetters() : boyAllLetters(), teacher);
        }

        @JavascriptInterface public String ask(String q, String teacher) { return assistantAnswer(q, teacher); }

        @JavascriptInterface public void speak(String text, String teacher) { MainActivity.this.speak(text, teacher); }

        @JavascriptInterface public void saveProgress(int index, int stars) { prefs.edit().putInt("last_index", index).putInt("stars", stars).apply(); }

        @JavascriptInterface public String getProgress() {
            try {
                JSONObject o = new JSONObject();
                o.put("last_index", prefs.getInt("last_index", 0));
                o.put("stars", prefs.getInt("stars", 0));
                return o.toString();
            } catch(Exception e) { return "{}"; }
        }
    }

    String exampleFor(String letter) {
        if (letter.equals("أ")) return "أسد";
        if (letter.equals("ب")) return "باب";
        if (letter.equals("ت")) return "تمر";
        if (letter.equals("ث")) return "ثوب";
        if (letter.equals("ج")) return "جمل";
        if (letter.equals("ح")) return "حصان";
        if (letter.equals("خ")) return "خروف";
        if (letter.equals("د")) return "دجاجة";
        if (letter.equals("ذ")) return "ذرة";
        if (letter.equals("ر")) return "رمان";
        if (letter.equals("ز")) return "زهرة";
        if (letter.equals("س")) return "سمكة";
        if (letter.equals("ش")) return "شمس";
        if (letter.equals("ص")) return "صقر";
        if (letter.equals("ض")) return "ضفدع";
        if (letter.equals("ط")) return "طائرة";
        if (letter.equals("ظ")) return "ظرف";
        if (letter.equals("ع")) return "عين";
        if (letter.equals("غ")) return "غزال";
        if (letter.equals("ف")) return "فيل";
        if (letter.equals("ق")) return "قمر";
        if (letter.equals("ك")) return "كتاب";
        if (letter.equals("ل")) return "ليمون";
        if (letter.equals("م")) return "موز";
        if (letter.equals("ن")) return "نخلة";
        if (letter.equals("ه")) return "هدهد";
        if (letter.equals("و")) return "وردة";
        if (letter.equals("ي")) return "يد";
        return "";
    }
}
