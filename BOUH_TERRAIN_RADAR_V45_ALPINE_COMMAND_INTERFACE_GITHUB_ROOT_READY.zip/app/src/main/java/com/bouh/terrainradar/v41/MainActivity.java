package com.bouh.terrainradar.v41;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class MainActivity extends Activity implements SensorEventListener, TextToSpeech.OnInitListener {
    private WebView web;
    private final ArrayList<Cell> cells = new ArrayList<>();
    private SensorManager sensorManager;
    private Sensor accelerometer;
    private Sensor gyroscope;
    private Sensor lightSensor;
    private TextToSpeech textToSpeech;
    private float ax = 0f, ay = 0f, az = 0f, gx = 0f, gy = 0f, gz = 0f, lux = -1f;
    private File databaseFile;
    private static final int REQ_PICK_KML = 2001;

    static class Cell {
        String id = "";
        String zone = "";
        String classification = "";
        String model = "";
        String indicators = "";
        String reason = "";
        String source = "";
        double lat;
        double lon;
        int row;
        int col;
        int score;
        int structure;
        int alteration;
        int feox;
        int drainage;
        int magnetic;
        int lithology;
        int historical;
        int gpz;
    }

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestLocationPermissions();
        loadDb();
        setupSensors();
        textToSpeech = new TextToSpeech(this, this);
        web = new WebView(this);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        if (Build.VERSION.SDK_INT >= 16) {
            settings.setAllowFileAccessFromFileURLs(true);
            settings.setAllowUniversalAccessFromFileURLs(true);
        }
        if (Build.VERSION.SDK_INT >= 21) {
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        }
        if (Build.VERSION.SDK_INT >= 26) {
            WebView.setSafeBrowsingWhitelist(new ArrayList<String>(), null);
        }
        web.addJavascriptInterface(new Bridge(), "BOUH");
        web.setWebViewClient(new SafeClient());
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
        log("APP_START cells=" + cells.size());
    }

    private void requestLocationPermissions() {
        if (Build.VERSION.SDK_INT >= 23) {
            requestPermissions(new String[]{
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
            }, 10);
        }
    }

    private void setupSensors() {
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        if (sensorManager != null) {
            accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
            gyroscope = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
            lightSensor = sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT);
        }
    }

    static class SafeClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            if (url == null) return true;
            if (url.startsWith("file:///android_asset/")) return false;
            if (url.startsWith("https://")) return false;
            return true;
        }
    }

    @Override
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS && textToSpeech != null) {
            try {
                textToSpeech.setLanguage(new Locale("ar"));
            } catch (Exception ignored) {
            }
            textToSpeech.setSpeechRate(0.93f);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        startSensors();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (sensorManager != null) sensorManager.unregisterListener(this);
    }

    @Override
    protected void onDestroy() {
        if (textToSpeech != null) {
            textToSpeech.stop();
            textToSpeech.shutdown();
        }
        super.onDestroy();
    }

    private void startSensors() {
        if (sensorManager == null) return;
        if (accelerometer != null) sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
        if (gyroscope != null) sensorManager.registerListener(this, gyroscope, SensorManager.SENSOR_DELAY_NORMAL);
        if (lightSensor != null) sensorManager.registerListener(this, lightSensor, SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            ax = event.values[0];
            ay = event.values[1];
            az = event.values[2];
        } else if (event.sensor.getType() == Sensor.TYPE_GYROSCOPE) {
            gx = event.values[0];
            gy = event.values[1];
            gz = event.values[2];
        } else if (event.sensor.getType() == Sensor.TYPE_LIGHT) {
            lux = event.values[0];
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }

    private void loadDb() {
        try {
            databaseFile = new File(getFilesDir(), "BOUH_V30_REAL_3ZONES.db");
            if (!databaseFile.exists()) {
                InputStream inputStream = getAssets().open("databases/BOUH_V30_REAL_3ZONES.db");
                FileOutputStream fileOutputStream = new FileOutputStream(databaseFile);
                byte[] buffer = new byte[8192];
                int length;
                while ((length = inputStream.read(buffer)) > 0) fileOutputStream.write(buffer, 0, length);
                fileOutputStream.close();
                inputStream.close();
            }
            SQLiteDatabase database = SQLiteDatabase.openDatabase(databaseFile.getAbsolutePath(), null, SQLiteDatabase.OPEN_READONLY);
            Cursor cursor = database.rawQuery("SELECT id,zone,lat,lon,row,col,classification,final_score,structure_score,alteration_score,feox_score,drainage_score,magnetic_proxy,lithology_score,historical_score,gpz_analog,model,indicators,decision_reason,source_note FROM cells", null);
            while (cursor.moveToNext()) {
                Cell cell = new Cell();
                cell.id = safeString(cursor, 0);
                cell.zone = safeString(cursor, 1);
                cell.lat = cursor.getDouble(2);
                cell.lon = cursor.getDouble(3);
                cell.row = cursor.getInt(4);
                cell.col = cursor.getInt(5);
                cell.classification = safeString(cursor, 6);
                cell.score = cursor.getInt(7);
                cell.structure = cursor.getInt(8);
                cell.alteration = cursor.getInt(9);
                cell.feox = cursor.getInt(10);
                cell.drainage = cursor.getInt(11);
                cell.magnetic = cursor.getInt(12);
                cell.lithology = cursor.getInt(13);
                cell.historical = cursor.getInt(14);
                cell.gpz = cursor.getInt(15);
                cell.model = safeString(cursor, 16);
                cell.indicators = safeString(cursor, 17);
                cell.reason = safeString(cursor, 18);
                cell.source = safeString(cursor, 19);
                cells.add(cell);
            }
            cursor.close();
            database.close();
        } catch (Exception exception) {
            log("DB_LOAD_ERROR " + exception.getMessage());
        }
    }

    private String safeString(Cursor cursor, int index) {
        return cursor.isNull(index) ? "" : cursor.getString(index);
    }

    private double dist(double lat1, double lon1, double lat2, double lon2) {
        double earth = 6371000.0;
        double phi1 = Math.toRadians(lat1);
        double phi2 = Math.toRadians(lat2);
        double dPhi = Math.toRadians(lat2 - lat1);
        double dLambda = Math.toRadians(lon2 - lon1);
        double value = Math.sin(dPhi / 2) * Math.sin(dPhi / 2) + Math.cos(phi1) * Math.cos(phi2) * Math.sin(dLambda / 2) * Math.sin(dLambda / 2);
        return earth * 2 * Math.atan2(Math.sqrt(value), Math.sqrt(1 - value));
    }

    private double bearing(double lat1, double lon1, double lat2, double lon2) {
        double phi1 = Math.toRadians(lat1);
        double phi2 = Math.toRadians(lat2);
        double lambda = Math.toRadians(lon2 - lon1);
        double y = Math.sin(lambda) * Math.cos(phi2);
        double x = Math.cos(phi1) * Math.sin(phi2) - Math.sin(phi1) * Math.cos(phi2) * Math.cos(lambda);
        return (Math.toDegrees(Math.atan2(y, x)) + 360.0) % 360.0;
    }

    private String directionName(double bearing) {
        String[] names = {"شمال", "شمال شرق", "شرق", "جنوب شرق", "جنوب", "جنوب غرب", "غرب", "شمال غرب"};
        int index = (int) Math.round(bearing / 45.0) % 8;
        return names[index];
    }

    private String readTextFromUri(Uri uri) throws Exception {
        InputStream inputStream = getContentResolver().openInputStream(uri);
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        byte[] buffer = new byte[8192];
        int length;
        while ((length = inputStream.read(buffer)) > 0) outputStream.write(buffer, 0, length);
        inputStream.close();
        return outputStream.toString("UTF-8");
    }

    private String readKmlFromKmz(Uri uri) throws Exception {
        InputStream inputStream = getContentResolver().openInputStream(uri);
        ZipInputStream zipInputStream = new ZipInputStream(inputStream);
        ZipEntry entry;
        while ((entry = zipInputStream.getNextEntry()) != null) {
            String name = entry.getName() == null ? "" : entry.getName().toLowerCase(Locale.ROOT);
            if (name.endsWith(".kml")) {
                ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                byte[] buffer = new byte[8192];
                int length;
                while ((length = zipInputStream.read(buffer)) > 0) outputStream.write(buffer, 0, length);
                zipInputStream.close();
                inputStream.close();
                return outputStream.toString("UTF-8");
            }
        }
        zipInputStream.close();
        inputStream.close();
        return "";
    }

    private void sendImportResult(final String name, final String text, final String error) {
        runOnUiThread(() -> {
            try {
                JSONObject result = new JSONObject();
                result.put("ok", error == null || error.isEmpty());
                result.put("name", name == null ? "" : name);
                result.put("content", text == null ? "" : text);
                result.put("error", error == null ? "" : error);
                String javascript = "window.onNativeImport && window.onNativeImport(" + JSONObject.quote(result.toString()) + ")";
                web.evaluateJavascript(javascript, null);
            } catch (Exception exception) {
                log("IMPORT_CALLBACK_ERROR " + exception.getMessage());
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_PICK_KML) return;
        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            sendImportResult("", "", "لم يتم اختيار ملف");
            return;
        }
        Uri uri = data.getData();
        try {
            getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) {
        }
        try {
            String name = "imported";
            Cursor cursor = getContentResolver().query(uri, null, null, null, null);
            if (cursor != null) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (cursor.moveToFirst() && index >= 0) name = cursor.getString(index);
                cursor.close();
            }
            String lowerName = name.toLowerCase(Locale.ROOT);
            String text = lowerName.endsWith(".kmz") ? readKmlFromKmz(uri) : readTextFromUri(uri);
            if (text == null || text.trim().isEmpty()) sendImportResult(name, "", "تعذر قراءة KML/KMZ أو الملف فارغ");
            else sendImportResult(name, text, "");
        } catch (Exception exception) {
            sendImportResult("", "", exception.getMessage());
        }
    }

    private boolean isOnline() {
        try {
            ConnectivityManager manager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            if (manager == null) return false;
            if (Build.VERSION.SDK_INT >= 23) {
                NetworkCapabilities capabilities = manager.getNetworkCapabilities(manager.getActiveNetwork());
                return capabilities != null && (
                        capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ||
                                capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                                capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
                );
            }
            NetworkInfo info = manager.getActiveNetworkInfo();
            return info != null && info.isConnected();
        } catch (Exception exception) {
            return false;
        }
    }

    private void log(String message) {
        try {
            File dir = new File(getFilesDir(), "logs");
            if (!dir.exists()) dir.mkdirs();
            File logFile = new File(dir, "bouh_field.log");
            String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date());
            String line = timestamp + " | " + message + "\n";
            FileOutputStream outputStream = new FileOutputStream(logFile, true);
            outputStream.write(line.getBytes(StandardCharsets.UTF_8));
            outputStream.close();
        } catch (Exception ignored) {
        }
    }

    private JSONObject cellToJson(Cell cell, double fromLat, double fromLon) throws Exception {
        double distance = dist(fromLat, fromLon, cell.lat, cell.lon);
        double azimuth = bearing(fromLat, fromLon, cell.lat, cell.lon);
        JSONObject object = new JSONObject();
        object.put("id", cell.id);
        object.put("zone", cell.zone);
        object.put("lat", cell.lat);
        object.put("lon", cell.lon);
        object.put("classification", cell.classification);
        object.put("score", cell.score);
        object.put("distance_m", Math.round(distance));
        object.put("bearing", Math.round(azimuth));
        object.put("direction", directionName(azimuth));
        object.put("structure", cell.structure);
        object.put("alteration", cell.alteration);
        object.put("feox", cell.feox);
        object.put("drainage", cell.drainage);
        object.put("magnetic", cell.magnetic);
        object.put("lithology", cell.lithology);
        object.put("historical", cell.historical);
        object.put("gpz", cell.gpz);
        object.put("reason", cell.reason);
        return object;
    }

    public class Bridge {
        @JavascriptInterface
        public String cells() {
            try {
                JSONArray array = new JSONArray();
                int added = 0;
                for (Cell cell : cells) {
                    boolean important = cell.score >= 74 || cell.gpz >= 70 || cell.classification.contains("GPZ") || cell.id.startsWith("ARB_") || cell.id.startsWith("A1_") || cell.id.startsWith("A2_") || cell.id.startsWith("A6_");
                    if (!important) continue;
                    JSONObject object = new JSONObject();
                    object.put("id", cell.id);
                    object.put("zone", cell.zone);
                    object.put("lat", cell.lat);
                    object.put("lon", cell.lon);
                    object.put("classification", cell.classification);
                    object.put("score", cell.score);
                    object.put("gpz", cell.gpz);
                    array.put(object);
                    added++;
                    if (added >= 900) break;
                }
                return array.toString();
            } catch (Exception exception) {
                log("CELLS_ERROR " + exception.getMessage());
                return "[]";
            }
        }

        @JavascriptInterface
        public String dbSummary() {
            try {
                JSONObject object = new JSONObject();
                object.put("cells", cells.size());
                object.put("dbPath", databaseFile == null ? "" : databaseFile.getAbsolutePath());
                object.put("dbBytes", databaseFile == null || !databaseFile.exists() ? 0 : databaseFile.length());
                int gpz = 0, candidate = 0, hold = 0, low = 0;
                for (Cell cell : cells) {
                    if (cell.classification.contains("GPZ")) gpz++;
                    else if (cell.classification.contains("Candidate")) candidate++;
                    else if (cell.classification.contains("HOLD")) hold++;
                    else low++;
                }
                object.put("gpz", gpz);
                object.put("candidate", candidate);
                object.put("hold", hold);
                object.put("low", low);
                return object.toString();
            } catch (Exception exception) {
                return "{}";
            }
        }

        @JavascriptInterface
        public String fieldStatus() {
            try {
                JSONObject object = new JSONObject();
                object.put("online", isOnline());
                object.put("gpsPermission", Build.VERSION.SDK_INT < 23 || checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED);
                object.put("databaseReady", cells.size() > 0);
                object.put("cells", cells.size());
                object.put("accelerometer", accelerometer != null);
                object.put("gyroscope", gyroscope != null);
                object.put("light", lightSensor != null);
                object.put("exportDir", getExternalFilesDir(null) == null ? getFilesDir().getAbsolutePath() : getExternalFilesDir(null).getAbsolutePath());
                return object.toString();
            } catch (Exception exception) {
                return "{\"online\":false}";
            }
        }

        @JavascriptInterface
        public String analyze(double lat, double lon) {
            try {
                Cell best = null;
                double bestDistance = Double.MAX_VALUE;
                for (Cell cell : cells) {
                    if (Math.abs(cell.lat - lat) > 0.08 || Math.abs(cell.lon - lon) > 0.08) continue;
                    double distance = dist(lat, lon, cell.lat, cell.lon);
                    if (distance < bestDistance) {
                        bestDistance = distance;
                        best = cell;
                    }
                }
                if (best == null) {
                    for (Cell cell : cells) {
                        double distance = dist(lat, lon, cell.lat, cell.lon);
                        if (distance < bestDistance) {
                            bestDistance = distance;
                            best = cell;
                        }
                    }
                }
                JSONObject object = new JSONObject();
                object.put("lat", lat);
                object.put("lon", lon);
                if (best == null) {
                    object.put("status", "NO_DB");
                    return object.toString();
                }
                double distanceFactor = bestDistance <= 60 ? 1.0 : bestDistance <= 150 ? 0.95 : bestDistance <= 300 ? 0.88 : bestDistance <= 700 ? 0.75 : bestDistance <= 1500 ? 0.60 : bestDistance <= 5000 ? 0.42 : 0.20;
                double weighted = .25 * best.structure + .20 * best.alteration + .15 * best.feox + .15 * best.drainage + .10 * best.magnetic + .10 * best.lithology + .05 * best.historical;
                double boost = best.gpz >= 90 ? 8 : best.gpz >= 70 ? 5 : best.gpz >= 50 ? 2 : 0;
                int finalScore = (int) Math.round(Math.min(100, weighted * distanceFactor + boost));
                String classification = bestDistance > 5000 ? "Outside Coverage / HOLD" : finalScore >= 85 && (best.gpz >= 60 || (best.structure >= 70 && best.alteration >= 70)) ? "GPZ Field Check" : finalScore >= 74 ? "Candidate" : finalScore >= 52 ? "HOLD" : "Reject/Low";
                if (best.feox >= 80 && best.structure < 40 && best.alteration < 40) {
                    classification = "HOLD";
                    finalScore = Math.min(finalScore, 55);
                }
                String confidence = finalScore >= 85 && bestDistance <= 300 && best.structure >= 65 && best.alteration >= 55 ? "HIGH" : finalScore >= 74 && bestDistance <= 700 ? "MEDIUM" : finalScore >= 52 ? "LOW" : "VERY_LOW";
                double azimuth = bearing(lat, lon, best.lat, best.lon);
                object.put("status", bestDistance <= 5000 ? "INSIDE_NEAREST_CELL" : "OUTSIDE_COVERAGE");
                object.put("distance_m", Math.round(bestDistance));
                object.put("bearing", Math.round(azimuth));
                object.put("direction", directionName(azimuth));
                object.put("nearest_id", best.id);
                object.put("nearest_lat", best.lat);
                object.put("nearest_lon", best.lon);
                object.put("zone", best.zone);
                object.put("row", best.row);
                object.put("col", best.col);
                object.put("classification", classification);
                object.put("confidence", confidence);
                object.put("final_score", finalScore);
                object.put("raw_cell_score", best.score);
                object.put("structure", best.structure);
                object.put("alteration", best.alteration);
                object.put("feox", best.feox);
                object.put("drainage", best.drainage);
                object.put("magnetic", best.magnetic);
                object.put("lithology", best.lithology);
                object.put("historical", best.historical);
                object.put("gpz", best.gpz);
                object.put("model", best.model);
                object.put("indicators", best.indicators);
                object.put("reason", bestDistance > 5000 ? "النقطة بعيدة عن أقرب خلية محلية؛ النتيجة HOLD حتى تدخل نطاق التغطية أو تضيف قاعدة أدق." : best.reason);
                object.put("source", best.source);
                object.put("truth", "Field-check / Prospectivity only. No confirmed gold without GPZ/recovered gold/assay/QAQC.");
                object.put("gpz_strategy", gpz(best));
                log("ANALYZE lat=" + lat + " lon=" + lon + " id=" + best.id + " score=" + finalScore + " distance=" + Math.round(bestDistance));
                return object.toString();
            } catch (Exception exception) {
                log("ANALYZE_ERROR " + exception.getMessage());
                return "{\"status\":\"ERROR\",\"message\":\"" + exception.getMessage() + "\"}";
            }
        }

        @JavascriptInterface
        public String nearestTargets(double lat, double lon, int limit, int minScore, String filter) {
            try {
                ArrayList<Cell> pool = new ArrayList<>();
                String lowerFilter = filter == null ? "" : filter.toLowerCase(Locale.ROOT);
                for (Cell cell : cells) {
                    if (cell.score < minScore && cell.gpz < minScore) continue;
                    if (!lowerFilter.isEmpty() && !cell.classification.toLowerCase(Locale.ROOT).contains(lowerFilter)) continue;
                    pool.add(cell);
                }
                pool.sort((a, b) -> Double.compare(dist(lat, lon, a.lat, a.lon), dist(lat, lon, b.lat, b.lon)));
                JSONArray array = new JSONArray();
                int max = Math.max(1, Math.min(limit, 50));
                for (int i = 0; i < Math.min(max, pool.size()); i++) {
                    array.put(cellToJson(pool.get(i), lat, lon));
                }
                return array.toString();
            } catch (Exception exception) {
                log("TARGETS_ERROR " + exception.getMessage());
                return "[]";
            }
        }

        private String gpz(Cell cell) {
            if (cell.magnetic >= 65 || cell.feox >= 70) return "Ground Type: Difficult/Severe عند الضجيج، Gold Mode: High Yield، Sensitivity 8–11، Swing بطيء، Ground Balance متكرر.";
            if (cell.alteration >= 70 && cell.structure >= 65) return "إذا الأرض هادئة: Ground Normal، General/Deep للمقارنة، Sensitivity 12–16 تدريجياً، Audio Smoothing Off.";
            return "ابدأ High Yield + Difficult، ثم قارن Normal/General إذا الضجيج منخفض. لا تحفر إلا إشارة متكررة من اتجاهين.";
        }

        @JavascriptInterface
        public String gps() {
            try {
                LocationManager locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
                if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    return "{\"ok\":false,\"message\":\"إذن GPS غير مفعل\"}";
                }
                Location location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                if (location == null) location = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                if (location == null) return "{\"ok\":false,\"message\":\"لم يتم العثور على موقع GPS\"}";
                JSONObject object = new JSONObject();
                object.put("ok", true);
                object.put("lat", location.getLatitude());
                object.put("lon", location.getLongitude());
                object.put("alt", location.hasAltitude() ? location.getAltitude() : -9999);
                object.put("acc", location.hasAccuracy() ? location.getAccuracy() : -1);
                object.put("provider", location.getProvider());
                object.put("time", location.getTime());
                return object.toString();
            } catch (Exception exception) {
                return "{\"ok\":false,\"message\":\"" + exception.getMessage() + "\"}";
            }
        }

        @JavascriptInterface
        public String sensors() {
            try {
                JSONObject object = new JSONObject();
                object.put("ax", ax);
                object.put("ay", ay);
                object.put("az", az);
                object.put("gx", gx);
                object.put("gy", gy);
                object.put("gz", gz);
                object.put("lux", lux);
                object.put("motion", Math.sqrt(ax * ax + ay * ay + az * az));
                return object.toString();
            } catch (Exception exception) {
                return "{}";
            }
        }

        @JavascriptInterface
        public void speak(String text) {
            if (textToSpeech != null && text != null) textToSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, null, "bouh");
        }

        @JavascriptInterface
        public void pickKmlKmz() {
            runOnUiThread(() -> {
                try {
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("*/*");
                    intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                            "application/vnd.google-earth.kml+xml",
                            "application/vnd.google-earth.kmz",
                            "text/xml",
                            "application/xml",
                            "application/octet-stream"
                    });
                    startActivityForResult(intent, REQ_PICK_KML);
                } catch (Exception exception) {
                    sendImportResult("", "", exception.getMessage());
                }
            });
        }

        @JavascriptInterface
        public String writeExport(String filename, String content) {
            try {
                String safeName = filename == null ? "bouh_export.txt" : filename.replaceAll("[^A-Za-z0-9._\\-]", "_");
                File dir = getExternalFilesDir(null);
                if (dir == null) dir = getFilesDir();
                File exports = new File(dir, "exports");
                if (!exports.exists()) exports.mkdirs();
                File file = new File(exports, safeName);
                FileOutputStream outputStream = new FileOutputStream(file);
                outputStream.write((content == null ? "" : content).getBytes(StandardCharsets.UTF_8));
                outputStream.close();
                JSONObject object = new JSONObject();
                object.put("ok", true);
                object.put("path", file.getAbsolutePath());
                object.put("bytes", file.length());
                log("EXPORT " + file.getAbsolutePath());
                return object.toString();
            } catch (Exception exception) {
                log("EXPORT_ERROR " + exception.getMessage());
                return "{\"ok\":false,\"message\":\"" + exception.getMessage() + "\"}";
            }
        }

        @JavascriptInterface
        public String readLogs() {
            try {
                File file = new File(new File(getFilesDir(), "logs"), "bouh_field.log");
                if (!file.exists()) return "";
                InputStream inputStream = new java.io.FileInputStream(file);
                ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                byte[] buffer = new byte[8192];
                int length;
                while ((length = inputStream.read(buffer)) > 0) outputStream.write(buffer, 0, length);
                inputStream.close();
                return outputStream.toString("UTF-8");
            } catch (Exception exception) {
                return "";
            }
        }

        @JavascriptInterface
        public String ask(String question) {
            String q = question == null ? "" : question.toLowerCase(Locale.ROOT);
            if (q.matches(".*\\d{1,2}\\.\\d+.*\\d{1,3}\\.\\d+.*")) return "ضع الإحداثية في خيار إنشاء موقع/إحداثية أو حرّك المؤشر على الخريطة ثم افتح تحليل الرادار.";
            if (q.contains("قريب") || q.contains("أقرب")) return "افتح لوحة أهدافي ثم اضغط أقرب 10 أهداف؛ سأرتبها حسب المسافة والاتجاه والدرجة.";
            if (q.contains("تقرير") || q.contains("csv") || q.contains("kml")) return "من لوحة أهدافي يمكنك تصدير CSV/KML/GeoJSON، ومن السجل يمكنك تصدير مسار الجولة.";
            if (q.contains("gpz") || q.contains("7000")) return "إعداد GPZ: إذا الضجيج عالي أو الأرض مغناطيسية استخدم Difficult/Severe + High Yield + Sensitivity 8–11. إذا الأرض أهدأ ومع كوارتز استخدم Normal + General/Deep + Sensitivity 12–16.";
            if (q.contains("feox") || q.contains("حديد")) return "FeOx وحده HOLD. لا يُرفع كهدف قوي إلا مع Structure + Pattern + Alteration أو دليل GPZ/ميداني.";
            if (q.contains("ذهب") || q.contains("مؤكد")) return "التطبيق لا يعطي ذهباً مؤكداً. الناتج Candidate / HOLD / GPZ Field Check فقط حتى الإثبات الميداني.";
            if (q.contains("kml") || q.contains("kmz")) return "من زر العلم يمكنك استيراد KML/KMZ ثم عرض النقاط والمسارات على الخريطة.";
            return "أنا مساعد بوح. أعطني إحداثية أو صف الأرض، وسأطبق Structure → Pattern → Alteration → Confirmation → Decision مع الحوكمة: لا Target-B ولا ذهب مؤكد دون دليل ميداني.";
        }
    }
}
