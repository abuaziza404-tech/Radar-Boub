# بوح التضاريس V45 Alpine Command Interface

هذه الحزمة جاهزة للرفع إلى GitHub Actions وبناء APK مباشرة.

## أهم تطويرات V45
- رفع الإصدار الداخلي إلى `versionCode 44` و `versionName 45.0.0-alpine-command-interface`.
- تثبيت اسم التطبيق الظاهر بعد التثبيت: **بوح التضاريس**.
- تحديث GitHub Actions ليبحث عن حزمة V45 فقط ويعرض اسم V45 في صفحة Actions.
- إضافة فحص جاهزية الميدان V45:
  - GPS
  - قاعدة البيانات
  - الإنترنت / Offline
  - الأهداف المحفوظة
  - نقاط المسار
  - حالة التصدير
- إضافة خطة مهمة ذكية V45 ترتب الأهداف حسب الدرجة ثم القرب.
- إضافة خريطة حرارية Heatmap للنتائج من قاعدة الخلايا.
- إضافة تقرير HTML احترافي قابل للمشاركة بجانب JSON/CSV/KML/GPX/GeoJSON.
- تحسين رسائل الواجهة لتعرض V45 Alpine Command Interface.
- الحفاظ على بنية WebView + Android Bridge الحالية لتثبيت التطوير بسرعة دون كسر النظام.

## طريقة الرفع إلى GitHub
1. ارفع هذا الملف في جذر المستودع:
   `BOUH_TERRAIN_RADAR_V45_PRO_FIELD_INTELLIGENCE_GITHUB_ROOT_READY.zip`
2. أنشئ الملف:
   `.github/workflows/build-apk.yml`
3. استخدم ملف workflow الموجود داخل الحزمة أو انسخ محتواه من `.github/workflows/build-apk.yml`.
4. ادخل تبويب Actions وشغل:
   `Build BOUH Terrain Radar V45 APK`

## ملاحظة
`applicationId` بقي كما هو `com.bouh.terrainradar.v41` حتى يمكن تثبيت V45 كتحديث فوق النسخ السابقة. الاسم الظاهر للمستخدم هو **بوح التضاريس**.

## V45 Alpine Command Interface
- تطبيق الواجهة المطلوبة بصرياً: بطاقة إحداثيات علوية، شريحة هوية بوح التضاريس، رادار ثلاثي الحلقات، ملخص رادار دائم، وشريط أوامر سفلي عربي.
- تحديث حي للـ Score / Structure / Alteration / FeOx / Drainage من قاعدة البيانات.
- HUD ميداني: UTM تقريبي، ارتفاع، دقة GPS، وحالة Online/Offline.
- الإبقاء على أنظمة الأهداف والمسارات والتصدير والتقارير وHeatmap وKML/GPX/CSV/GeoJSON/HTML.
