package com.bouh.medicalai.v2;

import android.Manifest;
import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import android.text.method.ScrollingMovementMethod;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    final int BG = Color.rgb(6,17,31);
    final int CARD = Color.rgb(13,33,55);
    final int FIELD = Color.rgb(18,45,72);
    final int CYAN = Color.rgb(25,167,206);
    final int GREEN = Color.rgb(85,190,120);
    final int AMBER = Color.rgb(255,183,77);
    final int RED = Color.rgb(239,83,80);
    final int WHITE = Color.WHITE;

    LinearLayout root, content;
    TextView title, output, chatLog, historyBox;
    EditText age, temp, pulse, spo2, rr, sbp, dbp, glucose, pain, symptoms, chatInput, endpoint, key, model;
    Button homeBtn, examBtn, chestBtn, chatBtn, histBtn, settingsBtn, analyzeBtn, sendBtn, saveBtn, clearHistoryBtn, breathBtn;
    SharedPreferences prefs;
    Handler handler = new Handler();

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("bouh_med_v2", MODE_PRIVATE);
        if (Build.VERSION.SDK_INT >= 23) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 10);
        }
        showHome();
    }

    TextView tv(String s, int sp, int color, int style) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(sp);
        v.setTextColor(color);
        v.setTypeface(Typeface.DEFAULT, style);
        v.setGravity(Gravity.RIGHT);
        v.setTextDirection(View.TEXT_DIRECTION_RTL);
        v.setPadding(dp(10), dp(6), dp(10), dp(6));
        return v;
    }

    EditText input(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(Color.rgb(155,170,185));
        e.setTextColor(WHITE);
        e.setTextSize(15);
        e.setGravity(Gravity.RIGHT);
        e.setTextDirection(View.TEXT_DIRECTION_RTL);
        e.setSingleLine(false);
        e.setPadding(dp(12), dp(8), dp(12), dp(8));
        e.setBackground(round(FIELD, dp(12)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(dp(5), dp(5), dp(5), dp(5));
        e.setLayoutParams(lp);
        return e;
    }

    Button btn(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextColor(WHITE);
        b.setTextSize(13);
        b.setGravity(Gravity.CENTER);
        b.setBackground(round(Color.rgb(11,93,107), dp(12)));
        return b;
    }

    GradientDrawable round(int color, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radius);
        return g;
    }

    LinearLayout card() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(12), dp(12), dp(12), dp(12));
        l.setBackground(round(CARD, dp(18)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(dp(8), dp(8), dp(8), dp(8));
        l.setLayoutParams(lp);
        return l;
    }

    void frame(String page) {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(dp(5), dp(5), dp(5), dp(5));

        title = tv("فاحص بوح الطبي V2 | " + page, 19, WHITE, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        title.setBackground(round(Color.rgb(8,29,48), dp(18)));
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        HorizontalScrollView hsv = new HorizontalScrollView(this);
        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        homeBtn = btn("الرئيسية");
        examBtn = btn("الفحص");
        chestBtn = btn("الصدر/التنفس");
        chatBtn = btn("المساعد");
        histBtn = btn("السجل");
        settingsBtn = btn("الإعدادات");
        nav.addView(homeBtn); nav.addView(examBtn); nav.addView(chestBtn); nav.addView(chatBtn); nav.addView(histBtn); nav.addView(settingsBtn);
        hsv.addView(nav);
        root.addView(hsv, new LinearLayout.LayoutParams(-1, -2));

        ScrollView sv = new ScrollView(this);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        sv.addView(content);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);

        homeBtn.setOnClickListener(v -> showHome());
        examBtn.setOnClickListener(v -> showExam());
        chestBtn.setOnClickListener(v -> showChest());
        chatBtn.setOnClickListener(v -> showChat());
        histBtn.setOnClickListener(v -> showHistory());
        settingsBtn.setOnClickListener(v -> showSettings());
    }

    void showHome() {
        frame("الرئيسية");
        LinearLayout c = card();
        c.addView(tv("تطبيق فحص وفرز طبي أولي باللغة العربية", 18, CYAN, Typeface.BOLD));
        c.addView(tv("يفحص العلامات الحيوية، أعراض الصدر والتنفس، الضغط، السكر، الحرارة، النبض، والأكسجين ثم يعطي مستوى خطورة أولي وإرشاد واضح.", 15, WHITE, Typeface.NORMAL));
        c.addView(tv("النتائج: طبيعي / مراقبة / مراجعة طبيب / طوارئ. التطبيق لا يعطي تشخيصاً نهائياً ولا يصف أدوية.", 15, AMBER, Typeface.BOLD));
        content.addView(c);

        LinearLayout c2 = card();
        c2.addView(tv("الوحدات المطورة", 18, CYAN, Typeface.BOLD));
        c2.addView(tv("• فحص العلامات الحيوية\n• تقييم الصدر والتنفس\n• فرز أعراض الطوارئ\n• حساب Risk Score داخلي\n• سجل فحوصات محلي\n• مساعد طبي عربي محلي\n• إعدادات ربط AI اختياري", 15, WHITE, Typeface.NORMAL));
        content.addView(c2);
    }

    void showExam() {
        frame("الفحص العام");
        LinearLayout c = card();
        c.addView(tv("أدخل الأرقام المتوفرة فقط، واترك غير المتوفر فارغاً.", 15, AMBER, Typeface.BOLD));
        age = input("العمر بالسنوات");
        temp = input("درجة الحرارة °C");
        pulse = input("النبض / دقيقة");
        spo2 = input("الأكسجين SpO2 %");
        rr = input("معدل التنفس / دقيقة");
        sbp = input("الضغط الانقباضي");
        dbp = input("الضغط الانبساطي");
        glucose = input("سكر الدم mg/dL إن وجد");
        pain = input("شدة الألم من 0 إلى 10");
        symptoms = input("الأعراض: ألم صدر، ضيق نفس، سعال، حرارة، دوخة، إغماء، زرقة، صداع، قيء، إسهال، تعب...");
        analyzeBtn = btn("تحليل الحالة الآن");
        output = tv("جاهز للتحليل.", 15, WHITE, Typeface.NORMAL);
        output.setTextIsSelectable(true);

        c.addView(age); c.addView(temp); c.addView(pulse); c.addView(spo2); c.addView(rr);
        c.addView(sbp); c.addView(dbp); c.addView(glucose); c.addView(pain); c.addView(symptoms);
        c.addView(analyzeBtn); c.addView(output);
        content.addView(c);
        analyzeBtn.setOnClickListener(v -> analyze());
    }

    void showChest() {
        frame("الصدر والتنفس");
        LinearLayout c = card();
        c.addView(tv("فحص تنفّس ميداني: عدّ الأنفاس لمدة 30 ثانية ثم أدخل العدد.", 16, CYAN, Typeface.BOLD));
        c.addView(tv("علامات الخطر: ضيق نفس، ألم صدر ضاغط، زرقة، تعرّق شديد، إغماء، تشوش، أكسجين منخفض.", 15, AMBER, Typeface.BOLD));
        breathBtn = btn("ابدأ مؤقت 30 ثانية");
        output = tv("اضغط البدء ثم عدّ الأنفاس يدوياً.", 15, WHITE, Typeface.NORMAL);
        c.addView(breathBtn); c.addView(output);
        content.addView(c);
        breathBtn.setOnClickListener(v -> startBreathTimer());
    }

    void startBreathTimer() {
        final int[] s = {30};
        output.setText("بدأ العد: 30 ثانية...");
        Runnable r = new Runnable() {
            @Override public void run() {
                s[0]--;
                if (s[0] > 0) {
                    output.setText("باقي " + s[0] + " ثانية. عدّ الأنفاس الآن.");
                    handler.postDelayed(this, 1000);
                } else {
                    EditText e = input("عدد الأنفاس خلال 30 ثانية");
                    new AlertDialog.Builder(MainActivity.this)
                        .setTitle("إدخال عدد الأنفاس")
                        .setView(e)
                        .setPositiveButton("احسب", (d,w) -> {
                            double count = val(e, -1);
                            double rpm = count * 2.0;
                            String msg = "معدل التنفس التقريبي: " + (int)rpm + " / دقيقة\n";
                            if (rpm > 30) msg += "مرتفع جداً: إذا يوجد ضيق نفس أو ألم صدر أو زرقة فالأولوية للطوارئ.";
                            else if (rpm > 24) msg += "مرتفع: يحتاج متابعة ومراجعة إذا استمر.";
                            else if (rpm >= 12 && rpm <= 20) msg += "ضمن النطاق الشائع للبالغين في الراحة.";
                            else msg += "منخفض أو القياس غير دقيق؛ أعد القياس وراجع الطبيب عند وجود أعراض.";
                            output.setText(msg);
                        })
                        .setNegativeButton("إلغاء", null)
                        .show();
                }
            }
        };
        handler.postDelayed(r, 1000);
    }

    void analyze() {
        double a=val(age,-1), t=val(temp,-1), p=val(pulse,-1), o=val(spo2,-1), r=val(rr,-1), hi=val(sbp,-1), lo=val(dbp,-1), g=val(glucose,-1), pn=val(pain,-1);
        String sy = symptoms.getText().toString().toLowerCase(Locale.ROOT);
        int score = 0;
        ArrayList<String> reasons = new ArrayList<>();

        if (has(sy,"ألم صدر","الم صدر","ضغط بالصدر","وجع صدر")) { score+=35; reasons.add("ألم/ضغط في الصدر"); }
        if (has(sy,"ضيق نفس","اختناق","كتمة","نهجان")) { score+=35; reasons.add("ضيق نفس أو كتمة"); }
        if (has(sy,"زرقة","ازرق","أزرق")) { score+=45; reasons.add("زرقة محتملة"); }
        if (has(sy,"إغماء","اغماء","فقدان وعي","تشوش")) { score+=40; reasons.add("إغماء/تشوش"); }
        if (has(sy,"نزيف","دم كثير")) { score+=35; reasons.add("نزيف أو فقدان دم محتمل"); }

        if (o > 0 && o < 90) { score+=45; reasons.add("SpO2 أقل من 90%"); }
        else if (o >= 90 && o < 94) { score+=25; reasons.add("SpO2 منخفض"); }

        if (r > 30) { score+=30; reasons.add("معدل التنفس مرتفع جداً"); }
        else if (r > 24) { score+=15; reasons.add("معدل التنفس مرتفع"); }
        else if (r > 0 && r < 8) { score+=25; reasons.add("معدل التنفس منخفض"); }

        if (p > 130 || (p > 0 && p < 45)) { score+=25; reasons.add("النبض غير مطمئن"); }
        else if (p > 110) { score+=12; reasons.add("النبض مرتفع"); }

        if (t >= 39.5 || (t > 0 && t < 35)) { score+=20; reasons.add("حرارة شديدة أو انخفاض حرارة"); }
        else if (t >= 38) { score+=8; reasons.add("حرارة مرتفعة"); }

        if (hi >= 180 || lo >= 120) { score+=35; reasons.add("ضغط مرتفع جداً"); }
        else if (hi >= 160 || lo >= 100) { score+=15; reasons.add("ضغط مرتفع"); }
        else if ((hi > 0 && hi < 85) || (lo > 0 && lo < 50)) { score+=20; reasons.add("ضغط منخفض محتمل"); }

        if (g > 0 && g < 60) { score+=35; reasons.add("سكر منخفض جداً"); }
        else if (g > 300) { score+=25; reasons.add("سكر مرتفع جداً"); }

        if (pn >= 8) { score += 15; reasons.add("ألم شديد"); }
        if (a >= 65 && score > 0) { score += 8; reasons.add("العمر يرفع حساسية الخطر"); }
        if (score > 100) score = 100;

        String level;
        int color;
        if (score >= 65) { level = "طوارئ عالية"; color = RED; }
        else if (score >= 40) { level = "مراجعة طبيب اليوم / طوارئ عند التدهور"; color = AMBER; }
        else if (score >= 18) { level = "مراقبة ومراجعة إذا استمرت الأعراض"; color = AMBER; }
        else { level = "مبدئياً لا توجد مؤشرات عالية الخطورة من المدخلات"; color = GREEN; }

        StringBuilder sb = new StringBuilder();
        sb.append("النتيجة: ").append(level).append("\n");
        sb.append("Risk Score: ").append(score).append("/100\n\n");
        sb.append("الأسباب:\n");
        if (reasons.isEmpty()) sb.append("• لا توجد علامة خطر واضحة من القيم المدخلة.\n");
        else for (String reason: reasons) sb.append("• ").append(reason).append("\n");

        sb.append("\nالإجراء المقترح:\n");
        if (score >= 65) sb.append("اذهب للطوارئ/اطلب إسعاف، خصوصاً مع ألم صدر أو ضيق نفس أو زرقة أو إغماء أو أكسجين منخفض.");
        else if (score >= 40) sb.append("راجع طبيباً في أقرب وقت اليوم، واذهب للطوارئ عند زيادة الألم أو ضيق النفس أو انخفاض الأكسجين.");
        else if (score >= 18) sb.append("أعد القياس بعد راحة، راقب الأعراض، وراجع طبيباً إذا استمرت أو زادت.");
        else sb.append("تابع القياس والراحة. إذا ظهرت علامات خطر فالتقييم يتغير فوراً.");

        sb.append("\n\nتنبيه: هذا فرز أولي وليس تشخيصاً نهائياً ولا وصفاً علاجياً.");
        output.setText(sb.toString());
        output.setTextColor(color);
        saveHistory(sb.toString());
    }

    void showChat() {
        frame("المساعد الطبي");
        LinearLayout c = card();
        chatLog = tv("المساعد: اكتب الأعراض والأرقام المتوفرة، وسأعطيك فرزاً أولياً آمناً.\n", 15, WHITE, Typeface.NORMAL);
        chatLog.setMovementMethod(new ScrollingMovementMethod());
        chatLog.setTextIsSelectable(true);
        chatInput = input("اكتب سؤالك الطبي هنا...");
        sendBtn = btn("إرسال");
        c.addView(chatLog); c.addView(chatInput); c.addView(sendBtn);
        content.addView(c);
        sendBtn.setOnClickListener(v -> {
            String q = chatInput.getText().toString().trim();
            if (q.length() == 0) return;
            chatLog.append("\nأنت: " + q + "\nالمساعد: " + reply(q) + "\n");
            chatInput.setText("");
            try { ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(chatInput.getWindowToken(), 0); } catch(Exception e){}
        });
    }

    String reply(String q) {
        String x = q.toLowerCase(Locale.ROOT);
        if (has(x,"ألم صدر","الم صدر","ضيق نفس","زرقة","إغماء","اغماء")) {
            return "هذه علامات إنذار. إذا الأعراض شديدة أو مع تعرق/دوخة/تشوش أو SpO2 منخفض فالأولوية للطوارئ. اكتب العمر، SpO2، النبض، الضغط ومدة الأعراض لفرز أدق.";
        }
        if (has(x,"حرارة","حمى","سخونة")) {
            return "الحرارة 38 فأعلى غالباً مرتفعة. حرارة 39.5 أو أكثر، أو حرارة مع تشوش/ضيق نفس/تيبس رقبة/جفاف شديد، تحتاج مراجعة عاجلة.";
        }
        if (has(x,"سعال","بلغم","صدر","صفير")) {
            return "السعال مع ضيق نفس أو ألم صدر أو بلغم دموي أو أكسجين أقل من 94% يحتاج مراجعة. اكتب مدة السعال والحرارة ولون البلغم.";
        }
        if (has(x,"ضغط")) {
            return "ضغط 180/120 أو أكثر مع صداع شديد أو ألم صدر أو ضيق نفس أو تشوش حالة عاجلة. أعد القياس بعد راحة 5 دقائق وبجهاز موثوق.";
        }
        if (has(x,"سكر","سكري")) {
            return "سكر أقل من 60 أو أعلى من 300 مع أعراض يحتاج اهتماماً عاجلاً. لا أغير جرعات الأدوية؛ اتبع خطة طبيبك أو راجع الطوارئ عند الأعراض الشديدة.";
        }
        return "أحتاج تفاصيل أكثر: العمر، الحرارة، النبض، الأكسجين، الضغط، مدة الأعراض، والأمراض المزمنة. سأفرز الحالة إلى مراقبة أو مراجعة أو طوارئ، وليس تشخيصاً نهائياً.";
    }

    void showHistory() {
        frame("سجل الفحوصات");
        LinearLayout c = card();
        historyBox = tv(prefs.getString("history", "لا يوجد سجل بعد."), 14, WHITE, Typeface.NORMAL);
        historyBox.setTextIsSelectable(true);
        clearHistoryBtn = btn("مسح السجل");
        c.addView(historyBox); c.addView(clearHistoryBtn);
        content.addView(c);
        clearHistoryBtn.setOnClickListener(v -> {
            prefs.edit().remove("history").apply();
            historyBox.setText("تم مسح السجل.");
        });
    }

    void showSettings() {
        frame("الإعدادات");
        LinearLayout c = card();
        c.addView(tv("ربط AI خارجي اختياري", 18, CYAN, Typeface.BOLD));
        endpoint = input("API Endpoint اختياري");
        key = input("API Key اختياري - لا ترفعه إلى GitHub");
        model = input("Model اختياري");
        endpoint.setText(prefs.getString("endpoint",""));
        key.setText(prefs.getString("key",""));
        model.setText(prefs.getString("model",""));
        saveBtn = btn("حفظ الإعدادات محلياً");
        c.addView(endpoint); c.addView(key); c.addView(model); c.addView(saveBtn);
        c.addView(tv("الخصوصية: النسخة الحالية تعمل محلياً ولا ترسل بياناتك الطبية إلا إذا أضفت أنت خدمة خارجية لاحقاً.", 15, WHITE, Typeface.NORMAL));
        c.addView(tv("تحذير طبي: التطبيق فرز أولي فقط، وليس جهازاً طبياً معتمداً ولا بديلاً للطبيب أو الطوارئ.", 15, RED, Typeface.BOLD));
        content.addView(c);
        saveBtn.setOnClickListener(v -> {
            prefs.edit()
                .putString("endpoint", endpoint.getText().toString())
                .putString("key", key.getText().toString())
                .putString("model", model.getText().toString())
                .apply();
            Toast.makeText(this, "تم الحفظ محلياً", Toast.LENGTH_SHORT).show();
        });
    }

    void saveHistory(String report) {
        String time = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(new Date());
        String old = prefs.getString("history", "");
        String item = "----- " + time + " -----\n" + report + "\n\n";
        prefs.edit().putString("history", item + old).apply();
    }

    boolean has(String text, String... keys) {
        for (String k: keys) if (text.contains(k.toLowerCase(Locale.ROOT))) return true;
        return false;
    }

    double val(EditText e, double fallback) {
        try {
            String s = e.getText().toString().trim().replace(",", ".");
            if (s.length() == 0) return fallback;
            return Double.parseDouble(s);
        } catch(Exception ex) { return fallback; }
    }

    int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
}
