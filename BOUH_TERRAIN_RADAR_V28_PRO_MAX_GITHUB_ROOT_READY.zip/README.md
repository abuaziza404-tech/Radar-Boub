# BOUH Terrain Radar V28 Pro Max

خرائط صور وتضاريس متعددة، Hybrid حقيقي، مساعد أوسع مع نطق صوتي، وتحليل متعدد المؤشرات مع Distance Decay و GPZ Boost.

ارفع محتوى ZIP مفكوكاً إلى جذر GitHub ثم شغّل Actions.

الخرائط تحتاج إنترنت. التحليل يعمل محلياً من SQLite. استبدل Starter DB بقواعدك الكاملة لنطاق كامل.
