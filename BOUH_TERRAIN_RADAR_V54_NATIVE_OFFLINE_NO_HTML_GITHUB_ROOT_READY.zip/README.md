# BOUH Terrain Radar V54 Native Offline — No HTML

هذه حزمة Android Native مخصصة لـ GitHub Actions. التطبيق لا يعتمد على HTML ولا WebView ولا Leaflet ولا Google/Esri/OSM.

## الخصائص
- واجهة Android Native Java بالكامل.
- لا يوجد `index.html` داخل التطبيق.
- لا يوجد WebView.
- لا توجد صلاحية INTERNET في AndroidManifest.
- قاعدة بيانات الرادار الحقيقية محفوظة داخلياً: `BOUH_V30_REAL_3ZONES.db`.
- طبقات محلية Offline RGB/SWIR محفوظة داخل assets.
- يفتح مباشرة داخل نطاق أربعات / غرب بورتسودان، بدون قفل للخريطة.
- عداد الرادار والتحليل ظاهر دائماً.
- خارج التغطية الحقيقية يظهر NO REAL COVERAGE بدلاً من Score عشوائي.

## طريقة الاستخدام
ارفع محتويات الحزمة إلى جذر مستودع GitHub، ثم شغل:

Actions → Build BOUH Native Offline APK

سيظهر ملف APK داخل Artifacts.
