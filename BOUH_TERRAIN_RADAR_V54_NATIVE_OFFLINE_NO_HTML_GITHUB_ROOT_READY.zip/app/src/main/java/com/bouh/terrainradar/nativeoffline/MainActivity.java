package com.bouh.terrainradar.nativeoffline;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.*;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
    static final double HOME_LAT = 19.973186, HOME_LON = 36.745590;
    static final double RADIUS_M = 1200.0;
    final ArrayList<Cell> cells = new ArrayList<>();
    RadarView radar;
    TextView top, panel;
    Button modeBtn;
    boolean showSwir = false, showReject = false, followGps = false;
    Location lastGps;

    static class Cell {
        String id, zone, cls, model, indicators, reason;
        double lat, lon;
        int score, structure, alteration, feox, drainage, magnetic, lithology, historical, gpz;
    }
    static class Layer {
        String name, rgb, swir; double s,w,n,e; Bitmap rgbBmp, swirBmp;
        Layer(String name,String rgb,String swir,double s,double w,double n,double e){this.name=name;this.rgb=rgb;this.swir=swir;this.s=s;this.w=w;this.n=n;this.e=e;}
        boolean contains(double lat,double lon){return lat>=s&&lat<=n&&lon>=w&&lon<=e;}
    }
    final Layer[] layers = new Layer[]{
        new Layer("CENTER","offline_layers/center_offline_rgb.jpg","offline_layers/center_offline_swir.jpg",18.443135757230912,36.09832763671876,20.689322775663335,37.27111816406251),
        new Layer("NORTH","offline_layers/north_offline_rgb.jpg","offline_layers/north_offline_swir.jpg",19.508616310319184,35.98495468025546,21.739678698995803,37.15774520759921),
        new Layer("SOUTH","offline_layers/south_offline_rgb.jpg","offline_layers/south_offline_swir.jpg",16.618150998762626,36.61647038303276,18.888473188510254,37.78926091037651)
    };

    @Override public void onCreate(Bundle b){ super.onCreate(b); getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN); loadDb(); loadBitmaps(); buildUi(); requestGps(); }

    void buildUi(){
        FrameLayout root=new FrameLayout(this); radar=new RadarView(this); root.addView(radar,new FrameLayout.LayoutParams(-1,-1));
        top=new TextView(this); top.setTextColor(Color.WHITE); top.setTextSize(12); top.setTypeface(Typeface.DEFAULT_BOLD); top.setPadding(14,8,14,8); top.setBackground(round(0xcc050505,18));
        FrameLayout.LayoutParams tp=new FrameLayout.LayoutParams(-1,-2,Gravity.TOP|Gravity.CENTER_HORIZONTAL); tp.setMargins(10,10,10,0); root.addView(top,tp);
        panel=new TextView(this); panel.setTextColor(Color.WHITE); panel.setTextSize(12); panel.setPadding(14,12,14,12); panel.setBackground(round(0xdd050505,22)); panel.setTypeface(Typeface.MONOSPACE);
        FrameLayout.LayoutParams pp=new FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL); pp.setMargins(10,0,10,12); root.addView(panel,pp);
        LinearLayout tools=new LinearLayout(this); tools.setOrientation(LinearLayout.VERTICAL); tools.setPadding(6,6,6,6); tools.setBackground(round(0x66000000,22));
        String[] names={"HOME","CENTER","NORTH","SOUTH","RGB/SWIR","GPS","FILTER"};
        for(String n:names){ Button bt=button(n); tools.addView(bt,new LinearLayout.LayoutParams(dp(92),dp(38))); bt.setOnClickListener(v->handleButton(((Button)v).getText().toString())); if(n.equals("RGB/SWIR")) modeBtn=bt; }
        FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(-2,-2,Gravity.RIGHT|Gravity.CENTER_VERTICAL); lp.setMargins(0,0,8,0); root.addView(tools,lp);
        setContentView(root); radar.setCenter(HOME_LAT, HOME_LON); updateInfo();
    }
    Button button(String s){ Button b=new Button(this); b.setText(s); b.setTextSize(10); b.setTextColor(Color.WHITE); b.setAllCaps(false); b.setBackground(round(0xaa1a1a1a,16)); return b; }
    int dp(int v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
    android.graphics.drawable.GradientDrawable round(int color,int rad){ android.graphics.drawable.GradientDrawable g=new android.graphics.drawable.GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(rad)); g.setStroke(1,0x66d7b56d); return g; }
    void handleButton(String s){
        if(s.equals("HOME")){radar.setCenter(HOME_LAT,HOME_LON);} else if(s.equals("CENTER")){radar.setCenter(19.973186,36.745590);} else if(s.equals("NORTH")){radar.setCenter(20.927345,36.490000);} else if(s.equals("SOUTH")){radar.setCenter(19.788172,37.023588);} else if(s.equals("RGB/SWIR")){showSwir=!showSwir; modeBtn.setText(showSwir?"SWIR":"RGB");} else if(s.equals("GPS")){ if(lastGps!=null){followGps=true;radar.setCenter(lastGps.getLatitude(),lastGps.getLongitude());} } else if(s.equals("FILTER")){showReject=!showReject;}
        radar.invalidate(); updateInfo();
    }

    void loadBitmaps(){ for(Layer l:layers){ try{ l.rgbBmp=BitmapFactory.decodeStream(getAssets().open(l.rgb)); l.swirBmp=BitmapFactory.decodeStream(getAssets().open(l.swir)); }catch(Exception ignored){} } }
    void loadDb(){
        try{
            File f=new File(getFilesDir(),"BOUH_V30_REAL_3ZONES.db");
            if(!f.exists()){ InputStream in=getAssets().open("databases/BOUH_V30_REAL_3ZONES.db"); FileOutputStream out=new FileOutputStream(f); byte[] buf=new byte[8192]; int n; while((n=in.read(buf))>0)out.write(buf,0,n); out.close(); in.close(); }
            SQLiteDatabase db=SQLiteDatabase.openDatabase(f.getAbsolutePath(),null,SQLiteDatabase.OPEN_READONLY);
            Cursor c=db.rawQuery("SELECT id,zone,lat,lon,classification,final_score,structure_score,alteration_score,feox_score,drainage_score,magnetic_proxy,lithology_score,historical_score,gpz_analog,model,indicators,decision_reason FROM cells",null);
            while(c.moveToNext()){ Cell x=new Cell(); x.id=s(c,0); x.zone=s(c,1); x.lat=c.getDouble(2); x.lon=c.getDouble(3); x.cls=s(c,4); x.score=c.getInt(5); x.structure=c.getInt(6); x.alteration=c.getInt(7); x.feox=c.getInt(8); x.drainage=c.getInt(9); x.magnetic=c.getInt(10); x.lithology=c.getInt(11); x.historical=c.getInt(12); x.gpz=c.getInt(13); x.model=s(c,14); x.indicators=s(c,15); x.reason=s(c,16); cells.add(x); }
            c.close(); db.close();
        }catch(Exception e){ Toast.makeText(this,"DB error: "+e.getMessage(),Toast.LENGTH_LONG).show(); }
    }
    String s(Cursor c,int i){return c.isNull(i)?"":c.getString(i);} 

    void requestGps(){
        if(android.os.Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},7);
        try{ LocationManager lm=(LocationManager)getSystemService(LOCATION_SERVICE); lm.requestLocationUpdates(LocationManager.GPS_PROVIDER,2500,3,new LocationListener(){ public void onLocationChanged(Location l){ lastGps=l; if(followGps){radar.setCenter(l.getLatitude(),l.getLongitude()); updateInfo();} } public void onStatusChanged(String p,int s,Bundle e){} public void onProviderEnabled(String p){} public void onProviderDisabled(String p){} }); }catch(Exception ignored){}
    }
    Cell nearest(double lat,double lon){ Cell best=null; double bd=1e18; for(Cell c:cells){ double d=dist(lat,lon,c.lat,c.lon); if(d<bd){bd=d; best=c;} } return bd<=RADIUS_M?best:null; }
    double nearestDist(double lat,double lon){ double bd=1e18; for(Cell c:cells){ double d=dist(lat,lon,c.lat,c.lon); if(d<bd)bd=d; } return bd; }
    double dist(double a,double b,double c,double d){ double R=6371000, p1=Math.toRadians(a), p2=Math.toRadians(c), dp=Math.toRadians(c-a), dl=Math.toRadians(d-b); double x=Math.sin(dp/2)*Math.sin(dp/2)+Math.cos(p1)*Math.cos(p2)*Math.sin(dl/2)*Math.sin(dl/2); return 2*R*Math.atan2(Math.sqrt(x),Math.sqrt(1-x)); }
    void updateInfo(){
        double lat=radar.centerLat, lon=radar.centerLon; Cell c=nearest(lat,lon); Layer l=radar.layerFor(lat,lon);
        top.setText(String.format(Locale.US,"BOUH Native Offline  V54  |  %.6f, %.6f  |  %s  |  %d cells",lat,lon,l==null?"NO LOCAL MAP":l.name,cells.size()));
        if(c==null){ double d=nearestDist(lat,lon); panel.setText(String.format(Locale.US,"NO REAL COVERAGE\nNearest analyzed cell: %.0f m\nENGINE: OFFLINE READY | MAP: LOCAL IMAGE\nMove to Arbaat / West Port Sudan coverage.",d)); }
        else { panel.setText(String.format(Locale.US,"SCORE %d/100  •  %s  •  REAL COVERAGE\nSTR %d  ALT %d  FeOx %d  DRAIN %d  MAG %d  GPZ %d\n%s\nGPZ Strategy: %s",c.score,c.cls,c.structure,c.alteration,c.feox,c.drainage,c.magnetic,c.gpz,c.id,gpz(c))); }
    }
    String gpz(Cell c){ if(c.magnetic>75) return "Severe/Difficult • High Yield • Sens 8–11 • Slow swing"; if(c.score>=70) return "Normal/Difficult test • General/Deep • Sens 12–16 if stable"; return "Observe only; do not waste GPZ time unless field evidence appears"; }

    class RadarView extends View {
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG); double centerLat=HOME_LAT, centerLon=HOME_LON; float zoom=1.0f, lastX,lastY; boolean drag=false; ScaleGestureDetector scale;
        RadarView(Context c){ super(c); scale=new ScaleGestureDetector(c,new ScaleGestureDetector.SimpleOnScaleGestureListener(){ public boolean onScale(ScaleGestureDetector d){ zoom*=d.getScaleFactor(); if(zoom<0.7f)zoom=0.7f; if(zoom>7f)zoom=7f; invalidate(); return true; }}); }
        void setCenter(double lat,double lon){ centerLat=lat; centerLon=lon; invalidate(); updateInfo(); }
        Layer layerFor(double lat,double lon){ for(Layer l:layers) if(l.contains(lat,lon)) return l; return layers[0]; }
        @Override protected void onDraw(Canvas c){ super.onDraw(c); Layer l=layerFor(centerLat,centerLon); drawLayer(c,l); drawCells(c,l); drawCross(c); }
        void drawLayer(Canvas c,Layer l){ Bitmap b=showSwir?l.swirBmp:l.rgbBmp; if(b==null){c.drawColor(Color.BLACK);return;} PointF cp=llToPx(l,centerLat,centerLon); float scale=Math.max(getWidth()/(float)b.getWidth(), getHeight()/(float)b.getHeight())*zoom; float left=getWidth()/2f-cp.x*scale; float top=getHeight()/2f-cp.y*scale; Matrix m=new Matrix(); m.postScale(scale,scale); m.postTranslate(left,top); p.setAlpha(255); c.drawBitmap(b,m,p); c.drawColor(0x33000000); }
        PointF llToPx(Layer l,double lat,double lon){ Bitmap b=l.rgbBmp; float x=(float)((lon-l.w)/(l.e-l.w)*b.getWidth()); float y=(float)((l.n-lat)/(l.n-l.s)*b.getHeight()); return new PointF(x,y); }
        PointF llToScreen(Layer l,double lat,double lon){ Bitmap b=l.rgbBmp; PointF cp=llToPx(l,centerLat,centerLon); PointF pp=llToPx(l,lat,lon); float scale=Math.max(getWidth()/(float)b.getWidth(), getHeight()/(float)b.getHeight())*zoom; return new PointF(getWidth()/2f+(pp.x-cp.x)*scale,getHeight()/2f+(pp.y-cp.y)*scale); }
        void drawCells(Canvas c,Layer l){ for(Cell x:cells){ if(!l.contains(x.lat,x.lon)) continue; if(!showReject && x.score<55) continue; PointF s=llToScreen(l,x.lat,x.lon); if(s.x<-20||s.x>getWidth()+20||s.y<-20||s.y>getHeight()+20) continue; int col=x.score>=75?0xffffd54a:x.score>=55?0xff43d17a:0xff888888; p.setColor(col); p.setStyle(Paint.Style.FILL); c.drawCircle(s.x,s.y,x.score>=70?5:3,p); } }
        void drawCross(Canvas c){ p.setStrokeWidth(2); p.setColor(0xffffffff); c.drawLine(getWidth()/2f-18,getHeight()/2f,getWidth()/2f+18,getHeight()/2f,p); c.drawLine(getWidth()/2f,getHeight()/2f-18,getWidth()/2f,getHeight()/2f+18,p); p.setStyle(Paint.Style.STROKE); p.setColor(0xffffd54a); p.setStrokeWidth(3); c.drawCircle(getWidth()/2f,getHeight()/2f,44,p); p.setStyle(Paint.Style.FILL); }
        @Override public boolean onTouchEvent(android.view.MotionEvent e){ scale.onTouchEvent(e); if(e.getPointerCount()>1) return true; if(e.getAction()==MotionEvent.ACTION_DOWN){lastX=e.getX();lastY=e.getY();drag=true;} else if(e.getAction()==MotionEvent.ACTION_MOVE && drag){ pan(e.getX()-lastX,e.getY()-lastY); lastX=e.getX(); lastY=e.getY();} else if(e.getAction()==MotionEvent.ACTION_UP){drag=false;} return true; }
        void pan(float dx,float dy){ Layer l=layerFor(centerLat,centerLon); Bitmap b=l.rgbBmp; float scale=Math.max(getWidth()/(float)b.getWidth(), getHeight()/(float)b.getHeight())*zoom; double dLon=-(dx/scale)/b.getWidth()*(l.e-l.w); double dLat=(dy/scale)/b.getHeight()*(l.n-l.s); centerLon+=dLon; centerLat+=dLat; invalidate(); updateInfo(); }
    }
}
