package com.bouh.georadarai;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class LocalDataStore {
    private final Context context;
    private final List<TargetPoint> targets = new ArrayList<>();
    public LocalDataStore(Context context) { this.context = context; }

    public void load() {
        targets.clear();
        loadDb("BOUH_V21_CENTER_MOBILE.db");
        loadDb("BOUH_V21_NORTH_MOBILE.db");
        loadDb("BOUH_V21_SOUTH_MOBILE.db");
    }

    private void loadDb(String name) {
        try {
            File out = new File(context.getFilesDir(), name);
            if (!out.exists()) {
                InputStream in = context.getAssets().open("databases/" + name);
                FileOutputStream fos = new FileOutputStream(out);
                byte[] buffer = new byte[8192];
                int read;
                while ((read = in.read(buffer)) > 0) fos.write(buffer, 0, read);
                fos.close(); in.close();
            }
            SQLiteDatabase db = SQLiteDatabase.openDatabase(out.getAbsolutePath(), null, SQLiteDatabase.OPEN_READONLY);
            Cursor c = db.rawQuery("SELECT id,region,lat,lon,score,class_type,system_type,spectral,structure,alteration,terrain,kcl,status,notes FROM targets", null);
            while (c.moveToNext()) {
                targets.add(new TargetPoint(
                        c.getString(0), c.getString(1), c.getDouble(2), c.getDouble(3), c.getDouble(4),
                        c.getString(5), c.getString(6), c.getDouble(7), c.getDouble(8), c.getDouble(9),
                        c.getDouble(10), c.getDouble(11), c.getString(12), c.getString(13)));
            }
            c.close(); db.close();
        } catch (Exception ignored) { }
    }

    public List<TargetPoint> allTargets() { return targets; }

    public TargetPoint nearest(double lat, double lon) {
        TargetPoint best = null; double bestD = Double.MAX_VALUE;
        for (TargetPoint t : targets) {
            double d = distanceMeters(lat, lon, t.lat, t.lon);
            if (d < bestD) { bestD = d; best = t; }
        }
        return best;
    }

    public static double distanceMeters(double lat1, double lon1, double lat2, double lon2) {
        double R = 6371000.0;
        double p1 = Math.toRadians(lat1), p2 = Math.toRadians(lat2);
        double dp = Math.toRadians(lat2 - lat1), dl = Math.toRadians(lon2 - lon1);
        double a = Math.sin(dp/2)*Math.sin(dp/2) + Math.cos(p1)*Math.cos(p2)*Math.sin(dl/2)*Math.sin(dl/2);
        return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    }
}
