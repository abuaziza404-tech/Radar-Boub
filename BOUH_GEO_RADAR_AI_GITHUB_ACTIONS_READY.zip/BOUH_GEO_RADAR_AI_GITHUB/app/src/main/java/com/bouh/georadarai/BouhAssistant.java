package com.bouh.georadarai;

import java.util.List;

public class BouhAssistant {
    private final LocalDataStore store;
    public BouhAssistant(LocalDataStore store) { this.store = store; }

    public String reply(String q) {
        String s = q == null ? "" : q.toLowerCase();
        if (s.contains("top") || s.contains("افضل") || s.contains("أعلى") || s.contains("اغنى")) {
            return topTargets();
        }
        if (s.contains("target-b") || s.contains("اثبات") || s.contains("ذهب مؤكد")) {
            return "لا أرفع Target-B ولا أقول ذهب مؤكد إلا بوجود GPZ/recovered gold أو assay/QA-QC. التطبيق الحالي يعطي GPZ FIELD CHECK أو Candidate فقط من البيانات المحلية.";
        }
        if (s.contains("gpz") || s.contains("جهاز")) {
            return "قاعدة GPZ: الأرض ذات Magnetic Ground Risk مرتفع تُفحص ببطء، Ground Type Difficult/Severe، Gold Mode High Yield، Sensitivity 8–11. عند أرض هادئة مع كوارتز قوي يمكن Normal + General/Deep + Sensitivity 12–16.";
        }
        if (s.contains("sentinel") || s.contains("باند") || s.contains("استشعار")) {
            return "Sentinel uint8/visual داخل التطبيق يُعامل كمؤشر نسبي داعم وليس reflectance calibrated. القرار القوي يحتاج raw bands/DEM/ASTER/KCL/field confirmation.";
        }
        return "تحليل بوح: ابدأ بالبنية والنمط، ثم التغير الحلمائي/الطيفي، ثم التضاريس، ثم التأكيد الميداني. أرسل إحداثية داخل التطبيق أو اسأل: أعلى النقاط، GPZ، Sentinel، أو سبب التصنيف.";
    }

    private String topTargets() {
        List<TargetPoint> list = store.allTargets();
        StringBuilder b = new StringBuilder("أعلى النقاط المحلية في الحزمة:\n");
        int n = Math.min(5, list.size());
        for (int i = 0; i < n; i++) {
            TargetPoint t = list.get(i);
            b.append(i+1).append(") ").append(t.id).append(" ")
                    .append(String.format(java.util.Locale.US, "%.6f, %.6f", t.lat, t.lon))
                    .append(" score=").append(String.format(java.util.Locale.US, "%.3f", t.score))
                    .append(" | ").append(t.type).append("\n");
        }
        return b.toString();
    }
}
