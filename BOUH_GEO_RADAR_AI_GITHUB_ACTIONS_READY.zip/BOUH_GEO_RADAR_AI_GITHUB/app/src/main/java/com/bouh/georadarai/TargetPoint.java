package com.bouh.georadarai;

public class TargetPoint {
    public String id, region, clazz, type, status, notes;
    public double lat, lon, score, spectral, structure, alteration, terrain, kcl;

    public TargetPoint(String id, String region, double lat, double lon, double score, String clazz,
                       String type, double spectral, double structure, double alteration,
                       double terrain, double kcl, String status, String notes) {
        this.id = id; this.region = region; this.lat = lat; this.lon = lon; this.score = score;
        this.clazz = clazz; this.type = type; this.spectral = spectral; this.structure = structure;
        this.alteration = alteration; this.terrain = terrain; this.kcl = kcl;
        this.status = status; this.notes = notes;
    }
}
