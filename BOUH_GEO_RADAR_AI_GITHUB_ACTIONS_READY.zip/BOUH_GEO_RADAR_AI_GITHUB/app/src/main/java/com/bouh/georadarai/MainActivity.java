package com.bouh.georadarai;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.*;
import android.view.View;

public class MainActivity extends Activity {
    private LocalDataStore store;
    private DecisionEngine engine;
    private BouhAssistant assistant;
    private TextView output;
    private EditText latBox, lonBox, chatBox;
    private RadarMapView radar;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        store = new LocalDataStore(this); store.load();
        engine = new DecisionEngine(store); assistant = new BouhAssistant(store);

        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(18,18,18,18); root.setBackgroundColor(0xff07120f);
        TextView title = text("بوح التضاريس | Geo Radar AI", 22, 0xffd9ffe8, true); title.setGravity(Gravity.CENTER); root.addView(title);
        TextView sub = text("رادار جيولوجي محلي + مساعد تحليل AI — لا عشوائية ولا Target-B بدون تأكيد", 13, 0xff8ee6b1, false); sub.setGravity(Gravity.CENTER); root.addView(sub);

        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
        latBox = input("Latitude"); lonBox = input("Longitude"); Button scan = btn("SCAN");
        row.addView(latBox, new LinearLayout.LayoutParams(0, 70, 1)); row.addView(lonBox, new LinearLayout.LayoutParams(0,70,1)); row.addView(scan, new LinearLayout.LayoutParams(0,70,0.75f)); root.addView(row);

        radar = new RadarMapView(this); radar.setTargets(store.allTargets()); root.addView(radar, new LinearLayout.LayoutParams(-1,0,4));
        output = text("اضغط على الخريطة أو أدخل إحداثية ثم SCAN.", 14, 0xffffffff, false); output.setPadding(12,12,12,12); output.setBackgroundColor(0xff0d1f1a); root.addView(output, new LinearLayout.LayoutParams(-1,0,2));

        LinearLayout chat = new LinearLayout(this); chat.setOrientation(LinearLayout.HORIZONTAL);
        chatBox = input("اسأل مساعد بوح..."); Button ask = btn("AI"); chat.addView(chatBox, new LinearLayout.LayoutParams(0,70,1)); chat.addView(ask, new LinearLayout.LayoutParams(120,70)); root.addView(chat);
        setContentView(root);

        scan.setOnClickListener(v -> scanManual());
        ask.setOnClickListener(v -> output.setText("AI:\n" + assistant.reply(chatBox.getText().toString())));
        radar.setListener((lat, lon) -> { latBox.setText(String.format(java.util.Locale.US,"%.6f",lat)); lonBox.setText(String.format(java.util.Locale.US,"%.6f",lon)); showDecision(lat,lon); });
    }

    private void scanManual(){
        try { double lat=Double.parseDouble(latBox.getText().toString().trim()); double lon=Double.parseDouble(lonBox.getText().toString().trim()); radar.setSelected(lat,lon); showDecision(lat,lon); }
        catch(Exception e){ output.setText("أدخل الإحداثيات بصيغة رقمية صحيحة مثل 19.973186 / 36.745590"); }
    }
    private void showDecision(double lat, double lon){
        RadarDecision d = engine.scan(lat, lon);
        String nearest = d.nearest == null ? "" : "\nDistance to nearest cell: " + String.format(java.util.Locale.US,"%.1f m", d.distanceMeters);
        output.setText("RESULT: " + d.label + nearest + "\n\n" + d.reason);
    }
    private TextView text(String s, int sp, int color, boolean bold){ TextView v=new TextView(this); v.setText(s); v.setTextSize(sp); v.setTextColor(color); if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return v; }
    private EditText input(String hint){ EditText e=new EditText(this); e.setHint(hint); e.setSingleLine(true); e.setTextColor(0xffffffff); e.setHintTextColor(0xff8aa99a); e.setTextSize(14); e.setBackgroundColor(0xff102820); e.setPadding(10,0,10,0); return e; }
    private Button btn(String s){ Button b=new Button(this); b.setText(s); b.setTextColor(0xff06140f); b.setTextSize(13); return b; }
}
