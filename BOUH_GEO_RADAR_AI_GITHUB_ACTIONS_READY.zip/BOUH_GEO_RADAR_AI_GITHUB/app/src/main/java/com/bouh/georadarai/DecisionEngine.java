package com.bouh.georadarai;

public class DecisionEngine {
    private final LocalDataStore store;
    public DecisionEngine(LocalDataStore store) { this.store = store; }

    public RadarDecision scan(double lat, double lon) {
        TargetPoint n = store.nearest(lat, lon);
        if (n == null) return new RadarDecision("OUTSIDE COVERAGE", "لا توجد قواعد بيانات محلية محملة.", -1, null, false);
        double d = LocalDataStore.distanceMeters(lat, lon, n.lat, n.lon);
        boolean inside = d <= 1500;
        if (!inside) return new RadarDecision("OUTSIDE COVERAGE", "النقطة أبعد من 1500م عن أقرب خلية/هدف محلي. لا يتم التخمين خارج التغطية.", d, n, false);

        boolean hasStructure = n.structure >= 0.55;
        boolean hasAlteration = n.alteration >= 0.55;
        boolean spectralOk = n.spectral >= 0.55;
        boolean high = n.score >= 0.70 && hasStructure && hasAlteration && spectralOk;
        boolean candidate = n.score >= 0.62 && hasStructure && (hasAlteration || spectralOk);
        boolean hold = n.score >= 0.50 && (hasStructure || hasAlteration || spectralOk);

        if (high) return new RadarDecision("GPZ FIELD CHECK", reason(n, "تكامل بنية + نمط + تغير حلمائي/طيفي. لا يوجد إثبات ذهب إلا بفحص GPZ/عينة/assay."), d, n, true);
        if (candidate) return new RadarDecision("CANDIDATE", reason(n, "مرشح ميداني بسبب وجود أكثر من طبقة داعمة، مع منع رفع Target-B بدون تأكيد ميداني."), d, n, true);
        if (hold) return new RadarDecision("HOLD", reason(n, "يحتاج مراجعة ميدانية أو بيانات خام إضافية؛ لا يكفي وحده للحفر."), d, n, true);
        return new RadarDecision("REJECT", reason(n, "لا يوجد تكامل كافٍ بين Structure → Pattern → Alteration → Confirmation."), d, n, true);
    }

    private String reason(TargetPoint t, String tail) {
        return "أقرب خلية: " + t.id + " / " + t.region + "\n" +
                "النوع: " + t.type + "\n" +
                "Score=" + fmt(t.score) + " | Spectral=" + fmt(t.spectral) + " | Structure=" + fmt(t.structure) +
                " | Alteration=" + fmt(t.alteration) + " | Terrain=" + fmt(t.terrain) + " | KCL=" + fmt(t.kcl) + "\n" +
                "ملاحظة: " + t.notes + "\n" + tail;
    }

    private String fmt(double v) { return String.format(java.util.Locale.US, "%.3f", v); }
}
