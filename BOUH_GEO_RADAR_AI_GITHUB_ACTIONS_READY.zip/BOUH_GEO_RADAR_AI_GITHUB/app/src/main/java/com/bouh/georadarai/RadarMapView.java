package com.bouh.georadarai;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.View;
import java.util.List;

public class RadarMapView extends View {
    public interface Listener { void onPoint(double lat, double lon); }
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private List<TargetPoint> targets;
    private Listener listener;
    private double minLat=18.3, maxLat=21.7, minLon=34.5, maxLon=37.4;
    private double selectedLat=Double.NaN, selectedLon=Double.NaN;

    public RadarMapView(Context c) { super(c); }
    public void setTargets(List<TargetPoint> t) { targets=t; computeBounds(); invalidate(); }
    public void setListener(Listener l) { listener=l; }
    public void setSelected(double lat, double lon) { selectedLat=lat; selectedLon=lon; invalidate(); }

    private void computeBounds() {
        if (targets == null || targets.isEmpty()) return;
        minLat=90; maxLat=-90; minLon=180; maxLon=-180;
        for (TargetPoint t: targets) { minLat=Math.min(minLat,t.lat); maxLat=Math.max(maxLat,t.lat); minLon=Math.min(minLon,t.lon); maxLon=Math.max(maxLon,t.lon); }
        double padLat=(maxLat-minLat)*0.12+0.02, padLon=(maxLon-minLon)*0.12+0.02;
        minLat-=padLat; maxLat+=padLat; minLon-=padLon; maxLon+=padLon;
    }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        int w=getWidth(), h=getHeight();
        p.setStyle(Paint.Style.FILL); p.setColor(0xff07120f); c.drawRect(0,0,w,h,p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1); p.setColor(0x5537d67a);
        for(int i=0;i<7;i++){ float x=i*w/6f; c.drawLine(x,0,x,h,p); float y=i*h/6f; c.drawLine(0,y,w,y,p); }
        p.setStyle(Paint.Style.FILL); p.setTextSize(24); p.setColor(0xffd9ffe8);
        c.drawText("BOUH GEO RADAR - Local Data Coverage", 24, 36, p);
        if(targets!=null){
            for(TargetPoint t: targets){
                float x=x(t.lon), y=y(t.lat); float r=(float)(7+12*Math.max(0, Math.min(1, t.score)));
                int color = t.score>=0.70 ? 0xffffd166 : (t.score>=0.62 ? 0xff06d6a0 : 0xff4cc9f0);
                p.setColor(color); p.setStyle(Paint.Style.FILL); c.drawCircle(x,y,r,p);
                p.setColor(0xaa000000); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2); c.drawCircle(x,y,r,p);
            }
        }
        if(!Double.isNaN(selectedLat)){
            float x=x(selectedLon), y=y(selectedLat); p.setColor(0xffff4d6d); p.setStrokeWidth(4); p.setStyle(Paint.Style.STROKE);
            c.drawCircle(x,y,22,p); c.drawLine(x-30,y,x+30,y,p); c.drawLine(x,y-30,x,y+30,p);
        }
    }
    private float x(double lon){ return (float)((lon-minLon)/(maxLon-minLon)*getWidth()); }
    private float y(double lat){ return (float)((maxLat-lat)/(maxLat-minLat)*getHeight()); }
    private double lon(float x){ return minLon + (x/getWidth())*(maxLon-minLon); }
    private double lat(float y){ return maxLat - (y/getHeight())*(maxLat-minLat); }
    @Override public boolean onTouchEvent(MotionEvent e){
        if(e.getAction()==MotionEvent.ACTION_UP){ double la=lat(e.getY()), lo=lon(e.getX()); setSelected(la,lo); if(listener!=null)listener.onPoint(la,lo); return true; }
        return true;
    }
}
