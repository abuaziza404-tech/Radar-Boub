package com.bouh.georadarai;

public class RadarDecision {
    public String label;
    public String reason;
    public double distanceMeters;
    public TargetPoint nearest;
    public boolean insideCoverage;

    public RadarDecision(String label, String reason, double distanceMeters, TargetPoint nearest, boolean insideCoverage) {
        this.label = label; this.reason = reason; this.distanceMeters = distanceMeters;
        this.nearest = nearest; this.insideCoverage = insideCoverage;
    }
}
