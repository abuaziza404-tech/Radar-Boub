# Developer Notes

## Decision Engine

- Outside coverage if nearest local cell > 1500m.
- GPZ FIELD CHECK if score >= 0.70 and structure/alteration/spectral are all supportive.
- CANDIDATE if score >= 0.62 and structure plus alteration or spectral exists.
- HOLD if weak but has at least one support layer.
- REJECT if the chain is incomplete.

## Safety/Truth Rules

- No Target-B without point-specific GPZ/recovered gold/sample/assay.
- KCL is a geological prior only.
- Sentinel uint8/visual layers are relative support only.
- FeOx-only cannot be promoted.
- No random scoring.

## Future Upgrade Path

1. Replace starter SQLite DBs with full V21/V25 pixel databases.
2. Add MBTiles satellite cache in assets or app external storage.
3. Add optional online map tiles when internet exists.
4. Add optional external AI endpoint settings if required by the owner.
5. Add GPZ field form: signal response, depth, soil, quartz, magnetic risk, sample photo.
