# BOUH Geo Radar AI

تطبيق Android فعلي قابل للبناء عبر GitHub Actions. يحتوي على:

- رادار جيولوجي محلي مبني على قواعد SQLite داخل `assets/databases`.
- واجهة خريطة/رادار أصلية Native بدون HTML-only.
- Decision Engine يحترم: `Structure → Pattern → Alteration → Confirmation → Decision`.
- مساعد تحليل ودردشة محلي داخل التطبيق للشرح والمراجعة وتبادل الرأي.
- منع `Math.random` ومنع أي نتيجة وهمية.
- فصل KCL وSentinel visual/uint8 كدعم نسبي/مرجعي فقط.
- لا يرفع Target-B ولا يقول ذهب مؤكد بدون GPZ/sample/assay/QA-QC.

## طريقة الرفع والبناء

1. ارفع محتويات هذه الحزمة إلى مستودع GitHub جديد.
2. افتح تبويب **Actions**.
3. شغّل workflow باسم **Build Android Debug APK**.
4. بعد انتهاء البناء، حمّل ملف APK من Artifacts.

## قواعد البيانات المحلية

المسار:

`app/src/main/assets/databases/`

الملفات الحالية:

- `BOUH_V21_NORTH_MOBILE.db`
- `BOUH_V21_CENTER_MOBILE.db`
- `BOUH_V21_SOUTH_MOBILE.db`

يمكن استبدالها لاحقاً بقواعدك الكاملة بشرط الحفاظ على جدول `targets` بهذه الأعمدة:

`id, region, lat, lon, score, class_type, system_type, spectral, structure, alteration, terrain, kcl, status, notes`

## ملاحظة مهمة

هذه الحزمة تحتوي على نواة تطبيق قابلة للبناء مع بيانات سجل BOUH المثبتة داخل النظام، وليست بديلاً عن قواعد البكسلات الكاملة إذا أردت إدخال كل Sentinel/ASTER/Landsat/DEM. عند توفر قواعدك الكاملة، ضعها بنفس الأسماء وسيقرأها التطبيق مباشرة.
