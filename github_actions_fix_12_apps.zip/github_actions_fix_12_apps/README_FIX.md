# GitHub Actions Fix

ضع الملف التالي في مستودعك:

```text
.github/workflows/build-all-12-android-apks.yml
```

ثم احذف أو عطّل أي Workflow قديم يبني من جذر المستودع مباشرة بهذا الأمر الخاطئ:

```bash
gradle assembleDebug
```

السبب: التطبيقات موجودة داخل `apps/<app-name>/`، لذلك البناء الصحيح هو:

```bash
gradle -p apps/ridego-mobility assembleDebug
```

## خطوات الإصلاح

1. افتح المستودع على GitHub.
2. ادخل إلى:
   ```text
   .github/workflows/
   ```
3. احذف Workflow القديم أو استبدله بالملف الموجود في هذا التصحيح.
4. تأكد أن هيكل المستودع هو:
   ```text
   README.md
   apps/
     aurum-sense-local/
       settings.gradle.kts
       build.gradle.kts
       app/build.gradle.kts
     ridego-mobility/
       settings.gradle.kts
       build.gradle.kts
       app/build.gradle.kts
   .github/
     workflows/
       build-all-12-android-apks.yml
   ```
5. شغّل GitHub Actions من زر:
   ```text
   Run workflow
   ```

## ملاحظة مهمة

إذا رفعت المجلد كاملًا وفي داخله مجلد إضافي مثل:

```text
pro_android_12_app_packages/apps/...
```

فانقل محتويات `pro_android_12_app_packages` إلى جذر المستودع، بحيث يصبح `apps` في الجذر مباشرة.
