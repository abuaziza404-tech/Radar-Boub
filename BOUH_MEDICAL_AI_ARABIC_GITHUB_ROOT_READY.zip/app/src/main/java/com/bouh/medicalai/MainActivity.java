package com.bouh.medicalai;

import android.Manifest;
import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import android.text.*;
import android.text.method.ScrollingMovementMethod;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

public class MainActivity extends Activity {
    LinearLayout root, content;
    TextView title, resultBox, chatLog, sensorBox;
    EditText temp, pulse, spo2, rr, sbp, dbp, age, symptoms, chest, chatInput;
    Button btnHome, btnVitals, btnResp, btnChat, btnSettings, btnAnalyze, btnBreath, btnSend, btnSaveSettings;
    SharedPreferences prefs;
    AtomicBoolean measuring = new AtomicBoolean(false);

    int bg = Color.rgb(9,18,32);
    int card = Color.rgb(16,31,49);
    int teal = Color.rgb(25,167,206);
    int warn = Color.rgb(255,183,77);
    int danger = Color.rgb(239,83,80);
    int good = Color.rgb(102,187,106);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("bouh_medical_ai", MODE_PRIVATE);
        if (Build.VERSION.SDK_INT >= 23) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 100);
        }
        showHome();
    }

    TextView tv(String s, int sp, int color, int style) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(sp);
        v.setTextColor(color);
        v.setTypeface(Typeface.DEFAULT, style);
        v.setGravity(Gravity.RIGHT);
        v.setPadding(14,10,14,10);
        return v;
    }
    EditText input(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(Color.rgb(150,165,180));
        e.setTextColor(Color.WHITE);
        e.setSingleLine(false);
        e.setGravity(Gravity.RIGHT);
        e.setTextDirection(View.TEXT_DIRECTION_RTL);
        e.setBackgroundColor(Color.rgb(21,40,61));
        e.setPadding(14,10,14,10);
        return e;
    }
    Button btn(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextColor(Color.WHITE);
        b.setTextSize(14);
        b.setAllCaps(false);
        b.setBackgroundColor(Color.rgb(11,93,107));
        return b;
    }
    LinearLayout card() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(18,18,18,18);
        l.setBackgroundColor(card);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(10,10,10,10);
        l.setLayoutParams(lp);
        return l;
    }
    void frame(String pageTitle) {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bg);
        root.setPadding(8,8,8,8);

        title = tv("فاحص بوح الطبي | " + pageTitle, 20, Color.WHITE, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setGravity(Gravity.CENTER);
        btnHome = btn("الرئيسية");
        btnVitals = btn("الفحص");
        btnResp = btn("التنفس");
        btnChat = btn("المساعد");
        btnSettings = btn("الإعدادات");
        nav.addView(btnHome); nav.addView(btnVitals); nav.addView(btnResp); nav.addView(btnChat); nav.addView(btnSettings);
        root.addView(nav, new LinearLayout.LayoutParams(-1, -2));

        ScrollView sv = new ScrollView(this);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        sv.addView(content);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);

        btnHome.setOnClickListener(v -> showHome());
        btnVitals.setOnClickListener(v -> showVitals());
        btnResp.setOnClickListener(v -> showResp());
        btnChat.setOnClickListener(v -> showChat());
        btnSettings.setOnClickListener(v -> showSettings());
    }

    void showHome() {
        frame("الرئيسية");
        LinearLayout c = card();
        c.addView(tv("نظام فحص أولي عربي للعلامات الحيوية والصدر والتنفس", 18, teal, Typeface.BOLD));
        c.addView(tv("يدخل المستخدم الحرارة، النبض، الأكسجين، معدل التنفس، ضغط الدم، العمر، والأعراض. التطبيق يعطي مستوى خطورة وإرشاداً أولياً ولا يستبدل الطبيب أو الطوارئ.", 15, Color.WHITE, Typeface.NORMAL));
        c.addView(tv("المخرجات: طبيعي / مراقبة / مراجعة طبيب / طوارئ. لا يعطي تشخيصاً نهائياً ولا يصف أدوية.", 15, warn, Typeface.BOLD));
        content.addView(c);

        LinearLayout c2 = card();
        c2.addView(tv("الوحدات", 18, teal, Typeface.BOLD));
        c2.addView(tv("• فحص العلامات الحيوية\n• فحص الصدر والتنفس\n• مساعد طبي عربي محلي\n• إعدادات ربط AI اختياري\n• سياسة خصوصية محلية", 15, Color.WHITE, Typeface.NORMAL));
        content.addView(c2);
    }

    void showVitals() {
        frame("الفحص الطبي الأولي");
        LinearLayout c = card();
        age = input("العمر بالسنوات");
        temp = input("درجة الحرارة °C مثال 37.2");
        pulse = input("النبض / دقيقة مثال 82");
        spo2 = input("الأكسجين SpO2 % مثال 97");
        rr = input("معدل التنفس / دقيقة مثال 18");
        sbp = input("الضغط الانقباضي مثال 120");
        dbp = input("الضغط الانبساطي مثال 80");
        symptoms = input("الأعراض: ألم صدر، ضيق نفس، سعال، دوخة، إغماء، حرارة، تعب...");
        chest = input("وصف الصدر والتنفس: صفير، كتمة، ألم مع النفس، بلغم، زرقة، تعرق...");
        c.addView(age); c.addView(temp); c.addView(pulse); c.addView(spo2); c.addView(rr); c.addView(sbp); c.addView(dbp); c.addView(symptoms); c.addView(chest);
        btnAnalyze = btn("تحليل الحالة الآن");
        c.addView(btnAnalyze);
        resultBox = tv("أدخل البيانات ثم اضغط التحليل.", 16, Color.WHITE, Typeface.NORMAL);
        resultBox.setTextIsSelectable(true);
        c.addView(resultBox);
        content.addView(c);
        btnAnalyze.setOnClickListener(v -> analyzeVitals());
    }

    double d(EditText e, double fallback) {
        try { return Double.parseDouble(e.getText().toString().trim().replace(",", ".")); }
        catch(Exception ex) { return fallback; }
    }
    String s(EditText e) { return e.getText().toString().toLowerCase(Locale.ROOT); }

    void analyzeVitals() {
        double a=d(age,-1), t=d(temp,-1), p=d(pulse,-1), o=d(spo2,-1), r=d(rr,-1), hi=d(sbp,-1), lo=d(dbp,-1);
        String sy=s(symptoms)+" "+s(chest);
        int score=0; ArrayList<String> reasons=new ArrayList<>();

        if (sy.contains("ألم صدر") || sy.contains("الم صدر") || sy.contains("ضغط بالصدر")) { score+=35; reasons.add("ألم/ضغط في الصدر"); }
        if (sy.contains("ضيق نفس") || sy.contains("اختناق") || sy.contains("زرقة") || sy.contains("ازرق")) { score+=35; reasons.add("ضيق نفس أو زرقة"); }
        if (sy.contains("إغماء") || sy.contains("اغماء") || sy.contains("فقدان وعي")) { score+=40; reasons.add("إغماء أو فقدان وعي"); }
        if (o>0 && o<90) { score+=45; reasons.add("SpO2 أقل من 90%"); }
        else if (o>=90 && o<94) { score+=25; reasons.add("SpO2 منخفض"); }
        if (r>30) { score+=30; reasons.add("معدل التنفس مرتفع جداً"); }
        else if (r>24) { score+=15; reasons.add("معدل التنفس مرتفع"); }
        if (p>130 || (p>0 && p<45)) { score+=25; reasons.add("نبض غير مطمئن"); }
        else if (p>110) { score+=12; reasons.add("نبض مرتفع"); }
        if (t>=39.5 || (t>0 && t<35)) { score+=20; reasons.add("حرارة شديدة أو انخفاض حرارة"); }
        else if (t>=38) { score+=8; reasons.add("حرارة مرتفعة"); }
        if (hi>=180 || lo>=120) { score+=35; reasons.add("ضغط مرتفع جداً"); }
        else if (hi>=160 || lo>=100) { score+=15; reasons.add("ضغط مرتفع"); }
        if (a>=65 && score>0) { score+=8; reasons.add("العمر يزيد حساسية الخطر"); }

        String level; int color;
        if (score>=60) { level="طوارئ عالية: اطلب إسعاف/طوارئ فوراً خصوصاً مع ألم صدر أو ضيق نفس أو أكسجين منخفض."; color=danger; }
        else if (score>=35) { level="خطر متوسط إلى عالٍ: راجع طبيباً اليوم ولا تؤجل، واذهب للطوارئ إذا زاد ضيق النفس أو ألم الصدر."; color=warn; }
        else if (score>=15) { level="مراقبة ومراجعة: توجد مؤشرات تحتاج متابعة وقياس متكرر ومراجعة إذا استمرت."; color=warn; }
        else { level="مبدئياً المؤشرات المدخلة غير عالية الخطورة، مع بقاء الحكم للطبيب والفحص السريري."; color=good; }

        StringBuilder out=new StringBuilder();
        out.append("النتيجة الأولية:\n").append(level).append("\n\n");
        out.append("درجة الخطورة الداخلية: ").append(score).append("/100\n");
        out.append("الأسباب:\n");
        if(reasons.isEmpty()) out.append("• لا توجد أسباب خطرة واضحة من المدخلات.\n");
        else for(String x: reasons) out.append("• ").append(x).append("\n");
        out.append("\nتنبيه: هذا فرز أولي وليس تشخيصاً نهائياً. لا تعتمد عليه لعلاج أو إيقاف علاج. في ألم صدر شديد، ضيق نفس، زرقة، إغماء، تشوش، أو SpO2 منخفض: الطوارئ أولاً.");
        resultBox.setText(out.toString());
        resultBox.setTextColor(color);
    }

    void showResp() {
        frame("استشعار التنفس والصدر");
        LinearLayout c = card();
        c.addView(tv("قياس تنفّس تقريبي", 18, teal, Typeface.BOLD));
        c.addView(tv("هذه الوحدة لا تشخص مرضاً. يمكن استخدامها كمؤقت يساعدك على عدّ الأنفاس يدوياً لمدة 30 ثانية ثم يحسب المعدل بالدقيقة. وحدة الميكروفون تجريبية وغير طبية.", 15, warn, Typeface.BOLD));
        btnBreath = btn("ابدأ عدّ 30 ثانية للتنفس");
        c.addView(btnBreath);
        sensorBox = tv("اضغط البدء، وعدّ عدد مرات التنفس خلال 30 ثانية.", 16, Color.WHITE, Typeface.NORMAL);
        c.addView(sensorBox);
        content.addView(c);
        btnBreath.setOnClickListener(v -> startBreathTimer());
    }

    void startBreathTimer() {
        final int[] sec = {30};
        measuring.set(true);
        sensorBox.setText("بدأ العد: 30 ثانية. عدّ النفس يدوياً الآن...");
        Handler h=new Handler();
        Runnable run=new Runnable(){ public void run(){
            sec[0]--;
            if(sec[0]>0 && measuring.get()) {
                sensorBox.setText("باقي " + sec[0] + " ثانية. استمر في العد اليدوي.");
                h.postDelayed(this,1000);
            } else {
                measuring.set(false);
                final EditText breaths=input("أدخل عدد الأنفاس التي عدّيتها خلال 30 ثانية");
                new AlertDialog.Builder(MainActivity.this)
                    .setTitle("إدخال عدد الأنفاس")
                    .setView(breaths)
                    .setPositiveButton("احسب", (d,w)-> {
                        double count = d(breaths, -1);
                        double perMin = count*2;
                        String msg="معدل التنفس التقريبي: " + perMin + " / دقيقة\n";
                        if(perMin>30) msg += "مرتفع جداً: راجع الطوارئ إذا يوجد ضيق نفس/ألم صدر/زرقة.";
                        else if(perMin>24) msg += "مرتفع: يحتاج متابعة ومراجعة طبية إذا استمر.";
                        else if(perMin>=12 && perMin<=20) msg += "ضمن الشائع للبالغين في الراحة.";
                        else msg += "منخفض/غير معتاد أو القياس غير دقيق؛ أعد القياس وراجع الطبيب عند وجود أعراض.";
                        sensorBox.setText(msg);
                    })
                    .setNegativeButton("إلغاء", null)
                    .show();
            }
        }};
        h.postDelayed(run,1000);
    }

    void showChat() {
        frame("المساعد الطبي العربي");
        LinearLayout c=card();
        c.addView(tv("اسأل عن الأعراض أو اطلب تفسير نتيجة الفحص. المساعد يعطي فرزاً أولياً لا تشخيصاً نهائياً.", 15, warn, Typeface.BOLD));
        chatLog=tv("المساعد: أهلاً، اكتب الأعراض والعمر والحرارة والنبض والأكسجين إن وجدت.\n", 15, Color.WHITE, Typeface.NORMAL);
        chatLog.setMovementMethod(new ScrollingMovementMethod());
        chatLog.setTextIsSelectable(true);
        chatInput=input("اكتب سؤالك الطبي هنا...");
        btnSend=btn("إرسال");
        c.addView(chatLog); c.addView(chatInput); c.addView(btnSend);
        content.addView(c);
        btnSend.setOnClickListener(v -> sendChat());
    }

    void sendChat() {
        String q=chatInput.getText().toString().trim();
        if(q.length()==0) return;
        String ans=localMedicalAssistant(q);
        chatLog.append("\nأنت: "+q+"\nالمساعد: "+ans+"\n");
        chatInput.setText("");
        try { ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(chatInput.getWindowToken(),0); } catch(Exception e){}
    }

    String localMedicalAssistant(String q) {
        String x=q.toLowerCase(Locale.ROOT);
        if(x.contains("ألم صدر")||x.contains("الم صدر")||x.contains("ضيق نفس")||x.contains("زرقة")||x.contains("إغماء")||x.contains("اغماء")) {
            return "هذه أعراض إنذار. إذا الألم شديد أو مع ضيق نفس/تعرّق/دوخة/إغماء أو أكسجين منخفض، الأفضل التوجه للطوارئ فوراً. أخبرني بالعمر، SpO2، النبض، الضغط، ومدة الأعراض لفرز أدق.";
        }
        if(x.contains("حرارة")||x.contains("حمى")) {
            return "الحرارة تحتاج قياساً رقمياً. حرارة 38 فأعلى تُعد مرتفعة غالباً، و39.5 أو أكثر مع خمول شديد/ضيق نفس/تيبس رقبة/تشوش تستدعي مراجعة عاجلة. اشرب سوائل وراجع الطبيب إذا استمرت أو ظهرت علامات خطر.";
        }
        if(x.contains("سعال")||x.contains("بلغم")||x.contains("صدر")) {
            return "السعال مع ضيق نفس، ألم صدر، بلغم دموي، صفير شديد، أو أكسجين أقل من 94% يحتاج مراجعة طبية. اكتب مدة السعال والحرارة ولون البلغم وهل يوجد ربو أو تدخين.";
        }
        if(x.contains("ضغط")) {
            return "ضغط 180/120 أو أعلى، خصوصاً مع ألم صدر/صداع شديد/تشوش/ضيق نفس، حالة عاجلة. القياس يجب أن يكرر بعد راحة 5 دقائق وبجهاز موثوق.";
        }
        if(x.contains("سكر")||x.contains("سكري")) {
            return "اضطراب السكر يحتاج رقم قياس. هبوط السكر مع تعرق/رجفة/تشوش يحتاج تصرفاً سريعاً حسب تعليمات الطبيب. التطبيق لا يحدد جرعات أدوية.";
        }
        return "أحتاج بيانات أكثر: العمر، الجنس، مدة الأعراض، الحرارة، النبض، SpO2، الضغط، والأمراض المزمنة. أستطيع فرز الخطورة واقتراح هل الحالة مراقبة أم مراجعة طبيب أم طوارئ، لكن لا أعطي تشخيصاً نهائياً.";
    }

    void showSettings() {
        frame("الإعدادات والخصوصية");
        LinearLayout c=card();
        c.addView(tv("إعدادات AI اختياري", 18, teal, Typeface.BOLD));
        EditText endpoint=input("رابط خدمة AI اختياري");
        endpoint.setText(prefs.getString("endpoint",""));
        EditText key=input("مفتاح API اختياري - لا تضعه في GitHub");
        key.setText(prefs.getString("key",""));
        EditText model=input("اسم النموذج اختياري");
        model.setText(prefs.getString("model",""));
        btnSaveSettings=btn("حفظ الإعدادات محلياً");
        c.addView(endpoint); c.addView(key); c.addView(model); c.addView(btnSaveSettings);
        c.addView(tv("الخصوصية: البيانات المدخلة تبقى داخل الهاتف في هذه النسخة. لا ترسل أي بيانات طبية إلى خدمة خارجية إلا إذا فعّلت أنت ربط AI ووضعت مفتاحاً بنفسك.", 15, Color.WHITE, Typeface.NORMAL));
        c.addView(tv("تحذير طبي: التطبيق فرز أولي وليس جهازاً طبياً معتمداً ولا بديل طبيب/طوارئ.", 15, danger, Typeface.BOLD));
        content.addView(c);
        btnSaveSettings.setOnClickListener(v -> {
            prefs.edit().putString("endpoint", endpoint.getText().toString())
                .putString("key", key.getText().toString())
                .putString("model", model.getText().toString()).apply();
            Toast.makeText(this, "تم الحفظ محلياً", Toast.LENGTH_SHORT).show();
        });
    }
}
