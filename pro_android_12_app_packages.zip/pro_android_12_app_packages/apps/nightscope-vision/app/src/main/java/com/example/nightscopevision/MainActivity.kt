package com.example.nightscopevision
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

@Composable
fun App() {
    MaterialTheme {
        Surface(Modifier.fillMaxSize()) {
            var input by remember { mutableStateOf("") }
            var result by remember { mutableStateOf("جاهز للتجربة") }
            val features = listOf(
    "تكبير رقمي",
    "وضع إضاءة منخفضة محاكى",
    "فلتر تباين",
    "التقاط ملاحظات"
            )
            Column(Modifier.padding(20.dp)) {
                Text("NightScope Vision", style = MaterialTheme.typography.headlineMedium)
                Text("دربيل ليلي رقمي", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(12.dp))
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("حدود النموذج", style = MaterialTheme.typography.titleMedium)
                        Text("تحسين رقمي للصورة والكاميرا المتاحة فقط، ولا يحول الهاتف إلى رؤية ليلية عسكرية أو حرارية حقيقية.")
                    }
                }
                Spacer(Modifier.height(16.dp))
                OutlinedTextField(value=input, onValueChange={input=it}, label={Text("أدخل بيانات التجربة")}, modifier=Modifier.fillMaxWidth())
                Spacer(Modifier.height(12.dp))
                Button(modifier=Modifier.fillMaxWidth(), onClick={ result = "تم تشغيل نموذج MVP على: " + input.ifBlank { "بيانات افتراضية" } }) {
                    Text("تشغيل النموذج")
                }
                Spacer(Modifier.height(16.dp))
                Text("النتيجة", style = MaterialTheme.typography.titleMedium)
                Text(result)
                Spacer(Modifier.height(16.dp))
                Text("الوحدات المبدئية", style = MaterialTheme.typography.titleMedium)
                features.forEach { Text("• " + it) }
            }
        }
    }
}
