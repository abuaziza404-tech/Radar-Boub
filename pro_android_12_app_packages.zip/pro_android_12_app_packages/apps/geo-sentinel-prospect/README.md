# GeoSentinel Prospect — مسح جيولوجي Sentinel-2 وGEE

    ## الوصف
    تحليل مؤشرات طيفية تعليمية باستخدام Sentinel-2 وGoogle Earth Engine عند توفير حساب ومفاتيح، وليس ضمانًا لوجود ذهب.

    ## الميزات
    - مؤشرات طيفية
- قوالب GEE
- طبقات Sentinel-2
- تقرير احتمالية

    ## بناء APK
    ```bash
    gradle assembleDebug
    ```

    ## APK
    ```text
    app/build/outputs/apk/debug/app-debug.apk
    ```

    ## ملاحظة
    المشروع Starter MVP قابل للتطوير، وليس منتجًا إنتاجيًا نهائيًا.
