var aoi = /* your geometry */;
var s2 = ee.ImageCollection('COPERNICUS/S2_SR_HARMONIZED')
  .filterBounds(aoi)
  .filterDate('2024-01-01', '2024-12-31')
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20))
  .median();
var ironOxide = s2.select('B4').divide(s2.select('B2')).rename('Iron_Oxide');
var clay = s2.select('B11').divide(s2.select('B12')).rename('Clay_Minerals');
Map.centerObject(aoi, 10);
Map.addLayer(ironOxide, {min: 0.5, max: 3}, 'Iron Oxide');
Map.addLayer(clay, {min: 0.5, max: 2}, 'Clay Minerals');
