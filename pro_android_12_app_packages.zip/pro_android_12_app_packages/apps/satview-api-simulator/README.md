# SatView API Simulator — محاكي صور أقمار صناعية عبر API

    ## الوصف
    عارض صور أقمار عبر APIs أو بيانات مخزنة؛ لا يولد صورًا مباشرة لحظية للأرض دون مصدر رسمي وترخيص.

    ## الميزات
    - اختيار إحداثيات
- طلب صورة API
- كاش Offline
- مقارنة تواريخ

    ## بناء APK
    ```bash
    gradle assembleDebug
    ```

    ## APK
    ```text
    app/build/outputs/apk/debug/app-debug.apk
    ```

    ## ملاحظة
    المشروع Starter MVP قابل للتطوير، وليس منتجًا إنتاجيًا نهائيًا.
