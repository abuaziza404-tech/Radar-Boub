# Terra Offline Navigator — خرائط وملاحة بدون إنترنت

    ## الوصف
    ملاحة Offline باستخدام خرائط وملفات GPX/MBTiles يضيفها المستخدم، بدون نسخ ميزات أو بيانات تطبيقات تجارية.

    ## الميزات
    - واجهة مسارات بدون إنترنت
- إدارة نقاط Waypoints
- استيراد GPX لاحقًا
- بوصلة ومسافة تقديرية

    ## بناء APK
    ```bash
    gradle assembleDebug
    ```

    ## APK
    ```text
    app/build/outputs/apk/debug/app-debug.apk
    ```

    ## ملاحظة
    المشروع Starter MVP قابل للتطوير، وليس منتجًا إنتاجيًا نهائيًا.
