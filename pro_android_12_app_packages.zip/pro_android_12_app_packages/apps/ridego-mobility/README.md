# RideGo Mobility — محاكي Uber للمشاوير

    ## الوصف
    MVP مشروع مشاوير مع Backend تجريبي، يحتاج خرائط ودفع وتراخيص وتشغيل فعلي للإنتاج.

    ## الميزات
    - طلب رحلة
- سائق وراكب
- سعر تقديري
- حالة الرحلة

    ## بناء APK
    ```bash
    gradle assembleDebug
    ```

    ## APK
    ```text
    app/build/outputs/apk/debug/app-debug.apk
    ```

    ## ملاحظة
    المشروع Starter MVP قابل للتطوير، وليس منتجًا إنتاجيًا نهائيًا.
