# AstroWeather Orbit — تنبؤ الطقس والفضاء والأقمار

    ## الوصف
    واجهة توقعات تعتمد على API أو بيانات مخزنة، ولا تدعي توقعات فضائية دقيقة دون مصادر رسمية.

    ## الميزات
    - طقس محلي
- نشاط شمسي تجريبي
- مرور أقمار
- تخزين آخر بيانات Offline

    ## بناء APK
    ```bash
    gradle assembleDebug
    ```

    ## APK
    ```text
    app/build/outputs/apk/debug/app-debug.apk
    ```

    ## ملاحظة
    المشروع Starter MVP قابل للتطوير، وليس منتجًا إنتاجيًا نهائيًا.
