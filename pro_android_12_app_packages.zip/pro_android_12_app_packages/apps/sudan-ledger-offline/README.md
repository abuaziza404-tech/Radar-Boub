# Sudan Ledger Offline — محفظة تحويلات Offline تجريبية

    ## الوصف
    دفتر حسابات وتجربة USSD/SMS فقط، ولا ينفذ تحويل أموال حقيقي أو خدمات مصرفية دون ترخيص وربط رسمي.

    ## الميزات
    - دفتر معاملات محلي
- تحضير رسالة أو USSD
- سجل أرصدة تجريبي
- تحذيرات امتثال مصرفي

    ## بناء APK
    ```bash
    gradle assembleDebug
    ```

    ## APK
    ```text
    app/build/outputs/apk/debug/app-debug.apk
    ```

    ## ملاحظة
    المشروع Starter MVP قابل للتطوير، وليس منتجًا إنتاجيًا نهائيًا.
