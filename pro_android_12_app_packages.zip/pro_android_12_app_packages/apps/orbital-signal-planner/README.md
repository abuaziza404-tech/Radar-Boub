# Orbital Signal Planner — مخطط إشارات GPS والإنترنت الفضائي

    ## الوصف
    مخطط تعليمي للإشارات والتغطية؛ لا يتصل بـ Starlink أو الإنترنت الفضائي بدون طرفية أرضية مرخصة.

    ## الميزات
    - مؤشر تغطية تقديري
- GPS status shell
- توعية بالعتاد المطلوب
- سجل مواقع

    ## بناء APK
    ```bash
    gradle assembleDebug
    ```

    ## APK
    ```text
    app/build/outputs/apk/debug/app-debug.apk
    ```

    ## ملاحظة
    المشروع Starter MVP قابل للتطوير، وليس منتجًا إنتاجيًا نهائيًا.
