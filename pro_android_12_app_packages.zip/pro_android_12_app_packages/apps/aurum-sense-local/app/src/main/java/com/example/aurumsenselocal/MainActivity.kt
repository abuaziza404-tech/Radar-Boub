package com.example.aurumsenselocal
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

@Composable
fun App() {
    MaterialTheme {
        Surface(Modifier.fillMaxSize()) {
            var input by remember { mutableStateOf("") }
            var result by remember { mutableStateOf("جاهز للتجربة") }
            val features = listOf(
    "إدخال إحداثيات وملاحظات ميدانية",
    "حساب درجة احتمالية تعليمية",
    "حفظ نقاط محلية",
    "تصدير بيانات CSV لاحقًا"
            )
            Column(Modifier.padding(20.dp)) {
                Text("AurumSense Local", style = MaterialTheme.typography.headlineMedium)
                Text("رادار استشعار الذهب المحلي", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(12.dp))
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("حدود النموذج", style = MaterialTheme.typography.titleMedium)
                        Text("محلل مؤشرات محلية وجيولوجية للذهب، وليس رادارًا حقيقيًا لاكتشاف الذهب عبر الهاتف.")
                    }
                }
                Spacer(Modifier.height(16.dp))
                OutlinedTextField(value=input, onValueChange={input=it}, label={Text("أدخل بيانات التجربة")}, modifier=Modifier.fillMaxWidth())
                Spacer(Modifier.height(12.dp))
                Button(modifier=Modifier.fillMaxWidth(), onClick={ result = "تم تشغيل نموذج MVP على: " + input.ifBlank { "بيانات افتراضية" } }) {
                    Text("تشغيل النموذج")
                }
                Spacer(Modifier.height(16.dp))
                Text("النتيجة", style = MaterialTheme.typography.titleMedium)
                Text(result)
                Spacer(Modifier.height(16.dp))
                Text("الوحدات المبدئية", style = MaterialTheme.typography.titleMedium)
                features.forEach { Text("• " + it) }
            }
        }
    }
}
