# Nexus AI Assistant — مساعد ذكاء اصطناعي

    ## الوصف
    مساعد AI بنمط دردشة مع مفتاح API خاص بالمستخدم، وليس نسخة من ChatGPT Plus أو التفافًا على خدمات مدفوعة.

    ## الميزات
    - واجهة دردشة
- ذاكرة محلية اختيارية
- مفاتيح API عبر الإعدادات
- قوالب أوامر

    ## بناء APK
    ```bash
    gradle assembleDebug
    ```

    ## APK
    ```text
    app/build/outputs/apk/debug/app-debug.apk
    ```

    ## ملاحظة
    المشروع Starter MVP قابل للتطوير، وليس منتجًا إنتاجيًا نهائيًا.
