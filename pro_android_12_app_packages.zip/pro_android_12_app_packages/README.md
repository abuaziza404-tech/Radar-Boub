# Pro Android 12 App Packages

حزمة تضم 12 مشروع Android مستقلًا وجاهزًا للرفع إلى GitHub Actions.

1. `aurum-sense-local` — AurumSense Local: محلل مؤشرات محلية وجيولوجية للذهب، وليس رادارًا حقيقيًا لاكتشاف الذهب عبر الهاتف.
2. `terra-offline-navigator` — Terra Offline Navigator: ملاحة Offline باستخدام خرائط وملفات GPX/MBTiles يضيفها المستخدم، بدون نسخ ميزات أو بيانات تطبيقات تجارية.
3. `sudan-ledger-offline` — Sudan Ledger Offline: دفتر حسابات وتجربة USSD/SMS فقط، ولا ينفذ تحويل أموال حقيقي أو خدمات مصرفية دون ترخيص وربط رسمي.
4. `med-triage-simulator` — Med Triage Simulator: أداة فرز أولي وتثقيف صحي لا تقدم تشخيصًا طبيًا نهائيًا ولا تستبدل الطبيب أو الطوارئ.
5. `astro-weather-orbit` — AstroWeather Orbit: واجهة توقعات تعتمد على API أو بيانات مخزنة، ولا تدعي توقعات فضائية دقيقة دون مصادر رسمية.
6. `nexus-ai-assistant` — Nexus AI Assistant: مساعد AI بنمط دردشة مع مفتاح API خاص بالمستخدم، وليس نسخة من ChatGPT Plus أو التفافًا على خدمات مدفوعة.
7. `ridego-mobility` — RideGo Mobility: MVP مشروع مشاوير مع Backend تجريبي، يحتاج خرائط ودفع وتراخيص وتشغيل فعلي للإنتاج.
8. `nightscope-vision` — NightScope Vision: تحسين رقمي للصورة والكاميرا المتاحة فقط، ولا يحول الهاتف إلى رؤية ليلية عسكرية أو حرارية حقيقية.
9. `geo-sentinel-prospect` — GeoSentinel Prospect: تحليل مؤشرات طيفية تعليمية باستخدام Sentinel-2 وGoogle Earth Engine عند توفير حساب ومفاتيح، وليس ضمانًا لوجود ذهب.
10. `satview-api-simulator` — SatView API Simulator: عارض صور أقمار عبر APIs أو بيانات مخزنة؛ لا يولد صورًا مباشرة لحظية للأرض دون مصدر رسمي وترخيص.
11. `orbital-signal-planner` — Orbital Signal Planner: مخطط تعليمي للإشارات والتغطية؛ لا يتصل بـ Starlink أو الإنترنت الفضائي بدون طرفية أرضية مرخصة.
12. `drone-earth-hd-sim` — Drone Earth HD Sim: محاكي عرض صور أرضية عالية الدقة من مصادر خرائط/صور مرخصة، وليس بث درون حقيقي أو اختراق كاميرات.

## التشغيل

كل تطبيق موجود داخل `apps/<app-slug>`.

```bash
cd apps/ridego-mobility
gradle assembleDebug
```

## GitHub Actions

Workflow واحد يبني جميع التطبيقات ويرفع APK لكل تطبيق كـ Artifact:

```text
.github/workflows/build-all-android-apps.yml
```

## تنبيه

هذه Starter Kits آمنة وقابلة للتطوير، وبعضها محاكاة أو واجهة API لأن التنفيذ الحقيقي يحتاج تراخيص أو عتاد أو مصادر بيانات رسمية.
