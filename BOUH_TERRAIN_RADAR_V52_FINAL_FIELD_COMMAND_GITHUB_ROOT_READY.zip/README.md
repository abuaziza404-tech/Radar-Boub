# BOUH Terrain Radar V52 — Final Field Command

نسخة نهائية ميدانية محدثة من تطبيق بوح التضاريس.

## ماذا تغير؟

- التطبيق يفتح مباشرة داخل مناطقك: أربعات / غرب بورتسودان.
- لا يوجد قفل للخريطة: يمكنك التحرك والتصفح بحرية خارج النطاق.
- لا يتم إعطاء تحليل أو Score عشوائي خارج خلايا التغطية الحقيقية.
- HOME / CENTER / NORTH / SOUTH للرجوع السريع إلى نطاقات بوح.
- واجهة أخف وأنظف للهاتف: إحداثيات مصغرة، رادار أقل إزعاجاً، وأدوات ميدانية مرتبة.
- قاعدة البيانات الحقيقية محفوظة: BOUH_V30_REAL_3ZONES.db.
- versionCode 52 / versionName 52.0.0-final-field-command-unlocked-map.

## البناء

ارفع ملف ZIP في جذر مستودع GitHub، وضع ملف workflow داخل:

`.github/workflows/main.yml`

ثم شغّل Actions لبناء APK.

## ملاحظة تشغيلية

النتائج Field-check / Prospectivity فقط، ولا تثبت الذهب اقتصادياً دون GPZ/ذهب مستخرج/assay/QAQC.
