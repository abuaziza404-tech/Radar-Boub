# BOUH V59 Field UI Cleanup + Radar Logic Guard

V59 preserves V52 UI sections and Android structure while cleaning map clutter and guarding the V58 data precision model.

## Changes
- Hidden heavy target/cell dots by default; added toggle in Targets panel for top 80 cells only.
- Coverage rectangles reduced to subtle zone frames only.
- Default view starts closer to field-level zoom.
- Header compacted and radar remains visible but less obstructive.
- Database guarded: single Alteration or FeOx cannot lift a cell to Candidate/GPZ without Structure + Drainage + spectral support.
- Java now refreshes bundled DB on app start to avoid stale DB after app upgrade.

## DB guard counts
```json
{
  "cap_alteration_solo": 8389,
  "cap_feox_solo": 4216,
  "cap_no_structure_no_silica": 9581,
  "downgrade_gpz": 73,
  "downgrade_candidate": 10,
  "unchanged": 71310
}
```

## Zone QC
```json
{
  "A2_LOADER_EXPANSION": {
    "count": 1,
    "min": 80,
    "max": 80,
    "avg": 80.0
  },
  "A6_MOUNTAIN_FEEDER": {
    "count": 1,
    "min": 78,
    "max": 78,
    "avg": 78.0
  },
  "ARB_T3_STRUCTURAL_JOG": {
    "count": 1,
    "min": 80,
    "max": 80,
    "avg": 80.0
  },
  "CENTER": {
    "count": 30750,
    "min": 0,
    "max": 91,
    "avg": 49.22
  },
  "NORTH": {
    "count": 30750,
    "min": 0,
    "max": 96,
    "avg": 55.34
  },
  "SOUTH": {
    "count": 30750,
    "min": 0,
    "max": 91,
    "avg": 50.38
  }
}
```

## Class counts after guard
- Reject/Low: 49462
- HOLD: 40501
- Candidate: 2044
- GPZ Field Check: 246

Solo Alteration cells still >=74 after guard: 0
