# BOUH Terrain Radar V55 — Field Radar Map Restored

This is the corrected branch after the native no-HTML experiment.

- Radar and map interface restored.
- Local offline HTML UI inside APK assets, not an online website.
- No INTERNET permission.
- Local offline RGB/SWIR layers.
- Internal SQLite radar database: BOUH_V30_REAL_3ZONES.db.
- Starts in Arbaat / West Port Sudan.
- Map is unlocked; outside real coverage the engine returns NO REAL COVERAGE rather than random scores.

Build with GitHub Actions using `.github/workflows/build-apk.yml`.
