# BUILD_REPORT.md — v15.0 Plan 1 BOUH Radar Standalone

## الهدف

الخطة 1 تفصل تطبيق الرادار وحده ليكون أول تطبيق مستقل ضمن منظومة بوح:

```text
BOUH Radar
خريطة → مركز الشاشة → بحث محلي في 4303 خلية → Ground Score → تقرير نقطة
```

## ما تم تنفيذه

- تحويل الواجهة إلى تطبيق Radar-first مستقل.
- جعل الشاشة الافتراضية هي الرادار.
- الإبقاء فقط على:
  - الرادار
  - التقارير المختصرة
  - مكتبة البيانات المختصرة
- إزالة مركز الأنظمة والسلامة والإعدادات من تطبيق الرادار المستقل.
- تغيير app package إلى:
  - `com.bouh.radar`
- تغيير اسم التطبيق إلى:
  - `BOUH Radar`
- إضافة workflow مستقل:
  - `.github/workflows/bouh-radar-build.yml`
- إضافة خطة:
  - `PLAN_1_BOUH_RADAR_STANDALONE.md`

## البيانات المحلية

```text
compact data = apps/web/public/data/bouh_ground_grid_compact.json
compact cells = 4303
compact sha256 = caedab8f958013fd1b41625f80950a4b29f689cb74b674369467f29a304287f9
```

## سلامة التحليل

لم يتم تغيير:

```text
data/precomputed/bouh_ground_grid.sqlite
ground_cells = 4303
truth_status = partial_raw_grid_landsat_dem_not_full_spectral
الأوزان
أسماء الحقول
live-score repository logic
```

Top cell remains:

```text
cell_id = partial_raw_0004117
lat = 19.41022162800518
lng = 36.86820999932388
final_ground_score = 66.0
class = Class C
truth_status = partial_raw_grid_landsat_dem_not_full_spectral
```

## سياسة علمية ثابتة

```text
partial ready analyzed ground grid from Landsat/DEM
No Gold Proof
No Depth
No 100%
No Gold Target
Surface screening only
Field-check only
```

## Build status

```text
npm install = passed
npm run build = passed
npm run build:strict = passed
Capacitor sync Android = passed
```

## APK/AAB

يتم إنتاج APK/AAB عبر GitHub Actions:

```text
BOUH-RADAR-v15-0-APK-AAB
BOUH_RADAR_v15_0_ANDROID_ARTIFACTS.zip
```
