package com.abuaziza.bouhsupreme

import com.abuaziza.bouhsupreme.domain.*
import kotlin.test.Test
import kotlin.test.assertFalse
import kotlin.test.assertTrue

class EvidenceValidatorTest {
    private val validator = EvidenceValidator()

    @Test
    fun visualCannotCarryNumericClaim() {
        val result = validator.validate(
            EvidenceInput(
                evidenceType = EvidenceType.Alteration,
                sourceType = SourceType.Visual,
                tag = EvidenceTag.VisualNonComputational,
                description = "Google Earth image",
                numericValue = 0.9
            )
        )
        assertFalse(result.valid)
    }

    @Test
    fun rawNumericAccepted() {
        val result = validator.validate(
            EvidenceInput(
                evidenceType = EvidenceType.Alteration,
                sourceType = SourceType.Raw,
                tag = EvidenceTag.RealData,
                description = "GeoTIFF derived index",
                numericValue = 0.42
            )
        )
        assertTrue(result.valid)
    }
}
