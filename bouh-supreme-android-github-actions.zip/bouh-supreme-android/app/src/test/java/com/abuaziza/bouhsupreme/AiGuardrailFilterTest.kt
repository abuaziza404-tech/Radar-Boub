package com.abuaziza.bouhsupreme

import com.abuaziza.bouhsupreme.ai.AiGuardrailFilter
import kotlin.test.Test
import kotlin.test.assertFalse
import kotlin.test.assertTrue

class AiGuardrailFilterTest {
    private val filter = AiGuardrailFilter()

    @Test
    fun blocksUnsupportedTargetBUpgrade() {
        val result = filter.filter("هذا Target-B", localDecisionClass = "HOLD", presentationMode = false)
        assertFalse(result.allowed)
    }

    @Test
    fun masksCoordinatesInPresentation() {
        val result = filter.filter("Location 18.12345, 37.12345", localDecisionClass = "HOLD", presentationMode = true)
        assertTrue(result.safeText.contains("[masked coordinates]"))
    }
}
