package com.abuaziza.bouhsupreme

import com.abuaziza.bouhsupreme.domain.BouhKillMatrixEngine
import com.abuaziza.bouhsupreme.domain.DecisionClass
import com.abuaziza.bouhsupreme.domain.TargetEvidence
import kotlin.test.Test
import kotlin.test.assertEquals

class BouhKillMatrixEngineTest {
    private val engine = BouhKillMatrixEngine()

    @Test
    fun noStructureRejects() {
        val result = engine.classify(TargetEvidence(hasStructure = false, hasPattern = true))
        assertEquals(DecisionClass.Reject, result.decisionClass)
    }

    @Test
    fun visualOnlyMaxVisualCandidate() {
        val result = engine.classify(TargetEvidence(hasStructure = true, hasPattern = true, isVisualOnly = true))
        assertEquals(DecisionClass.VisualCandidate, result.decisionClass)
    }

    @Test
    fun feOxOnlyLowHold() {
        val result = engine.classify(TargetEvidence(hasStructure = true, hasPattern = true, isFeOxOnly = true))
        assertEquals(DecisionClass.LowHOLD, result.decisionClass)
    }

    @Test
    fun targetBRequiresAllGates() {
        val result = engine.classify(
            TargetEvidence(
                hasStructure = true,
                hasPattern = true,
                hasConfirmedAlteration = true,
                hasConfirmation = true,
                noiseControlled = true
            )
        )
        assertEquals(DecisionClass.TargetB, result.decisionClass)
    }
}
