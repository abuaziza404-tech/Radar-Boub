package com.abuaziza.bouhsupreme.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.abuaziza.bouhsupreme.data.BouhRepository
import com.abuaziza.bouhsupreme.ui.screens.*

enum class AppScreen(val titleAr: String, val titleEn: String) {
    Dashboard("الرئيسية", "Dashboard"),
    Projects("المشاريع", "Projects"),
    Targets("الأهداف", "Targets"),
    Assistant("المساعد", "Assistant"),
    Reports("التقارير", "Reports"),
    Settings("الإعدادات", "Settings")
}

@Composable
fun BouhSupremeApp(repository: BouhRepository) {
    var screen by remember { mutableStateOf(AppScreen.Dashboard) }
    var arabic by remember { mutableStateOf(true) }

    Scaffold(
        bottomBar = {
            NavigationBar {
                AppScreen.entries.forEach { item ->
                    NavigationBarItem(
                        selected = screen == item,
                        onClick = { screen = item },
                        label = { Text(if (arabic) item.titleAr else item.titleEn) },
                        icon = {}
                    )
                }
            }
        }
    ) { padding ->
        when (screen) {
            AppScreen.Dashboard -> DashboardScreen(Modifier.padding(padding), arabic)
            AppScreen.Projects -> ProjectsScreen(Modifier.padding(padding), repository, arabic)
            AppScreen.Targets -> TargetsScreen(Modifier.padding(padding), repository, arabic)
            AppScreen.Assistant -> AssistantScreen(Modifier.padding(padding), arabic)
            AppScreen.Reports -> ReportsScreen(Modifier.padding(padding), arabic)
            AppScreen.Settings -> SettingsScreen(
                modifier = Modifier.padding(padding),
                arabic = arabic,
                onLanguageToggle = { arabic = !arabic }
            )
        }
    }
}
