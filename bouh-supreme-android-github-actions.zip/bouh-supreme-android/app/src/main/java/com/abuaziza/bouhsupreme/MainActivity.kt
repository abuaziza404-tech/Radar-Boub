package com.abuaziza.bouhsupreme

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.abuaziza.bouhsupreme.ui.BouhSupremeApp
import com.abuaziza.bouhsupreme.ui.theme.BouhTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val repo = (application as BouhApp).repository
        setContent {
            BouhTheme {
                BouhSupremeApp(repo)
            }
        }
    }
}
