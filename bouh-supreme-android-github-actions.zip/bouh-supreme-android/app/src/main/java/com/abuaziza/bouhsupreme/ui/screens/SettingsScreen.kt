package com.abuaziza.bouhsupreme.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun SettingsScreen(
    modifier: Modifier = Modifier,
    arabic: Boolean,
    onLanguageToggle: () -> Unit
) {
    Column(modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(if (arabic) "الإعدادات" else "Settings", style = MaterialTheme.typography.headlineSmall)
        Button(onClick = onLanguageToggle) {
            Text(if (arabic) "Switch to English" else "التبديل إلى العربية")
        }
        Text(if (arabic) "إرسال البيانات الحساسة إلى AI API: مغلق افتراضياً" else "Send sensitive data to AI API: off by default")
    }
}
