package com.abuaziza.bouhsupreme.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.abuaziza.bouhsupreme.data.BouhRepository
import com.abuaziza.bouhsupreme.domain.TargetEvidence
import kotlinx.coroutines.launch

@Composable
fun TargetsScreen(modifier: Modifier = Modifier, repository: BouhRepository, arabic: Boolean) {
    val scope = rememberCoroutineScope()
    val targets by repository.observeTargets().collectAsState(initial = emptyList())
    var name by remember { mutableStateOf("") }
    var lastDecision by remember { mutableStateOf("") }

    Column(modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(if (arabic) "سجل الأهداف" else "Target Register", style = MaterialTheme.typography.headlineSmall)
        OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = { Text(if (arabic) "اسم الهدف" else "Target name") }
        )
        Button(onClick = {
            scope.launch {
                val project = repository.createProject("Default Field Project")
                val target = repository.createTarget(project.id, name)
                val result = repository.classifyAndSave(
                    target.id,
                    TargetEvidence(hasStructure = true, hasPattern = true, isVisualOnly = true)
                )
                lastDecision = result.decisionClass.label() + ": " + result.reasonSummary
                name = ""
            }
        }) {
            Text(if (arabic) "إنشاء هدف تجريبي بصري" else "Create Visual Test Target")
        }
        if (lastDecision.isNotBlank()) {
            AssistChip(onClick = {}, label = { Text(lastDecision) })
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(targets) { target ->
                Card {
                    Column(Modifier.padding(12.dp)) {
                        Text(target.name, style = MaterialTheme.typography.titleMedium)
                        Text("Decision: ${target.decisionClass}")
                        Text("Confidentiality: ${target.confidentialityLevel}")
                    }
                }
            }
        }
    }
}
