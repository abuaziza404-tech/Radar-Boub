package com.abuaziza.bouhsupreme.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun DashboardScreen(modifier: Modifier = Modifier, arabic: Boolean) {
    Column(modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(
            text = if (arabic) "بوح التضاريس | منظومة أبوعزيزة" else "BOUH SUPREME | AbuAziza Gold Terrain System",
            style = MaterialTheme.typography.headlineSmall
        )
        Text(if (arabic) "القانون الحاكم:" else "Supreme law:")
        AssistChip(onClick = {}, label = { Text("Structure → Pattern → Alteration → Confirmation → Decision") })
        Text(
            if (arabic)
                "MVP يعمل محلياً، يحفظ المشاريع والأهداف والأدلة، ويمنع قرارات Target-B دون دليل كامل."
            else
                "Offline-first MVP with projects, targets, evidence ledger, and guarded Target-B decisions."
        )
    }
}
