package com.abuaziza.bouhsupreme.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ProjectDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(project: ProjectEntity)

    @Query("SELECT * FROM projects ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<ProjectEntity>>

    @Query("SELECT * FROM projects WHERE id = :id LIMIT 1")
    suspend fun findById(id: String): ProjectEntity?
}

@Dao
interface TargetDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(target: TargetEntity)

    @Query("SELECT * FROM targets WHERE projectId = :projectId ORDER BY updatedAt DESC")
    fun observeByProject(projectId: String): Flow<List<TargetEntity>>

    @Query("SELECT * FROM targets ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<TargetEntity>>
}

@Dao
interface EvidenceDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(evidence: EvidenceEntity)

    @Query("SELECT * FROM evidences WHERE targetId = :targetId ORDER BY createdAt DESC")
    suspend fun listByTarget(targetId: String): List<EvidenceEntity>
}

@Dao
interface DecisionDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(decision: DecisionEntity)

    @Query("SELECT * FROM decisions WHERE targetId = :targetId ORDER BY createdAt DESC LIMIT 1")
    suspend fun latestForTarget(targetId: String): DecisionEntity?
}

@Dao
interface ImportedFileDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(file: ImportedFileEntity)
}

@Dao
interface FieldAnalogDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(analog: FieldAnalogEntity)

    @Query("SELECT * FROM field_analogs ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<FieldAnalogEntity>>
}

@Dao
interface GlobalMemoryDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(rule: GlobalMemoryRuleEntity)

    @Query("SELECT * FROM global_memory_rules ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<GlobalMemoryRuleEntity>>
}

@Dao
interface PromptTemplateDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(prompt: PromptTemplateEntity)

    @Query("SELECT * FROM prompt_templates WHERE name = :name AND language = :language LIMIT 1")
    suspend fun find(name: String, language: String): PromptTemplateEntity?
}
