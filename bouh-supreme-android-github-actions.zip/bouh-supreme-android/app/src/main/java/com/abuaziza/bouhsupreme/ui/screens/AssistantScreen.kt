package com.abuaziza.bouhsupreme.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.abuaziza.bouhsupreme.ai.AiGuardrailFilter
import com.abuaziza.bouhsupreme.domain.BouhKillMatrixEngine
import com.abuaziza.bouhsupreme.domain.TargetEvidence

@Composable
fun AssistantScreen(modifier: Modifier = Modifier, arabic: Boolean) {
    var answer by remember { mutableStateOf("") }
    val engine = remember { BouhKillMatrixEngine() }
    val guard = remember { AiGuardrailFilter() }

    Column(modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(if (arabic) "مساعد بوح" else "BOUH Assistant", style = MaterialTheme.typography.headlineSmall)
        Text("Structure → Pattern → Alteration → Confirmation → Decision")
        Button(onClick = {
            val decision = engine.classify(TargetEvidence(hasStructure = true, hasPattern = true, isFeOxOnly = true))
            answer = """
                1. نوع الدليل: [تحليل بصري غير حسابي] FeOx-only
                2. الحكم النهائي: ${decision.decisionClass.label()}
                3. السبب: ${decision.reasonSummary}
                4. الخطوة التالية: ${decision.fieldRecommendation}
            """.trimIndent()
        }) { Text(if (arabic) "اختبار FeOx فقط" else "Test FeOx-only") }

        Button(onClick = {
            val filtered = guard.filter("Target-B وذهب مؤكد", localDecisionClass = "HOLD", presentationMode = false)
            answer = filtered.safeText
        }) { Text(if (arabic) "اختبار حارس AI" else "Test AI Guardrail") }

        if (answer.isNotBlank()) {
            Card { Text(answer, Modifier.padding(12.dp)) }
        }
    }
}
