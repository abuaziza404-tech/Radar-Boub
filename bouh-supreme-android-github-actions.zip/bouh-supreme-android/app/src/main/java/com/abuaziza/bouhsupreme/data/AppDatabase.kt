package com.abuaziza.bouhsupreme.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        ProjectEntity::class,
        ImportedFileEntity::class,
        TargetEntity::class,
        EvidenceEntity::class,
        DecisionEntity::class,
        FieldAnalogEntity::class,
        LearningEventEntity::class,
        KnowledgeChunkEntity::class,
        GlobalMemoryRuleEntity::class,
        PromptTemplateEntity::class
    ],
    version = 1,
    exportSchema = true
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun projectDao(): ProjectDao
    abstract fun targetDao(): TargetDao
    abstract fun evidenceDao(): EvidenceDao
    abstract fun decisionDao(): DecisionDao
    abstract fun importedFileDao(): ImportedFileDao
    abstract fun fieldAnalogDao(): FieldAnalogDao
    abstract fun globalMemoryDao(): GlobalMemoryDao
    abstract fun promptTemplateDao(): PromptTemplateDao

    companion object {
        fun create(context: Context): AppDatabase =
            Room.databaseBuilder(context, AppDatabase::class.java, "bouh_supreme.db")
                .fallbackToDestructiveMigration()
                .build()
    }
}
