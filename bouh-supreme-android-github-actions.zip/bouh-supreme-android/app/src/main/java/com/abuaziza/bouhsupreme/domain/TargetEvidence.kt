package com.abuaziza.bouhsupreme.domain

data class TargetEvidence(
    val hasStructure: Boolean = false,
    val hasPattern: Boolean = false,
    val hasPossibleAlteration: Boolean = false,
    val hasConfirmedAlteration: Boolean = false,
    val hasConfirmation: Boolean = false,
    val noiseControlled: Boolean = false,
    val isVisualOnly: Boolean = false,
    val isFeOxOnly: Boolean = false,
    val magneticGroundRisk: Double? = null,
    val quartzQiHigh: Boolean = false
)

data class DecisionResult(
    val decisionClass: DecisionClass,
    val reasonSummary: String,
    val missingEvidence: String,
    val fieldRecommendation: String,
    val gpzStrategy: String? = null
)
