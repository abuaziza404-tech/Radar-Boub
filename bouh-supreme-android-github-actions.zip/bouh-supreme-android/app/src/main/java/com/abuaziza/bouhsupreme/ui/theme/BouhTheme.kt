package com.abuaziza.bouhsupreme.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable

@Composable
fun BouhTheme(content: @Composable () -> Unit) {
    MaterialTheme(content = content)
}
