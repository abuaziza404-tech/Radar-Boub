package com.abuaziza.bouhsupreme.ai

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody

data class AiSettings(
    val baseUrl: String,
    val apiKey: String,
    val modelName: String,
    val sendSensitiveData: Boolean = false
)

data class AiRequestContext(
    val mode: String,
    val language: String,
    val targetSummary: String,
    val evidenceSummary: String,
    val allowedTasks: List<String>,
    val forbiddenTasks: List<String>,
    val sensitivityPolicy: String = "do_not_send_precise_coordinates"
)

class AiGateway(
    private val client: OkHttpClient = OkHttpClient()
) {
    fun buildSafePayload(ctx: AiRequestContext): String {
        return """
        {
          "mode": "${ctx.mode}",
          "language": "${ctx.language}",
          "target_summary": ${jsonString(ctx.targetSummary)},
          "evidence_summary": ${jsonString(ctx.evidenceSummary)},
          "allowed_tasks": ${ctx.allowedTasks.joinToString(prefix = "[", postfix = "]") { jsonString(it) }},
          "forbidden_tasks": ${ctx.forbiddenTasks.joinToString(prefix = "[", postfix = "]") { jsonString(it) }},
          "sensitivity_policy": "${ctx.sensitivityPolicy}"
        }
        """.trimIndent()
    }

    fun makeRequest(settings: AiSettings, payload: String): Request {
        val body = payload.toRequestBody("application/json; charset=utf-8".toMediaType())
        return Request.Builder()
            .url(settings.baseUrl)
            .addHeader("Authorization", "Bearer ${settings.apiKey}")
            .addHeader("Content-Type", "application/json")
            .post(body)
            .build()
    }

    private fun jsonString(value: String): String {
        return "\"" + value
            .replace("\\", "\\\\")
            .replace("\"", "\\\"")
            .replace("\n", "\\n") + "\""
    }
}
