package com.abuaziza.bouhsupreme.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun ReportsScreen(modifier: Modifier = Modifier, arabic: Boolean) {
    Column(modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(if (arabic) "التقارير" else "Reports", style = MaterialTheme.typography.headlineSmall)
        Text(if (arabic) "سيتم دعم Operational Report و Presentation Report مع إخفاء الإحداثيات الحساسة." else "Operational and Presentation reports with sensitive coordinate masking.")
    }
}
