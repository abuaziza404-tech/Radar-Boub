package com.abuaziza.bouhsupreme.domain

data class FileAuthority(
    val fileType: String,
    val authorityClass: SourceType,
    val processingStatus: String,
    val reason: String
)

object FileAuthorityClassifier {
    fun classify(filename: String, sizeBytes: Long = 0L): FileAuthority {
        val ext = filename.substringAfterLast('.', "").lowercase()
        if (sizeBytes > 250L * 1024L * 1024L) {
            return FileAuthority(ext, SourceType.Raw, "needs_preprocessing", "File is too large for mobile MVP processing.")
        }

        return when (ext) {
            "tif", "tiff", "geotiff", "jp2", "hdf", "mtl", "qa", "scl", "dem", "srtm" ->
                FileAuthority(ext, SourceType.Raw, "pending", "Accepted as raw/computational candidate after CRS/QA checks.")
            "csv" ->
                FileAuthority(ext, SourceType.Field, "pending", "CSV accepted as field/tabular data depending on content.")
            "kml", "kmz" ->
                FileAuthority(ext, SourceType.VisualSpatial, "pending", "KML/KMZ is visual/spatial support only.")
            "jpg", "jpeg", "png" ->
                FileAuthority(ext, SourceType.Visual, "pending", "Image is visual-only; no spectral computation.")
            "pdf", "docx" ->
                FileAuthority(ext, SourceType.External, "pending", "Reference document; not raw spectral evidence.")
            else ->
                FileAuthority(ext.ifBlank { "unknown" }, SourceType.Example, "rejected", "Unsupported file type in MVP.")
        }
    }
}
