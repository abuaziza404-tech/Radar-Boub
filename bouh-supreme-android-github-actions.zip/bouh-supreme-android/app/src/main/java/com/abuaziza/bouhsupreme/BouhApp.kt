package com.abuaziza.bouhsupreme

import android.app.Application
import com.abuaziza.bouhsupreme.data.AppDatabase
import com.abuaziza.bouhsupreme.data.BouhRepository

class BouhApp : Application() {
    lateinit var repository: BouhRepository
        private set

    override fun onCreate() {
        super.onCreate()
        val db = AppDatabase.create(this)
        repository = BouhRepository(db)
    }
}
