package com.abuaziza.bouhsupreme.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.abuaziza.bouhsupreme.data.BouhRepository
import kotlinx.coroutines.launch

@Composable
fun ProjectsScreen(modifier: Modifier = Modifier, repository: BouhRepository, arabic: Boolean) {
    val scope = rememberCoroutineScope()
    val projects by repository.observeProjects().collectAsState(initial = emptyList())
    var name by remember { mutableStateOf("") }

    Column(modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(if (arabic) "المشاريع" else "Projects", style = MaterialTheme.typography.headlineSmall)
        OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = { Text(if (arabic) "اسم المشروع" else "Project name") }
        )
        Button(onClick = { scope.launch { repository.createProject(name); name = "" } }) {
            Text(if (arabic) "إنشاء مشروع" else "Create Project")
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(projects) { project ->
                Card {
                    Column(Modifier.padding(12.dp)) {
                        Text(project.name, style = MaterialTheme.typography.titleMedium)
                        Text("${project.regionName} · ${project.confidentialityMode}")
                    }
                }
            }
        }
    }
}
