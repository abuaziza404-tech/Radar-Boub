package com.abuaziza.bouhsupreme.domain

data class EvidenceInput(
    val evidenceType: EvidenceType,
    val sourceType: SourceType,
    val tag: EvidenceTag,
    val description: String,
    val numericValue: Double? = null,
    val claimsSpectralComputation: Boolean = false,
    val isConfirmation: Boolean = false
)

data class ValidationResult(
    val valid: Boolean,
    val message: String
)

class EvidenceValidator {
    fun validate(input: EvidenceInput): ValidationResult {
        if (input.numericValue != null && input.sourceType !in setOf(SourceType.Raw, SourceType.Field, SourceType.External, SourceType.Example)) {
            return ValidationResult(false, "Numeric values require raw, field, external, or example source.")
        }

        if (input.sourceType in setOf(SourceType.Visual, SourceType.VisualSpatial) && input.claimsSpectralComputation) {
            return ValidationResult(false, "Visual-only sources cannot prove Clay/SWIR/Silica/reflectance.")
        }

        if (input.isConfirmation && input.sourceType in setOf(SourceType.Visual, SourceType.VisualSpatial)) {
            return ValidationResult(false, "Visual-only evidence cannot be Confirmation.")
        }

        if (input.description.isBlank()) {
            return ValidationResult(false, "Evidence description is required.")
        }

        return ValidationResult(true, "Accepted with tag ${input.tag.label}.")
    }
}
