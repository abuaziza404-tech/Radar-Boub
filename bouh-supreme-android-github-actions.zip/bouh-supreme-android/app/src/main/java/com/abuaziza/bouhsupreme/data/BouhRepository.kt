package com.abuaziza.bouhsupreme.data

import com.abuaziza.bouhsupreme.domain.BouhKillMatrixEngine
import com.abuaziza.bouhsupreme.domain.DecisionResult
import com.abuaziza.bouhsupreme.domain.TargetEvidence
import kotlinx.coroutines.flow.Flow
import java.util.UUID

class BouhRepository(private val db: AppDatabase) {
    private val engine = BouhKillMatrixEngine()

    fun observeProjects(): Flow<List<ProjectEntity>> = db.projectDao().observeAll()
    fun observeTargets(): Flow<List<TargetEntity>> = db.targetDao().observeAll()

    suspend fun createProject(name: String, region: String = "شرق السودان"): ProjectEntity {
        val now = System.currentTimeMillis()
        val project = ProjectEntity(
            id = UUID.randomUUID().toString(),
            name = name.ifBlank { "BOUH Field Project" },
            regionName = region,
            aoiDescription = "",
            confidentialityMode = "operational",
            shareWithGlobalMemory = true,
            notes = "",
            createdAt = now
        )
        db.projectDao().upsert(project)
        return project
    }

    suspend fun createTarget(projectId: String, name: String): TargetEntity {
        val now = System.currentTimeMillis()
        val target = TargetEntity(
            id = "T-" + UUID.randomUUID().toString().take(8).uppercase(),
            projectId = projectId,
            name = name.ifBlank { "New Target" },
            latitude = null,
            longitude = null,
            geometryJson = null,
            analogClass = null,
            decisionClass = "HOLD",
            confidentialityLevel = "secret",
            notes = "",
            createdAt = now,
            updatedAt = now
        )
        db.targetDao().upsert(target)
        return target
    }

    suspend fun classifyAndSave(targetId: String, evidence: TargetEvidence): DecisionResult {
        val result = engine.classify(evidence)
        db.decisionDao().upsert(
            DecisionEntity(
                id = UUID.randomUUID().toString(),
                targetId = targetId,
                decisionClass = result.decisionClass.label(),
                reasonSummary = result.reasonSummary,
                missingEvidence = result.missingEvidence,
                fieldRecommendation = result.fieldRecommendation,
                gpzStrategy = result.gpzStrategy,
                createdAt = System.currentTimeMillis()
            )
        )
        return result
    }
}
