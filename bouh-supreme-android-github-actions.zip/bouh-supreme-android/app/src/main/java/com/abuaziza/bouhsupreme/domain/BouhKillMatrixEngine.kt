package com.abuaziza.bouhsupreme.domain

class BouhKillMatrixEngine {
    fun classify(e: TargetEvidence): DecisionResult {
        if (!e.hasStructure) {
            return DecisionResult(
                decisionClass = DecisionClass.Reject,
                reasonSummary = "No Structure evidence. Reject-first logic applied.",
                missingEvidence = "Structure: lineament, shear, fault intersection, contact, jog, or structural corridor.",
                fieldRecommendation = "Add structural evidence before any targeting decision.",
                gpzStrategy = gpzStrategy(e)
            )
        }

        if (!e.hasPattern) {
            return DecisionResult(
                decisionClass = DecisionClass.Reject,
                reasonSummary = "Structure exists, but Pattern is missing.",
                missingEvidence = "Pattern: hill-foot, feeder gully, wadi edge, pediment, dark regolith strip, or cluster.",
                fieldRecommendation = "Map geomorphology and pattern context.",
                gpzStrategy = gpzStrategy(e)
            )
        }

        if (e.isFeOxOnly) {
            return DecisionResult(
                decisionClass = DecisionClass.LowHOLD,
                reasonSummary = "FeOx-only is insufficient and may be ordinary oxidation or color noise.",
                missingEvidence = "Alteration confirmation, raw bands, GPZ, sample, assay, or field note.",
                fieldRecommendation = "Do not promote. Collect raw/field confirmation.",
                gpzStrategy = gpzStrategy(e)
            )
        }

        if (e.isVisualOnly) {
            return DecisionResult(
                decisionClass = DecisionClass.VisualCandidate,
                reasonSummary = "Visual-only evidence cannot prove Clay, SWIR, Silica, reflectance, or gold.",
                missingEvidence = "Raw bands, DEM, GPZ hit, sample, assay, or documented field confirmation.",
                fieldRecommendation = "Keep as HOLD/Visual Candidate and collect confirming evidence.",
                gpzStrategy = gpzStrategy(e)
            )
        }

        if (e.hasStructure && e.hasPattern && e.hasPossibleAlteration && !e.hasConfirmation) {
            return DecisionResult(
                decisionClass = DecisionClass.Candidate,
                reasonSummary = "Structure + Pattern + possible Alteration exist, but Confirmation is missing.",
                missingEvidence = "Confirmation: GPZ recovered gold, assay, sample, geochem, or explicit field evidence.",
                fieldRecommendation = "Run controlled GPZ lines or collect surface samples.",
                gpzStrategy = gpzStrategy(e)
            )
        }

        if (e.hasStructure && e.hasPattern && e.hasConfirmedAlteration && e.hasConfirmation && e.noiseControlled) {
            return DecisionResult(
                decisionClass = DecisionClass.TargetB,
                reasonSummary = "Structure + Pattern + Alteration + Confirmation + Noise control satisfied.",
                missingEvidence = "None for Target-B gate. Continue controlled verification.",
                fieldRecommendation = "Proceed to operational field verification with documented controls.",
                gpzStrategy = gpzStrategy(e)
            )
        }

        return DecisionResult(
            decisionClass = DecisionClass.HOLD,
            reasonSummary = "Evidence is incomplete. Maximum safe operational decision is HOLD.",
            missingEvidence = "Complete Alteration, Confirmation, and Noise control gates.",
            fieldRecommendation = "Add raw data or field confirmation before escalation.",
            gpzStrategy = gpzStrategy(e)
        )
    }

    fun gpzStrategy(e: TargetEvidence): String {
        val risk = e.magneticGroundRisk
        return when {
            risk != null && risk > 0.75 -> "GPZ 7000: Severe/Difficult, High Yield, Sensitivity 8–11, Audio Smoothing Low/On, slow controlled lines + cross-check."
            risk != null && risk < 0.45 && e.quartzQiHigh -> "GPZ 7000: Normal, General/Deep, Sensitivity 12–16, Audio Smoothing Off, slow depth-focused scanning."
            else -> "GPZ 7000: Start conservative, verify from two directions, isolate hot rocks, and document signal behavior."
        }
    }
}
