package com.abuaziza.bouhsupreme.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey val id: String,
    val name: String,
    val regionName: String,
    val aoiDescription: String,
    val confidentialityMode: String,
    val shareWithGlobalMemory: Boolean,
    val notes: String,
    val createdAt: Long
)

@Entity(tableName = "imported_files")
data class ImportedFileEntity(
    @PrimaryKey val id: String,
    val projectId: String,
    val filename: String,
    val fileType: String,
    val localUri: String,
    val authorityClass: String,
    val processingStatus: String,
    val checksum: String,
    val importedAt: Long
)

@Entity(tableName = "targets")
data class TargetEntity(
    @PrimaryKey val id: String,
    val projectId: String,
    val name: String,
    val latitude: Double?,
    val longitude: Double?,
    val geometryJson: String?,
    val analogClass: String?,
    val decisionClass: String,
    val confidentialityLevel: String,
    val notes: String,
    val createdAt: Long,
    val updatedAt: Long
)

@Entity(tableName = "evidences")
data class EvidenceEntity(
    @PrimaryKey val id: String,
    val targetId: String,
    val evidenceType: String,
    val sourceType: String,
    val sourceFileId: String?,
    val mandatoryTag: String,
    val description: String,
    val numericValue: Double?,
    val unit: String?,
    val isConfirmed: Boolean,
    val createdAt: Long
)

@Entity(tableName = "decisions")
data class DecisionEntity(
    @PrimaryKey val id: String,
    val targetId: String,
    val decisionClass: String,
    val reasonSummary: String,
    val missingEvidence: String,
    val fieldRecommendation: String,
    val gpzStrategy: String?,
    val createdAt: Long
)

@Entity(tableName = "field_analogs")
data class FieldAnalogEntity(
    @PrimaryKey val id: String,
    val projectId: String?,
    val sourceTargetId: String?,
    val analogClass: String,
    val confirmationType: String?,
    val confirmationStrength: String?,
    val terrainSignature: String,
    val structureSignature: String,
    val alterationSignature: String,
    val notes: String,
    val createdAt: Long
)

@Entity(tableName = "learning_events")
data class LearningEventEntity(
    @PrimaryKey val id: String,
    val projectId: String,
    val targetId: String?,
    val eventType: String,
    val beforeState: String?,
    val afterState: String?,
    val reason: String,
    val approvedByUser: Boolean,
    val createdAt: Long
)

@Entity(tableName = "knowledge_chunks")
data class KnowledgeChunkEntity(
    @PrimaryKey val id: String,
    val projectId: String,
    val sourceFileId: String?,
    val chunkText: String,
    val chunkType: String,
    val sensitivityLevel: String,
    val createdAt: Long
)

@Entity(tableName = "global_memory_rules")
data class GlobalMemoryRuleEntity(
    @PrimaryKey val id: String,
    val ruleType: String,
    val sourceProjectCount: Int,
    val confidenceLevel: String,
    val descriptionAr: String,
    val descriptionEn: String,
    val sensitiveOrigin: Boolean,
    val requiresUserApproval: Boolean,
    val createdAt: Long,
    val updatedAt: Long
)

@Entity(tableName = "prompt_templates")
data class PromptTemplateEntity(
    @PrimaryKey val id: String,
    val name: String,
    val language: String,
    val content: String,
    val createdAt: Long
)
