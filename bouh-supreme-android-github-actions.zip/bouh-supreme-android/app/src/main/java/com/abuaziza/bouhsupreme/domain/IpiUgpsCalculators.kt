package com.abuaziza.bouhsupreme.domain

object IpiCalculator {
    fun calculate(s: Double?, a: Double?, p: Double?, f: Double?): String {
        if (s == null || a == null || p == null || f == null) {
            return "لا أملك بيانات كافية لحساب IPI رقمياً."
        }
        val ipi = 100.0 * ((0.35 * s) + (0.30 * a) + (0.20 * p) + (0.15 * f))
        val decision = when {
            ipi >= 85 -> "Target-B"
            ipi >= 70 -> "Target-B Candidate / Zoom"
            ipi >= 55 -> "HOLD"
            ipi >= 35 -> "Low HOLD"
            else -> "Reject"
        }
        return "[بيانات حقيقية] IPI=${"%.1f".format(ipi)} → $decision"
    }
}

object UgpsCalculator {
    fun calculate(
        spectral: Double?,
        structural: Double?,
        geomorphology: Double?,
        multiProject: Double?,
        fieldValidation: Double?,
        noise: Double?
    ): String {
        if (spectral == null || structural == null || geomorphology == null || multiProject == null || fieldValidation == null || noise == null) {
            return "لا أملك بيانات كافية لحساب UGPS رقمياً."
        }
        val score = (0.30 * spectral) + (0.25 * structural) + (0.20 * geomorphology) +
            (0.15 * multiProject) + (0.10 * fieldValidation) - (0.10 * noise)
        return "[بيانات حقيقية] UGPS=${"%.2f".format(score)}. UGPS ترجيح داعم وليس إثبات ذهب."
    }
}
