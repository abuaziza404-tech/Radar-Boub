package com.abuaziza.bouhsupreme.ai

data class GuardrailResult(
    val allowed: Boolean,
    val safeText: String,
    val reason: String? = null
)

class AiGuardrailFilter {
    private val forbiddenGoldClaims = listOf("ذهب مؤكد", "confirmed gold", "gold is confirmed")
    private val unsupportedSpectralClaims = listOf("SWIR عالي", "Clay مؤكد", "Silica محسوبة", "reflectance")

    fun filter(response: String, localDecisionClass: String, presentationMode: Boolean): GuardrailResult {
        val lower = response.lowercase()

        if (forbiddenGoldClaims.any { lower.contains(it.lowercase()) }) {
            return GuardrailResult(
                allowed = false,
                safeText = "تم حجب رد AI لأنه حاول تأكيد الذهب دون دليل ميداني/مختبري.",
                reason = "Gold confirmation without allowed proof."
            )
        }

        if (unsupportedSpectralClaims.any { response.contains(it, ignoreCase = true) }) {
            return GuardrailResult(
                allowed = false,
                safeText = "تم حجب رد AI لأنه استخدم ادعاء طيفي غير مدعوم.",
                reason = "Unsupported spectral claim."
            )
        }

        if (response.contains("Target-B", ignoreCase = true) && localDecisionClass != "Target-B") {
            return GuardrailResult(
                allowed = false,
                safeText = "تم حجب ترقية AI إلى Target-B لأن محرك القرار المحلي لم يوافق.",
                reason = "AI attempted decision override."
            )
        }

        val masked = if (presentationMode) maskCoordinates(response) else response
        return GuardrailResult(true, masked)
    }

    private fun maskCoordinates(text: String): String {
        val coordPattern = Regex("""[-+]?\d{1,2}\.\d{4,}\s*,\s*[-+]?\d{1,3}\.\d{4,}""")
        return coordPattern.replace(text, "[masked coordinates]")
    }
}
