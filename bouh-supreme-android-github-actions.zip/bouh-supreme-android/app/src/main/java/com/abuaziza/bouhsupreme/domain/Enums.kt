package com.abuaziza.bouhsupreme.domain

enum class DecisionClass {
    Reject,
    LowHOLD,
    HOLD,
    VisualCandidate,
    Candidate,
    TargetB;

    fun label(): String = when (this) {
        Reject -> "Reject"
        LowHOLD -> "Low HOLD"
        HOLD -> "HOLD"
        VisualCandidate -> "Visual Candidate"
        Candidate -> "Candidate"
        TargetB -> "Target-B"
    }
}

enum class EvidenceType {
    Structure,
    Pattern,
    Alteration,
    Confirmation,
    Noise,
    FieldNote,
    Reference
}

enum class SourceType {
    Raw,
    Visual,
    VisualSpatial,
    Field,
    External,
    Example
}

enum class EvidenceTag(val label: String) {
    RealData("[بيانات حقيقية]"),
    ExternalSource("[مصدر خارجي]"),
    UserMessageData("[بيانات من رسالة المستخدم]"),
    VisualNonComputational("[تحليل بصري غير حسابي]"),
    Example("[مثال توضيحي]")
}
