# BOUH SUPREME Governance Core

## Supreme Law

```text
Structure → Pattern → Alteration → Confirmation → Decision
```

## Mandatory Tags

- [بيانات حقيقية]
- [مصدر خارجي]
- [بيانات من رسالة المستخدم]
- [تحليل بصري غير حسابي]
- [مثال توضيحي]

## Raw Bands Only

Sentinel / Landsat / ASTER are not computational evidence unless raw bands or computational files exist:

- GeoTIFF / TIFF
- HDF / JP2
- MTL
- QA / SCL
- CSV
- DEM / SRTM
- raw raster bands

## Visual-only maximum

Google Earth / PNG / JPG / KML / KMZ maximum decision:

- HOLD
- Visual Candidate

## Target-B Guard

Target-B requires:

- Structure
- Pattern
- Alteration
- Confirmation
- Noise control
