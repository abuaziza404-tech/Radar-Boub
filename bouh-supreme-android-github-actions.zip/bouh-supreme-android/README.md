# BOUH SUPREME | AbuAziza Gold Terrain System

Android APK MVP scaffold for **بوح التضاريس | منظومة أبوعزيزة**.

This repository is ready to upload to GitHub and build with GitHub Actions.

## What is included

- Kotlin Android app.
- Jetpack Compose bilingual UI: Arabic / English.
- Room / SQLite local database.
- Offline-first project and target register.
- Evidence Ledger with mandatory source tags.
- BOUH Kill Matrix local rule engine.
- IPI / UGPS guarded calculators.
- Global Memory scaffolding.
- AI API Gateway scaffolding with local guardrails.
- GitHub Actions workflow to run unit tests and build a debug APK.

## Core rule

```text
Structure → Pattern → Alteration → Confirmation → Decision
```

The AI API is not allowed to confirm gold, invent coordinates, invent spectral values, or upgrade a target to Target-B without the local Kill Matrix.

## Build locally

```bash
gradle testDebugUnitTest
gradle assembleDebug
```

Or upload to GitHub and run **Android CI**.

## MVP limitations

- Heavy GeoTIFF/Sentinel/Landsat/ASTER processing is scaffolded but not implemented in this first code package.
- The app classifies files and evidence authority locally.
- Raw raster analytics should be added later through GDAL/raster preprocessing or a controlled backend.
- Maps are represented as a placeholder screen in this package to keep the initial APK build stable.

## Security defaults

- Precise coordinates are operational-only.
- Presentation mode masks sensitive location data.
- AI API sending of sensitive data is off by default.
