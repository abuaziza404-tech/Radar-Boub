#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
test -f "$ROOT_DIR/apps/web/capacitor.config.ts"
grep -q 'com.bawh.terrain' "$ROOT_DIR/apps/web/capacitor.config.ts"
test -f "$ROOT_DIR/ANDROID_BUILD_GUIDE.md"
test -f "$ROOT_DIR/scripts/build_android_debug.sh"
test -f "$ROOT_DIR/scripts/build_android_release.sh"
echo "Android release scaffolding checks passed."
