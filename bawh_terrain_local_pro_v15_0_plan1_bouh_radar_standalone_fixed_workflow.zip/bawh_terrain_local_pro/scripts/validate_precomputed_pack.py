from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PRE = ROOT / "data" / "precomputed"

REQUIRED = [
    "truth_policy.json",
    "evidence_registry.json",
    "regional_zones.json",
    "official_targets_and_screening_points.json",
    "universal_summary_compact.json",
    "drive_import_manifest.json",
    "data_definitions.json",
    "radar_bootstrap.json",
]

def main() -> None:
    missing = [name for name in REQUIRED if not (PRE / name).exists()]
    if missing:
        raise SystemExit(f"Missing precomputed files: {missing}")

    for name in REQUIRED:
        json.loads((PRE / name).read_text(encoding="utf-8"))

    targets = json.loads((PRE / "official_targets_and_screening_points.json").read_text(encoding="utf-8"))
    assert targets["truth_policy"].lower().find("not gold proof") >= 0
    assert len(targets["targets"]) >= 5

    evidence = json.loads((PRE / "evidence_registry.json").read_text(encoding="utf-8"))
    visual = [c for c in evidence["evidence_classes"] if c["class_id"] == "visual_context_only"][0]
    assert "spectral_indices" in visual["blocked_uses"]

    print("BOUH lightweight pack validation OK")

if __name__ == "__main__":
    main()
