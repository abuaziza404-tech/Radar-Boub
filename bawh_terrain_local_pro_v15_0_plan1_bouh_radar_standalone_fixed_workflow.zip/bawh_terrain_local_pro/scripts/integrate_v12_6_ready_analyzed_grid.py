#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import shutil
import sqlite3
import zipfile
from pathlib import Path

EXPECTED_SHA256 = "c89cedffb3916878f4fee9a22868300af43fc85874d9d79ef69ee657816c949d"
EXPECTED_COUNT = 4303

def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("zip_path", help="BOUH_v12_6_READY_ANALYZED_GROUND_GRID_DATA.zip")
    parser.add_argument("--project-root", default=".", help="Project root")
    args = parser.parse_args()

    zip_path = Path(args.zip_path).resolve()
    project_root = Path(args.project_root).resolve()

    if not zip_path.exists():
        raise SystemExit(f"Missing ZIP: {zip_path}")

    actual = sha256(zip_path)
    if actual != EXPECTED_SHA256:
        raise SystemExit(f"SHA256 mismatch: {actual} != {EXPECTED_SHA256}")

    with zipfile.ZipFile(zip_path, "r") as archive:
        candidates = [name for name in archive.namelist() if name.endswith("data/precomputed/bouh_ground_grid.sqlite")]
        if not candidates:
            raise SystemExit("data/precomputed/bouh_ground_grid.sqlite not found inside ZIP")
        extracted = project_root / "data/precomputed/bouh_ground_grid.sqlite"
        extracted.parent.mkdir(parents=True, exist_ok=True)
        with archive.open(candidates[0]) as src, extracted.open("wb") as dst:
            shutil.copyfileobj(src, dst)

    conn = sqlite3.connect(project_root / "data/precomputed/bouh_ground_grid.sqlite")
    try:
        count = conn.execute("select count(*) from ground_cells").fetchone()[0]
    finally:
        conn.close()

    if count != EXPECTED_COUNT:
        raise SystemExit(f"ground_cells mismatch: {count} != {EXPECTED_COUNT}")

    print(f"Integrated v12.6 ready analyzed ground grid: ground_cells={count}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
