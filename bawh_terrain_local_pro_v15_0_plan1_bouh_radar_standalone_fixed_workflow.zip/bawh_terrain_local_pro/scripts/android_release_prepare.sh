#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
WEB_DIR="$ROOT_DIR/apps/web"

cd "$WEB_DIR"

echo "Installing web dependencies..."
npm install

echo "Building web assets..."
npm run build

if [ ! -d "android" ]; then
  echo "Adding Capacitor Android project..."
  npx cap add android
fi

echo "Syncing Capacitor Android..."
npx cap sync android

echo "Applying release signing template..."
mkdir -p android/app
cp "$ROOT_DIR/android-release/app-build.gradle.release.template" "$WEB_DIR/android/app/build.gradle.release.template"

cat > "$WEB_DIR/android/keystore.properties.example" <<'EOF'
storeFile=/absolute/path/bawhterrain-release.keystore
storePassword=CHANGE_ME_STORE_PASSWORD
keyAlias=bawhterrain
keyPassword=CHANGE_ME_KEY_PASSWORD
EOF

echo ""
echo "Next:"
echo "1) Create keystore:"
echo "   keytool -genkeypair -v -keystore bawhterrain-release.keystore -alias bawhterrain -keyalg RSA -keysize 4096 -validity 10000"
echo "2) Copy android/keystore.properties.example to android/keystore.properties"
echo "3) Edit real passwords and keystore path"
echo "4) Open Android Studio or run:"
echo "   cd apps/web/android && ./gradlew bundleRelease"
