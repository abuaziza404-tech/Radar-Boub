# Implementation Notes

## E — لوحة مصادر الأقمار وحالة كل مصدر

موجودة كبنية جاهزة:
- `/radar/library`
- `/radar/regional-corridor`
- `/projects/{id}/layers`
- `/safety/forecast`

## W — أمان وصلاحيات ومفاتيح API مشفرة

تم تجهيز أساس الأمان:
- SECURITY.md
- safe ZIP extraction
- upload validation
- offline cache
- PWA service worker

المرحلة التالية:
- JWT Auth
- RBAC
- encrypted secrets vault
- API key rotation

## D — الاختبارات

موجودة:
- bbox
- spectral indices
- safety risk engine

تشغيل:
```bash
docker compose exec api pytest -q
```

## Z — التصدير

هذا الأرشيف هو نسخة ZIP جاهزة للتشغيل المحلي.
