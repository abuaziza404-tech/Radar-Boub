# Final QA Checklist — بوح التضاريس v10

## API

- [ ] `/health` يعمل.
- [ ] `/app/identity` يعرض اسم المطور.
- [ ] `/system/overview` يعمل.
- [ ] `/sources/status` يعمل.
- [ ] إنشاء مشروع.
- [ ] تشغيل radar scan.
- [ ] رفع ZIP.
- [ ] رفع MBTiles.
- [ ] رفع PMTiles.
- [ ] إنشاء خطة Offline download.
- [ ] إنشاء admin.
- [ ] تسجيل الدخول JWT.
- [ ] اختبار `/auth/me`.

## Web

- [ ] Dashboard.
- [ ] Radar.
- [ ] Esri Satellite.
- [ ] Hybrid.
- [ ] Streets.
- [ ] حفظ المنطقة.
- [ ] Offline Map Manager.
- [ ] GPS الجهاز.
- [ ] Safety page.
- [ ] Sources page.
- [ ] Workflow page.
- [ ] AI Queue.
- [ ] Security Center.
- [ ] PIN lock.
- [ ] Biometrics عند توفرها.

## Android

- [ ] PWA install من Chrome.
- [ ] Debug APK يعمل.
- [ ] Release AAB يبنى.
- [ ] Release APK يبنى.
- [ ] Offline بعد حفظ منطقة.
- [ ] GPS permission.
- [ ] Storage persistence.

## Security

- [ ] `APP_SECRET_KEY` تم تغييره.
- [ ] keystore خارج Git.
- [ ] لا توجد كلمات مرور في المستودع.
- [ ] HTTPS في production.
