# BOUH v12.5 Analytical Authority Ground Grid Pack

## الحكم التحليلي

هذه الحزمة ليست واجهة وليست APK. هذه حزمة عقل التحليل التي تُلزم المطور بمنطق بوح.

## لماذا تم إنشاؤها؟

لأن v12.4 يحتوي:
- MapLibre
- overlays
- cache
- نقاط precomputed

لكنه لا يحتوي:
- Ground Grid حقيقي
- Live score تحت الدبوس
- قراءة بيكسل/خلية
- عداد أرض يتغير مع الحركة

## ما تحتويه

- نموذج أوزان وتحليل: `configs/ground_score_model_v12_5.json`
- خلايا seed موثقة: `data/precomputed/bouh_seed_cells_v12_5.*`
- SQLite seed DB: `data/precomputed/bouh_seed_cells_v12_5.sqlite`
- جرد مصادر Drive: `data/drive_inventory/bouh_drive_raw_inventory_v12_5.json`
- سكربت بناء Ground Grid: `scripts/build_bouh_ground_grid.py`
- API live score: `apps/api/app/bouh_core/live_score_repository.py`
- واجهة meter: `apps/web/src/bouh/BouhLiveGroundScoreMeter.tsx`
- برومبت المطور: `docs/GRIMOIRE_V12_5_GROUND_GRID_PROMPT.md`

## أرقام seed الحالية

- official targets: 5
- universal support: 10
- sentinel support: 10
- total seed cells: 25

## تحذير علمي

seed cells ليست raw pixel result. هي anchors/contexts.
القراءة الأرضية الحقيقية تتطلب تشغيل `build_bouh_ground_grid.py` على الراسترات الخام المستوردة.
