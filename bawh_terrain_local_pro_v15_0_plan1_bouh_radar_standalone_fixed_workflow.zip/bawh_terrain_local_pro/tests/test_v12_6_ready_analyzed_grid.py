from pathlib import Path
import sqlite3
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "apps" / "api"))

from app.bouh_core.live_score_repository import live_score, live_score_status


def test_v12_6_ready_grid_integrated_when_available(monkeypatch):
    monkeypatch.setenv("BOUH_PRECOMPUTED_DIR", str(ROOT / "data" / "precomputed"))
    db = ROOT / "data" / "precomputed" / "bouh_ground_grid.sqlite"
    assert db.exists(), "bouh_ground_grid.sqlite must exist"

    conn = sqlite3.connect(db)
    count = conn.execute("select count(*) from ground_cells").fetchone()[0]
    nearest = conn.execute(
        "select latitude, longitude from ground_cells order by abs(latitude - 19.9732) + abs(longitude - 36.7456) limit 1"
    ).fetchone()
    conn.close()

    assert count == 4303

    status = live_score_status()
    assert status["ground_grid_exists"] is True
    assert status["ground_grid_cell_count"] == 4303

    out = live_score(float(nearest[0]), float(nearest[1]), 300)
    assert out["mode"] == "ground_grid"
    assert out["result"]["final_ground_score"] is not None
    assert out["result"]["truth_status"]
    assert "Gold" not in out.get("limitation_ar", "")
