from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "apps" / "api"))

from app.bouh_core.evidence_policy import classify_file_name, assert_not_visual_for_indices

def test_png_is_visual_only():
    info = classify_file_name("Browser_images (1).png")
    assert info["evidence_class"] == "visual_context_only"
    assert info["can_compute_indices"] is False

def test_geotiff_sentinel_can_compute():
    info = classify_file_name("2026-06-02_Sentinel-2_L2A_B08_Raw.tiff")
    assert info["evidence_class"] == "calculation_grade_sentinel_raw"
    assert info["can_compute_indices"] is True

def test_visual_rejected_for_indices():
    try:
        assert_not_visual_for_indices("target.kmz")
        assert False
    except ValueError:
        assert True
