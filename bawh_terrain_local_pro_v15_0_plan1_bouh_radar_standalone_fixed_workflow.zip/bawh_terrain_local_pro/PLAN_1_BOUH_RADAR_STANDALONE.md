# PLAN 1 — BOUH Radar Standalone

## الهدف

فصل الرادار في تطبيق مستقل سريع وميداني:

```text
خريطة → مركز الشاشة → بحث محلي في 4303 خلية → Ground Score → تقرير نقطة
```

## نطاق التطبيق

يتضمن:

- شاشة رادار فقط كواجهة رئيسية.
- تقارير آخر قراءة.
- مكتبة بيانات مختصرة للتحقق من 4303 خلية.
- localGroundGrid داخل APK.
- compact JSON داخل Android assets.

لا يتضمن:

- السلامة.
- الطقس.
- التنبؤات.
- مركز الأنظمة.
- مصادر خارجية.
- API إجباري.

هذه الأنظمة ستصبح تطبيقات مستقلة في الخطط التالية.

## القيود المحفوظة

```text
ground_cells = 4303
truth_status = partial_raw_grid_landsat_dem_not_full_spectral
No Gold Proof
No Depth
No 100%
Surface screening only
Field-check only
```
