# دليل دمج حزمة بوح الخفيفة داخل v12.1

## الهدف
جعل واجهة الرادار تعمل مباشرة ببيانات بوح الأساسية بدون تحميل باندات أو ملفات ثقيلة.

## مسار الدمج

### 1. نسخ الملفات
```bash
bash scripts/copy_into_v12_1.sh /path/to/bawh_terrain_local_pro
```

### 2. ربط FastAPI
في `apps/api/app/main.py`:
```python
from app.bouh_core.router import router as bouh_lightweight_router
app.include_router(bouh_lightweight_router)
```

### 3. ربط الواجهة
في `RadarMapLibre.tsx` أو صفحة الرادار:
```tsx
import BouhLightweightRadarPanel from "./bouh/BouhLightweightRadarPanel";
import "./bouh/bouh_panel.css";

<BouhLightweightRadarPanel
  onMessage={onMessage}
  onFlyTo={(lat, lng, label) => {
    mapRef.current?.flyTo({ center: [lng, lat], zoom: 14 });
    onMessage(`تم الانتقال إلى: ${label}`);
  }}
/>
```

### 4. إدخال البيانات الثقيلة اختياريًا
لا تضع GeoTIFF داخل APK.

ضعها فقط في Docker/Desktop:
```text
/app/data/imports/dem/
/app/data/imports/landsat8_171046_20260516/
/app/data/imports/sentinel2/
/app/data/imports/regional_zones/
```

### 5. فحص حالة الاستيراد
استدعِ:
`GET /bouh/imports/status`

### 6. قاعدة مهمة
الرادار يعمل حتى لو لم توجد imports. لكنه في هذه الحالة يعرض:
- precomputed targets
- screening points
- corridor metadata

ولا يحسب بيكسلات جديدة.


## v12.2 Overlay + Cache

تمت إضافة localStorage cache لـ /bouh/radar/bootstrap. وتمت إضافة overlays: bouh-official-targets وbouh-universal-support وbouh-sentinel2-support.
