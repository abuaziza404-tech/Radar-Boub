# قاموس بيانات بوح الخفيف — منع الخبط والهلوسة

## 1. Precomputed
بيانات خفيفة مستخرجة مسبقًا، مثل:
- أهداف Field-check.
- نقاط دعم نسبي.
- ملخص Sentinel.
- نطاقات جنوب/وسط/شمال.

هذه تعرض على الرادار فورًا، لكنها لا تعني أن الراستر الخام موجود داخل التطبيق.

## 2. Optional Import
ملفات ثقيلة لا توضع داخل APK:
- GeoTIFF
- DEM
- Landsat reflectance/TIR/QA/MTL
- Sentinel raw bands
- ZIP regional zones

توضع في:
`/app/data/imports`

## 3. Calculation-grade
مصدر يصلح للحساب إذا اكتملت شروطه:
- GeoTIFF خام.
- DEM.
- QA/MTL.
- CSV/JSON منظم.
- API موثق.

## 4. Visual-only
مصدر بصري فقط:
- PNG
- JPG
- KMZ/KML
- Browser_images

ممنوع إنتاج NDVI/NDWI/BSI/NDMI منها.

## 5. Relative Support
نقاط أو قيم تفاضل ميداني:
- ليست gold proof.
- ليست assay.
- ليست هدفًا مؤكدًا.
- تستخدم لترتيب الفحص فقط.

## 6. قواعد التسمية داخل الواجهة
لا تستخدم:
- هدف ذهب
- كشف
- مؤكد
- دفين
- عمق

استخدم:
- مؤشر سطحي
- دعم نسبي
- فحص ميداني
- يحتاج بيانات إضافية
- Reject
- Class A/B/C


## حقول إلزامية لكل نقطة v12.2

source، evidence_class، truth_status، limitation_ar، calculation_allowed، proof_status.
