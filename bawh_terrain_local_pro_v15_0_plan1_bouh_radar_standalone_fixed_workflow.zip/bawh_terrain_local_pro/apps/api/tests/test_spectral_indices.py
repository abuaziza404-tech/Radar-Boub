import numpy as np
from app.geo.spectral_indices import compute_spectral_indices, calculate_spectral_bonus

def test_indices_all_bands():
    bands={k:np.full((4,4),v,dtype="float32") for k,v in {"blue":.12,"green":.35,"red":.22,"nir":.68,"swir":.44}.items()}
    r=compute_spectral_indices(bands)
    assert r.ndvi is not None
    assert "ndvi" in r.summaries
    assert 0 <= calculate_spectral_bonus(r.summaries) <= 12
