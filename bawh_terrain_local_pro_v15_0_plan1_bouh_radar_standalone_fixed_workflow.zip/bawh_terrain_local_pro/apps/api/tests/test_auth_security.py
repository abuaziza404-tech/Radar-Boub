from app.auth.security import create_token, decode_token, hash_password, verify_password


def test_hash_password_and_verify():
    stored = hash_password("correct-password")
    assert verify_password("correct-password", stored)
    assert not verify_password("wrong-password", stored)


def test_token_round_trip():
    token = create_token({"sub": "1", "username": "admin", "role": "admin"}, ttl_hours=1)
    payload = decode_token(token)
    assert payload["sub"] == "1"
    assert payload["role"] == "admin"
