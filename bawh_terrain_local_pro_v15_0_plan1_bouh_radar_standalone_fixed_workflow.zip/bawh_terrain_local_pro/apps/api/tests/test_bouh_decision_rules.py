from app.bouh_core.decision_rules import decide_target_priority


def test_feox_alone_is_not_target():
    result = decide_target_priority({"source": "real_raster", "feox_evidence": True})
    assert result["target_priority"] == "Needs More Data"


def test_no_structure_no_silica_rejects():
    result = decide_target_priority({"source": "real_raster", "pattern_evidence": True})
    assert result["target_priority"] == "Reject"


def test_class_a_requires_structure_alteration_confirmation():
    result = decide_target_priority({
        "source": "uploaded_geotiff",
        "structure_evidence": True,
        "alteration_evidence": True,
        "spectral_confirmation": True,
    })
    assert result["target_priority"] == "Class A"
