from app.safety.risk_engine import analyze_safety_forecast
def test_safety_risks():
    raw={"current":{"temperature_2m":35,"wind_speed_10m":10,"wind_gusts_10m":20},"hourly":{"temperature_2m":[35,36],"wind_speed_10m":[10,12],"wind_gusts_10m":[20,25],"precipitation_probability":[10,20],"precipitation":[0,1],"visibility":[9000,8000],"soil_moisture_0_to_1cm":[.1,.2]}}
    r=analyze_safety_forecast(raw)
    assert r["ok"]
    assert len(r["risks"]) >= 5
