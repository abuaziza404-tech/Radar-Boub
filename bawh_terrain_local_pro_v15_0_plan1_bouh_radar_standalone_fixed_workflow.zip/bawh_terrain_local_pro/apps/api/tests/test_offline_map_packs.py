import sqlite3
from pathlib import Path

from app.offline.map_packs import detect_pack_type, inspect_mbtiles, read_mbtiles_tile, safe_pack_name


def create_test_mbtiles(path: Path) -> None:
    with sqlite3.connect(str(path)) as connection:
        cursor = connection.cursor()
        cursor.execute("CREATE TABLE metadata (name TEXT, value TEXT)")
        cursor.execute("CREATE TABLE tiles (zoom_level INTEGER, tile_column INTEGER, tile_row INTEGER, tile_data BLOB)")
        cursor.executemany(
            "INSERT INTO metadata (name, value) VALUES (?, ?)",
            [
                ("name", "test"),
                ("format", "png"),
                ("bounds", "10,20,30,40"),
                ("minzoom", "1"),
                ("maxzoom", "3"),
            ],
        )
        cursor.execute(
            "INSERT INTO tiles (zoom_level, tile_column, tile_row, tile_data) VALUES (?, ?, ?, ?)",
            (1, 1, 0, b"fake-png"),
        )
        connection.commit()


def test_detect_pack_type():
    assert detect_pack_type("a.mbtiles") == "mbtiles"
    assert detect_pack_type("a.pmtiles") == "pmtiles"


def test_safe_pack_name_removes_path_separators():
    assert safe_pack_name("../x.mbtiles") == ".._x.mbtiles"
    assert safe_pack_name("a\\b.pmtiles") == "a_b.pmtiles"


def test_inspect_and_read_mbtiles(tmp_path):
    path = tmp_path / "test.mbtiles"
    create_test_mbtiles(path)

    inspected = inspect_mbtiles(path)

    assert inspected["min_zoom"] == 1
    assert inspected["max_zoom"] == 1
    assert inspected["bounds"] == {"west": 10.0, "south": 20.0, "east": 30.0, "north": 40.0}
    assert inspected["metadata"]["tile_count"] == "1"

    tile = read_mbtiles_tile(path, 1, 1, 1)

    assert tile is not None
    assert tile[0] == b"fake-png"
    assert tile[1] == "image/png"
