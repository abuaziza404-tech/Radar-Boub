from app.geo.raster_layers import RASTER_LAYER_NAMES


def test_ndmi_layer_supported():
    assert "ndmi" in RASTER_LAYER_NAMES
