from app.security.upload_validation import validate_upload


def test_reject_dangerous_extension():
    result = validate_upload("evil.exe", 10, "application/octet-stream")
    assert result["errors"]


def test_kml_context_only():
    result = validate_upload("site.kml", 10, "application/vnd.google-earth.kml+xml")
    assert result["is_context_only"] is True
    assert result["is_analysis_ready"] is False


def test_geotiff_analysis_ready():
    result = validate_upload("band.tif", 10, "image/tiff")
    assert result["is_analysis_ready"] is True
