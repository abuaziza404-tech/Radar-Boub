from app.geo.bbox import calculate_bbox_from_center
def test_bbox_order():
    b=calculate_bbox_from_center(24.7,46.6,300)
    assert b.south < b.north
    assert b.west < b.east
    assert b.as_list() == [b.west,b.south,b.east,b.north]
