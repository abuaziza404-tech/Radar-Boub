from app.offline.tile_planner import build_tile_plan, estimate_tile_count, estimate_tile_ranges, lng_lat_to_tile


def test_lng_lat_to_tile_world_center():
    tile = lng_lat_to_tile(0, 0, 1)
    assert tile == {"x": 1, "y": 1}


def test_estimate_tile_ranges_valid():
    ranges = estimate_tile_ranges(46.0, 24.0, 46.1, 24.1, 10, 11)
    assert len(ranges) == 2
    assert all(item.count > 0 for item in ranges)


def test_build_tile_plan_sources():
    plan = build_tile_plan(46.0, 24.0, 46.01, 24.01, 10, 10, ["esri_satellite", "osm_streets"])
    assert plan["count"] == estimate_tile_count(46.0, 24.0, 46.01, 24.01, 10, 10, 2)
    assert plan["tiles"][0]["url"].startswith("https://")
