from pydantic import BaseModel, Field
class SafetyForecastRequest(BaseModel):
    lat: float = Field(ge=-90, le=90)
    lng: float = Field(ge=-180, le=180)
    project_id: int | None = None
    hours: int = Field(default=48, ge=1, le=168)
