from pathlib import Path
import sqlite3
from typing import Any


ALLOWED_MAP_PACK_EXTENSIONS = {".mbtiles", ".pmtiles"}


def safe_pack_name(filename: str) -> str:
    clean = filename.replace("/", "_").replace("\\", "_").strip()
    if not clean:
        raise ValueError("اسم الملف غير صالح")
    return clean


def detect_pack_type(filename: str) -> str:
    suffix = Path(filename).suffix.lower()

    if suffix == ".mbtiles":
        return "mbtiles"

    if suffix == ".pmtiles":
        return "pmtiles"

    raise ValueError("يدعم النظام MBTiles وPMTiles فقط")


def validate_map_pack_extension(filename: str) -> None:
    suffix = Path(filename).suffix.lower()

    if suffix not in ALLOWED_MAP_PACK_EXTENSIONS:
        raise ValueError("نوع حزمة الخرائط غير مدعوم")


def inspect_mbtiles(path: str | Path) -> dict[str, Any]:
    db_path = Path(path)

    if not db_path.exists():
        raise FileNotFoundError(str(db_path))

    metadata: dict[str, str] = {}
    zooms: list[int] = []

    with sqlite3.connect(str(db_path)) as connection:
        cursor = connection.cursor()

        try:
            cursor.execute("SELECT name, value FROM metadata")
            metadata = {str(name): str(value) for name, value in cursor.fetchall()}
        except sqlite3.Error:
            metadata = {}

        try:
            cursor.execute("SELECT MIN(zoom_level), MAX(zoom_level), COUNT(*) FROM tiles")
            row = cursor.fetchone()
            if row:
                min_zoom, max_zoom, tile_count = row
                if min_zoom is not None and max_zoom is not None:
                    zooms = [int(min_zoom), int(max_zoom)]
                metadata["tile_count"] = str(int(tile_count or 0))
        except sqlite3.Error:
            metadata["tile_count"] = "0"

    bounds = parse_bounds(metadata.get("bounds"))
    return {
        "metadata": metadata,
        "min_zoom": zooms[0] if zooms else parse_optional_int(metadata.get("minzoom")),
        "max_zoom": zooms[1] if zooms else parse_optional_int(metadata.get("maxzoom")),
        "bounds": bounds,
        "format": metadata.get("format", "png").lower(),
    }


def inspect_pmtiles(path: str | Path) -> dict[str, Any]:
    db_path = Path(path)
    if not db_path.exists():
        raise FileNotFoundError(str(db_path))

    return {
        "metadata": {
            "note": "PMTiles تم حفظه كحزمة خام. العرض المباشر يحتاج بروتوكول PMTiles أو تحويل إلى MBTiles.",
        },
        "min_zoom": None,
        "max_zoom": None,
        "bounds": {},
        "format": "pmtiles",
    }


def read_mbtiles_tile(path: str | Path, z: int, x: int, y: int) -> tuple[bytes, str] | None:
    db_path = Path(path)

    if not db_path.exists():
        raise FileNotFoundError(str(db_path))

    tms_y = (2 ** z - 1) - y

    with sqlite3.connect(str(db_path)) as connection:
        cursor = connection.cursor()
        cursor.execute(
            "SELECT tile_data FROM tiles WHERE zoom_level = ? AND tile_column = ? AND tile_row = ? LIMIT 1",
            (z, x, tms_y),
        )
        row = cursor.fetchone()

        if not row:
            return None

        tile_data = bytes(row[0])

        metadata = {}
        try:
            cursor.execute("SELECT name, value FROM metadata")
            metadata = {str(name): str(value) for name, value in cursor.fetchall()}
        except sqlite3.Error:
            metadata = {}

    fmt = metadata.get("format", "png").lower()
    media_type = {
        "png": "image/png",
        "jpg": "image/jpeg",
        "jpeg": "image/jpeg",
        "webp": "image/webp",
        "pbf": "application/x-protobuf",
        "mvt": "application/x-protobuf",
    }.get(fmt, "application/octet-stream")

    return tile_data, media_type


def parse_bounds(value: str | None) -> dict[str, float]:
    if not value:
        return {}

    try:
        west, south, east, north = [float(part.strip()) for part in value.split(",")]
        return {"west": west, "south": south, "east": east, "north": north}
    except Exception:
        return {}


def parse_optional_int(value: str | None) -> int | None:
    if value in [None, ""]:
        return None

    try:
        return int(float(value))
    except Exception:
        return None
