from dataclasses import dataclass
import math


SOURCE_TEMPLATES = {
    "esri_satellite": "https://services.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
    "esri_reference": "https://services.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}",
    "osm_streets": "https://tile.openstreetmap.org/{z}/{x}/{y}.png",
}


@dataclass
class TileRange:
    zoom: int
    min_x: int
    max_x: int
    min_y: int
    max_y: int

    @property
    def count(self) -> int:
        return max(0, self.max_x - self.min_x + 1) * max(0, self.max_y - self.min_y + 1)


def estimate_tile_ranges(west: float, south: float, east: float, north: float, min_zoom: int, max_zoom: int) -> list[TileRange]:
    if min_zoom < 0 or max_zoom > 22 or min_zoom > max_zoom:
        raise ValueError("zoom range غير صالح")

    ranges: list[TileRange] = []

    for zoom in range(min_zoom, max_zoom + 1):
        north_west = lng_lat_to_tile(west, north, zoom)
        south_east = lng_lat_to_tile(east, south, zoom)

        ranges.append(
            TileRange(
                zoom=zoom,
                min_x=max(0, min(north_west["x"], south_east["x"])),
                max_x=max(north_west["x"], south_east["x"]),
                min_y=max(0, min(north_west["y"], south_east["y"])),
                max_y=max(north_west["y"], south_east["y"]),
            )
        )

    return ranges


def estimate_tile_count(west: float, south: float, east: float, north: float, min_zoom: int, max_zoom: int, source_count: int = 1) -> int:
    return sum(tile_range.count for tile_range in estimate_tile_ranges(west, south, east, north, min_zoom, max_zoom)) * source_count


def build_tile_plan(west: float, south: float, east: float, north: float, min_zoom: int, max_zoom: int, sources: list[str]) -> dict:
    ranges = estimate_tile_ranges(west, south, east, north, min_zoom, max_zoom)
    tiles = []

    for tile_range in ranges:
        for x in range(tile_range.min_x, tile_range.max_x + 1):
            for y in range(tile_range.min_y, tile_range.max_y + 1):
                for source in sources:
                    template = SOURCE_TEMPLATES[source]
                    tiles.append(
                        {
                            "source": source,
                            "z": tile_range.zoom,
                            "x": x,
                            "y": y,
                            "url": template.replace("{z}", str(tile_range.zoom)).replace("{x}", str(x)).replace("{y}", str(y)),
                        }
                    )

    return {
        "sources": sources,
        "count": len(tiles),
        "ranges": [tile_range.__dict__ for tile_range in ranges],
        "tiles": tiles,
    }


def lng_lat_to_tile(lng: float, lat: float, zoom: int) -> dict[str, int]:
    lat = max(-85.05112878, min(85.05112878, lat))
    n = 2 ** zoom
    lat_rad = math.radians(lat)
    x = int(((lng + 180.0) / 360.0) * n)
    y = int(((1.0 - math.log(math.tan(lat_rad) + 1 / math.cos(lat_rad)) / math.pi) / 2.0) * n)
    return {"x": x, "y": y}
