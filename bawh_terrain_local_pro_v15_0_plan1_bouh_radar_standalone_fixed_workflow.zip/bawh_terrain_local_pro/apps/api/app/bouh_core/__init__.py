"""BOUH Core lightweight data integration package."""
