from typing import Any

VISUAL_ONLY_SOURCES = {"visual_only", "example", "synthetic_fallback"}


def boolish(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return value > 0
    if isinstance(value, str):
        return value.strip().lower() in {"1", "true", "yes", "y", "high", "present", "موجود"}
    return False


def numeric(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except Exception:
        return default


def decide_target_priority(evidence: dict[str, Any]) -> dict[str, Any]:
    """Structure → Pattern → Alteration → Confirmation → Decision."""
    source = str(evidence.get("source") or evidence.get("evidence_source") or "unknown")
    structure = boolish(evidence.get("structure_evidence"))
    pattern = boolish(evidence.get("pattern_evidence"))
    clay_silica = boolish(evidence.get("clay_silica_evidence")) or boolish(evidence.get("silica_evidence")) or boolish(evidence.get("quartz_evidence"))
    alteration = boolish(evidence.get("alteration_evidence")) or clay_silica
    confirmation = boolish(evidence.get("spectral_confirmation")) or boolish(evidence.get("field_confirmation"))
    feox = boolish(evidence.get("feox_evidence"))
    real_numeric = source not in VISUAL_ONLY_SOURCES and source != "unknown"

    reasons: list[str] = []

    if feox and not (structure or clay_silica or confirmation):
        reasons.append("FeOx وحده لا يكفي للتقييم.")
        return decision("Needs More Data", reasons, evidence)

    if not structure and not clay_silica:
        reasons.append("لا يوجد دليل بنيوي ولا دليل طين/سيليكا؛ يتم رفض الهدف.")
        return decision("Reject", reasons, evidence)

    if source in {"visual_only", "example"}:
        reasons.append("الصور البصرية وGoogle Earth/JPG/PNG/KML/KMZ سياق فقط وليست دليلاً طيفياً رقمياً.")
        if structure or clay_silica:
            return decision("Needs More Data", reasons, evidence)
        return decision("Reject", reasons, evidence)

    if source == "synthetic_fallback":
        reasons.append("المصدر synthetic_fallback للتجربة فقط ولا يسمح بثقة عالية.")
        return decision("Needs More Data", reasons, evidence)

    if structure and alteration and confirmation and real_numeric:
        reasons.append("دليل بنيوي + تغير/سيليكا/كوارتز + تأكيد طيفي/ميداني من مصدر رقمي.")
        return decision("Class A", reasons, evidence)

    if structure and (alteration or confirmation) and real_numeric:
        reasons.append("دليل بنيوي مع دليل تغير أو تأكيد؛ يحتاج تحقق ميداني.")
        return decision("Class B", reasons, evidence)

    if pattern and (structure or alteration) and real_numeric:
        reasons.append("نمط سطحي مع دليل مساعد؛ أولوية منخفضة للمراجعة.")
        return decision("Class C", reasons, evidence)

    reasons.append("المعطيات غير كافية لاتخاذ قرار موثوق.")
    return decision("Needs More Data", reasons, evidence)


def decision(class_name: str, reasons: list[str], evidence: dict[str, Any]) -> dict[str, Any]:
    return {
        "target_priority": class_name,
        "decision_rule": "Structure → Pattern → Alteration → Confirmation → Decision",
        "reasons_ar": reasons,
        "allowed_outputs": ["Class A", "Class B", "Class C", "Reject", "Needs More Data"],
        "scientific_guardrail_ar": "بوح التضاريس منصة تحليل تضاريس وطبقات سطحية وسلامة ميدانية. النتائج احتمالية وتحتاج تحقق ميداني. النظام لا يثبت وجود ذهب أو دفائن أو أهداف تحت الأرض.",
        "input_summary": {
            "source": evidence.get("source") or evidence.get("evidence_source") or "unknown",
            "structure_evidence": boolish(evidence.get("structure_evidence")),
            "pattern_evidence": boolish(evidence.get("pattern_evidence")),
            "alteration_evidence": boolish(evidence.get("alteration_evidence")),
            "confirmation": boolish(evidence.get("spectral_confirmation")) or boolish(evidence.get("field_confirmation")),
        },
    }
