from __future__ import annotations

from fastapi import APIRouter
from app.bouh_core.precomputed_repository import (
    get_data_definitions,
    get_drive_import_manifest,
    get_evidence_registry,
    get_official_targets,
    get_radar_bootstrap_payload,
    get_regional_zones,
    get_truth_policy,
    get_universal_summary,
)
from app.bouh_core.import_status import scan_imports
from app.bouh_core.live_score_repository import live_score, live_score_status

router = APIRouter(prefix="/bouh", tags=["BOUH Lightweight Intelligence"])

@router.get("/radar/bootstrap")
def radar_bootstrap():
    return get_radar_bootstrap_payload()

@router.get("/truth-policy")
def truth_policy():
    return get_truth_policy()

@router.get("/evidence-registry")
def evidence_registry():
    return get_evidence_registry()

@router.get("/regional-zones")
def regional_zones():
    return get_regional_zones()

@router.get("/official-targets")
def official_targets():
    return get_official_targets()

@router.get("/universal-summary")
def universal_summary():
    return get_universal_summary()

@router.get("/import-manifest")
def import_manifest():
    return get_drive_import_manifest()

@router.get("/data-definitions")
def data_definitions():
    return get_data_definitions()

@router.get("/imports/status")
def imports_status():
    return scan_imports()


@router.get("/live-score")
def bouh_live_score(lat: float, lng: float, radius: float = 300):
    return live_score(lat, lng, radius)


@router.get("/live-score/status")
def bouh_live_score_status():
    return live_score_status()
