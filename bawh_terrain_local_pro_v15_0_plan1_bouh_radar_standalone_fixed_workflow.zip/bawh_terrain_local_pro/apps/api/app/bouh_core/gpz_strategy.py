from typing import Any


def number(value: Any) -> float | None:
    try:
        return float(value)
    except Exception:
        return None


def recommend_gpz_strategy(magnetic_ground_risk: Any = None, quartz_qi: Any = None) -> dict:
    magnetic = number(magnetic_ground_risk)
    quartz = number(quartz_qi)

    if magnetic is None:
        return insufficient()

    if magnetic > 0.75:
        return {
            "status": "estimated",
            "ground_type": "Severe/Difficult",
            "gold_mode": "High Yield",
            "sensitivity": "8–11",
            "audio_smoothing": "Low/On",
            "swing": "Slow",
            "notes_ar": "أرض مغناطيسية عالية، خفّض الحساسية وركز على ثبات الصوت.",
        }

    if magnetic < 0.45 and quartz is not None and quartz >= 0.65:
        return {
            "status": "estimated",
            "ground_type": "Normal",
            "gold_mode": "General/Deep",
            "sensitivity": "12–16",
            "audio_smoothing": "Off",
            "swing": "Slow controlled",
            "notes_ar": "مناسب لاختبار عروق كوارتز أو سطح أقل إزعاجًا.",
        }

    return {
        "status": "estimated",
        "ground_type": "Difficult",
        "gold_mode": "General",
        "sensitivity": "10–13",
        "audio_smoothing": "Low",
        "swing": "Slow controlled",
        "notes_ar": "إعداد متوسط؛ راقب الضوضاء الأرضية وعدّل الحساسية تدريجيًا.",
    }


def insufficient() -> dict:
    return {
        "status": "insufficient_data",
        "ground_type": "Unknown",
        "gold_mode": "Unknown",
        "sensitivity": "Unknown",
        "audio_smoothing": "Unknown",
        "swing": "Slow",
        "notes_ar": "إعداد GPZ تقديري يحتاج فحص أرضي.",
    }
