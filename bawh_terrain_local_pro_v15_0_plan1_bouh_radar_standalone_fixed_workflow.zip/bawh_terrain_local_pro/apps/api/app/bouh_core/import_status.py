from __future__ import annotations

import os
from pathlib import Path
from typing import Any
from app.bouh_core.evidence_policy import classify_file_name

def _safe_relative(path: Path, root: Path) -> str:
    try:
        return str(path.relative_to(root))
    except ValueError:
        return str(path)

def import_root() -> Path:
    return Path(os.getenv("BOUH_IMPORT_ROOT", "/app/data/imports"))

def scan_imports(root: Path | None = None) -> dict[str, Any]:
    root = root or import_root()
    items: list[dict[str, Any]] = []

    if root.exists():
        for path in sorted(root.rglob("*")):
            if path.is_file():
                info = classify_file_name(path.name)
                items.append({
                    "file_name": path.name,
                    "relative_path": _safe_relative(path, root),
                    "size_bytes": path.stat().st_size,
                    **info,
                })

    counts: dict[str, int] = {}
    for item in items:
        cls = item["evidence_class"]
        counts[cls] = counts.get(cls, 0) + 1

    return {
        "ok": True,
        "root": str(root),
        "count": len(items),
        "class_counts": counts,
        "items": items,
        "notes_ar": [
            "عدم وجود ملفات imports لا يمنع تشغيل الرادار؛ سيعمل على البيانات الخفيفة المسبقة.",
            "الراسترات الثقيلة اختيارية وتستخدم للتحليل الكامل على Docker/Desktop.",
        ]
    }
