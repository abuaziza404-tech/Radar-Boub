from celery import Celery
from sqlalchemy.orm import Session
from app.config import settings
from app.database import SessionLocal
from app.geo.bbox import calculate_bbox_from_center
from app.geo.terrain import analyze_dem_array, generate_synthetic_dem
from app.geo.raster_layers import save_project_raster_layers
from app.models import ScanProject, TerrainMetrics

celery_app = Celery("bawh_terrain_worker", broker=settings.redis_url, backend=settings.redis_url)

@celery_app.task(name="run_terrain_analysis")
def run_terrain_analysis(project_id: int) -> dict:
    db: Session = SessionLocal()
    try:
        project = db.get(ScanProject, project_id)
        if project is None: return {"ok": False, "error": "project_not_found"}
        project.status = "processing"; db.commit()
        bbox = calculate_bbox_from_center(project.center_lat, project.center_lng, project.radius_m)
        dem = generate_synthetic_dem(160)
        metadata = {"bbox": bbox.as_dict(), "dem_source":"synthetic-fallback", "errors":[]}
        layers = save_project_raster_layers(project.id, dem, bbox, None)
        metadata["raster_layers"] = layers
        result = analyze_dem_array(dem, 30.0, project.soil_type, project.terrain_type, "synthetic-fallback")
        old = db.query(TerrainMetrics).filter(TerrainMetrics.project_id == project.id).first()
        if old: db.delete(old); db.commit()
        db.add(TerrainMetrics(project_id=project.id, mean_elevation=result.mean_elevation, min_elevation=result.min_elevation, max_elevation=result.max_elevation, mean_slope=result.mean_slope, max_slope=result.max_slope, roughness_score=result.roughness_score, flow_score=result.flow_score, data_quality_score=result.data_quality_score, final_score=result.final_score, report_ar=result.report_ar, layer_urls={}, source_metadata=metadata))
        project.status = "completed"; db.commit()
        return {"ok": True, "project_id": project_id}
    except Exception as exc:
        p = db.get(ScanProject, project_id)
        if p: p.status = "failed"; db.commit()
        return {"ok": False, "error": str(exc)}
    finally:
        db.close()
