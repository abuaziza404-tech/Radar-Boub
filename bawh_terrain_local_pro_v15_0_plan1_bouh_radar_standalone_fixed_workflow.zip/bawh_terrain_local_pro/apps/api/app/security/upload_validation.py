from pathlib import Path
import hashlib
import mimetypes
import time

SAFE_EXTENSIONS = {
    ".tif", ".tiff", ".jp2", ".zip", ".geojson", ".json", ".csv", ".mbtiles", ".pmtiles", ".kml", ".kmz", ".png", ".jpg", ".jpeg", ".webp"
}
CONTEXT_ONLY_EXTENSIONS = {".kml", ".kmz", ".png", ".jpg", ".jpeg", ".webp"}
DANGEROUS_EXTENSIONS = {".exe", ".bat", ".cmd", ".sh", ".ps1", ".dll", ".so", ".dylib", ".js", ".mjs", ".php", ".py", ".jar", ".apk"}
MAX_UPLOAD_BYTES = 1024 * 1024 * 1024


def sanitize_filename(filename: str) -> str:
    clean = filename.replace("/", "_").replace("\\", "_").strip().strip(".")
    if not clean:
        clean = f"upload_{int(time.time())}"
    return clean[:260]


def detect_type(filename: str, content_type: str | None = None) -> dict:
    suffix = Path(filename).suffix.lower()

    if suffix in DANGEROUS_EXTENSIONS:
        return {"detected_type": "dangerous", "is_context_only": True, "is_analysis_ready": False, "errors": ["امتداد خطر محظور."]}

    if suffix not in SAFE_EXTENSIONS:
        return {"detected_type": "unsupported", "is_context_only": True, "is_analysis_ready": False, "errors": ["امتداد غير مدعوم."]}

    if suffix in {".tif", ".tiff", ".jp2"}:
        detected = "raster_band_or_dem"
        analysis_ready = True
        context_only = False
    elif suffix == ".zip":
        detected = "archive_zip"
        analysis_ready = True
        context_only = False
    elif suffix in {".geojson", ".json", ".csv"}:
        detected = "structured_data"
        analysis_ready = True
        context_only = False
    elif suffix in {".mbtiles", ".pmtiles"}:
        detected = "offline_map_pack"
        analysis_ready = True
        context_only = False
    elif suffix in CONTEXT_ONLY_EXTENSIONS:
        detected = "visual_context"
        analysis_ready = False
        context_only = True
    else:
        detected = "supported_upload"
        analysis_ready = False
        context_only = True

    return {
        "detected_type": detected,
        "is_context_only": context_only,
        "is_analysis_ready": analysis_ready,
        "errors": [],
        "mime_guess": content_type or mimetypes.guess_type(filename)[0] or "application/octet-stream",
    }


def validate_upload(filename: str, size: int, content_type: str | None = None) -> dict:
    safe = sanitize_filename(filename)
    inspection = detect_type(safe, content_type)

    errors = list(inspection.get("errors", []))
    if size > MAX_UPLOAD_BYTES:
        errors.append("حجم الملف أكبر من الحد المسموح.")

    valid = not errors and inspection["detected_type"] != "dangerous"

    return {
        "file_name": safe,
        "size": size,
        "content_type": content_type or inspection.get("mime_guess") or "application/octet-stream",
        "detected_type": inspection["detected_type"],
        "role": role_for_type(inspection["detected_type"]),
        "band_role": None,
        "crs": None,
        "bounds": None,
        "is_analysis_ready": bool(valid and inspection["is_analysis_ready"]),
        "is_context_only": bool(inspection["is_context_only"]),
        "errors": errors,
        "recommendation_ar": recommendation(inspection["detected_type"], errors),
        "sha256": None,
    }


def enrich_with_hash(meta: dict, data: bytes) -> dict:
    meta = dict(meta)
    meta["sha256"] = hashlib.sha256(data).hexdigest()
    return meta


def role_for_type(detected_type: str) -> str:
    return {
        "raster_band_or_dem": "analysis_raster",
        "archive_zip": "dataset_archive",
        "structured_data": "tabular_or_vector",
        "offline_map_pack": "offline_maps",
        "visual_context": "visual_context_only",
    }.get(detected_type, "unknown")


def recommendation(detected_type: str, errors: list[str]) -> str:
    if errors:
        return "ارفض الملف أو صحح الامتداد/الحجم قبل التحليل."
    if detected_type == "visual_context":
        return "سياق بصري فقط؛ لا يستخدم كدليل طيفي رقمي."
    if detected_type == "raster_band_or_dem":
        return "حدد band_role أو DEM role ثم شغّل التحليل."
    if detected_type == "offline_map_pack":
        return "استخدم الحزمة في الخرائط Offline."
    if detected_type == "archive_zip":
        return "سيتم فحص ZIP وفكه بأمان دون تنفيذ أي ملف."
    return "جاهز للفهرسة أو المراجعة."
