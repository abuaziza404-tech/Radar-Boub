from dataclasses import dataclass
import numpy as np


@dataclass
class SpectralIndexResult:
    ndvi: np.ndarray | None
    ndwi: np.ndarray | None
    bsi: np.ndarray | None
    ndmi: np.ndarray | None
    summaries: dict[str, dict[str, float]]


def safe_divide(numerator, denominator):
    with np.errstate(divide="ignore", invalid="ignore"):
        result = numerator / denominator
        result[~np.isfinite(result)] = np.nan
        return np.clip(result, -1, 1)


def normalize_reflectance(array: np.ndarray) -> np.ndarray:
    values = array.astype("float32")
    values[values <= 0] = np.nan
    finite = values[np.isfinite(values)]
    if finite.size and float(np.nanpercentile(finite, 99)) > 2:
        values = values / 10000.0 if float(np.nanpercentile(finite, 99)) > 255 else values / 255.0
    return np.clip(values, 0, 1)


def summarize_index(name: str, index: np.ndarray) -> dict[str, float]:
    valid = np.isfinite(index)
    if not np.any(valid):
        return {"min": 0.0, "max": 0.0, "mean": 0.0, "std": 0.0, "valid_pixel_ratio": 0.0}
    vals = index[valid]
    return {
        "min": float(np.nanmin(vals)),
        "max": float(np.nanmax(vals)),
        "mean": float(np.nanmean(vals)),
        "std": float(np.nanstd(vals)),
        "valid_pixel_ratio": float(np.sum(valid) / index.size),
    }


def compute_spectral_indices(bands: dict[str, np.ndarray]) -> SpectralIndexResult:
    n = {key: normalize_reflectance(value) for key, value in bands.items() if value is not None}
    blue = n.get("blue")
    green = n.get("green")
    red = n.get("red")
    nir = n.get("nir")
    swir = n.get("swir")

    ndvi = safe_divide(nir - red, nir + red) if nir is not None and red is not None else None
    ndwi = safe_divide(green - nir, green + nir) if green is not None and nir is not None else None
    bsi = safe_divide((swir + red) - (nir + blue), (swir + red) + (nir + blue)) if all(b is not None for b in [blue, red, nir, swir]) else None
    ndmi = safe_divide(nir - swir, nir + swir) if nir is not None and swir is not None else None

    summaries = {}
    for name, value in [("ndvi", ndvi), ("ndwi", ndwi), ("bsi", bsi), ("ndmi", ndmi)]:
        if value is not None:
            summaries[name] = summarize_index(name, value)

    return SpectralIndexResult(ndvi, ndwi, bsi, ndmi, summaries)


def calculate_spectral_bonus(summaries: dict[str, dict[str, float]]) -> float:
    bonus = 0.0
    for name, weight in [("ndvi", 4), ("ndwi", 5), ("bsi", 3), ("ndmi", 3)]:
        mean = summaries.get(name, {}).get("mean")
        if isinstance(mean, (int, float)):
            bonus += max(0, min(1, (mean + 1) / 2)) * weight
    return float(max(0, min(12, bonus)))
