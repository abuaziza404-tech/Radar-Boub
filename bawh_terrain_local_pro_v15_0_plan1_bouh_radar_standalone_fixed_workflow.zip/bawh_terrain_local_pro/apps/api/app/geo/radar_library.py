from dataclasses import dataclass
from pathlib import Path
import csv, json

SUMMARY_CSV_PATH = Path("/app/data/imports/bouh_sentinel_dataset_summary.csv")
REVIEW_JSON_PATH = Path("/app/data/imports/bouh_uploaded_data_review.json")
RADAR_ROLE_LABELS_AR = {
    "regional_south":"النطاق الجنوبي","regional_center":"نطاق الوسط","regional_north":"نطاق الشمال",
    "port_partial":"طبقة Port الجزئية","local_target_west":"الهدف المحلي الغربي","local_target_east":"الهدف المحلي الشرقي",
    "abuziza_local_app":"سجل أبو عزيزة المحلي","unclassified":"غير مصنف"
}
RADAR_ROLE_ORDER = ["regional_south","regional_center","regional_north","port_partial","local_target_west","local_target_east","abuziza_local_app"]

@dataclass
class RadarLibraryItem:
    role: str
    label_ar: str
    source_name: str
    complete_core: bool
    band_count: int
    west: float | None
    south: float | None
    east: float | None
    north: float | None
    center_lat: float | None
    center_lng: float | None
    ndvi_mean: float | None
    ndwi_mean: float | None
    bsi_mean: float | None
    ndmi_mean: float | None
    analysis_status: str
    recommendation_ar: str

def parse_float(v):
    try:
        if v in [None,"","nan","None"]: return None
        return float(v)
    except Exception: return None
def parse_int(v):
    try:
        if v in [None,"","nan","None"]: return 0
        return int(float(v))
    except Exception: return 0
def parse_bool(v): return str(v).lower() in {"true","1","yes","y"}

def load_summary_rows():
    if not SUMMARY_CSV_PATH.exists(): return []
    with SUMMARY_CSV_PATH.open("r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))

def status(role, complete, bands):
    if role == "abuziza_local_app": return "register_import_only"
    if complete and bands >= 5: return "analysis_ready"
    if bands > 0: return "partial_context_only"
    return "raw_storage_only"

def recommend(role, complete, bands):
    if role == "regional_center": return "مهم جدًا: يكمل الربط بين الجنوب والشمال."
    if role in {"regional_south","regional_north"}: return "نطاق إقليمي رئيسي للمقارنة."
    if role == "port_partial": return "ملف جزئي يدمج كسياق."
    if role == "abuziza_local_app": return "سجل محلي يحتاج مراجعة أو نموذج لاحق."
    return "قابل للتحليل الطيفي." if complete else "يحفظ كبيانات خام."

def build_radar_library():
    items = []
    for r in load_summary_rows():
        role = r.get("role") or "unclassified"
        bands = parse_int(r.get("band_count"))
        complete = parse_bool(r.get("complete_core"))
        items.append(RadarLibraryItem(role, RADAR_ROLE_LABELS_AR.get(role,role), r.get("zip") or role, complete, bands, parse_float(r.get("west")), parse_float(r.get("south")), parse_float(r.get("east")), parse_float(r.get("north")), parse_float(r.get("center_lat")), parse_float(r.get("center_lng")), parse_float(r.get("NDVI_mean")), parse_float(r.get("NDWI_mean")), parse_float(r.get("BSI_mean")), parse_float(r.get("NDMI_mean")), status(role,complete,bands), recommend(role,complete,bands)))
    items.sort(key=lambda i: RADAR_ROLE_ORDER.index(i.role) if i.role in RADAR_ROLE_ORDER else 999)
    return items

def build_dataset_detail(role):
    item = next((i for i in build_radar_library() if i.role == role), None)
    if not item: return {"ok":False,"message":"النطاق غير موجود"}
    notes = []
    notes.append("النطاق يحتوي الباندات الأساسية." if item.complete_core else "النطاق جزئي ولا يصلح لكل المؤشرات.")
    if item.ndwi_mean is not None and item.ndwi_mean < 0: notes.append("NDWI سالب، غالبًا سطح جاف.")
    if item.bsi_mean is not None and item.bsi_mean > 0: notes.append("BSI موجب، سطح عارٍ نسبيًا.")
    notes.append("المؤشرات سطحية ولا تثبت وجود أهداف تحت الأرض.")
    actions = [{"id":"show_on_map","label_ar":"إظهار على الخريطة","enabled":item.west is not None},{"id":"send_to_ai_queue","label_ar":"إرسال لنموذج لاحق","enabled":True}]
    return {"ok":True,"item":item.__dict__,"quality_notes":notes,"radar_actions":actions}
