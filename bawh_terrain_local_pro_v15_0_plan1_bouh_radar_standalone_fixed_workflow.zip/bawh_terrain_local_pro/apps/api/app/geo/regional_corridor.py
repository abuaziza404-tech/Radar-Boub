from dataclasses import dataclass

REGIONAL_ORDER = ["regional_south","regional_center","regional_north"]

@dataclass
class CorridorSegment:
    role: str
    name: str
    west: float
    south: float
    east: float
    north: float
    center_lat: float
    center_lng: float
    ndvi_mean: float | None
    ndwi_mean: float | None
    bsi_mean: float | None
    ndmi_mean: float | None
    complete_core: bool

def _float(v):
    try:
        if v in [None,"","nan","None"]: return None
        return float(v)
    except Exception:
        return None

def build_corridor_segments(rows):
    by = {r.get("role"): r for r in rows}
    out = []
    for role in REGIONAL_ORDER:
        r = by.get(role)
        if not r: continue
        out.append(CorridorSegment(role, r.get("zip", role), float(r["west"]), float(r["south"]), float(r["east"]), float(r["north"]), float(r["center_lat"]), float(r["center_lng"]), _float(r.get("NDVI_mean")), _float(r.get("NDWI_mean")), _float(r.get("BSI_mean")), _float(r.get("NDMI_mean")), str(r.get("complete_core")).lower()=="true"))
    return out

def trend(values):
    values = [v for v in values if v is not None]
    if not values: return {"available": False}
    delta = values[-1]-values[0] if len(values)>1 else 0.0
    return {"available": True, "first": values[0], "last": values[-1], "delta": delta, "direction": "increasing" if delta > .02 else "decreasing" if delta < -.02 else "stable", "mean": sum(values)/len(values)}

def analyze_corridor_trend(segments):
    if len(segments) < 2: return {"status":"insufficient_segments","message":"لا توجد قطاعات كافية."}
    ndvi = [s.ndvi_mean for s in segments]
    ndwi = [s.ndwi_mean for s in segments]
    bsi = [s.bsi_mean for s in segments]
    return {"status":"ready","segment_count":len(segments),"roles":[s.role for s in segments],"ndvi":trend(ndvi),"ndwi":trend(ndwi),"bsi":trend(bsi),"interpretation_ar":"الممر الإقليمي يميل إلى بيئة جافة نسبيًا عند سلبية NDWI وإيجابية BSI. التحليل سطحي فقط."}
