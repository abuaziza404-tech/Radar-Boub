import math
from dataclasses import dataclass

@dataclass(frozen=True)
class BBox:
    south: float
    west: float
    north: float
    east: float
    def as_list(self) -> list[float]:
        return [self.west, self.south, self.east, self.north]
    def as_dict(self) -> dict[str, float]:
        return {"south": self.south, "west": self.west, "north": self.north, "east": self.east}

def calculate_bbox_from_center(lat: float, lng: float, radius_m: float) -> BBox:
    earth_radius_m = 6371000.0
    lat_delta = math.degrees(radius_m / earth_radius_m)
    cos_lat = max(0.000001, math.cos(math.radians(lat)))
    lng_delta = math.degrees(radius_m / (earth_radius_m * cos_lat))
    return BBox(
        south=max(-90, lat - lat_delta),
        west=max(-180, lng - lng_delta),
        north=min(90, lat + lat_delta),
        east=min(180, lng + lng_delta),
    )
