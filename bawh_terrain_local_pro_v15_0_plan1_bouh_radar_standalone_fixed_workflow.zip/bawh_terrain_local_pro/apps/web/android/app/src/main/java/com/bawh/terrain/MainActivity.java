package com.bawh.terrain;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
