import React from "react";

export default function SafetyPage() {
  const controls = [
    ["Offline-first", "مفعل"],
    ["Safe uploads", "مفعل"],
    ["Path traversal", "مفعل"],
    ["Local cache", "مفعل"],
    ["API headers", "محلي فقط"],
    ["JWT/RBAC", "اختياري"]
  ];

  return (
    <section className="screen concise-page operational-safety">
      <article className="hero-card compact clean-card">
        <span className="eyebrow">السلامة</span>
        <h2>لوحة تشغيل آمن مختصرة</h2>
        <p>القسم يوضح ضوابط التشغيل المحلي دون عرض رسائل API تقنية للمستخدم الميداني.</p>
      </article>

      <section className="security-dashboard">
        {controls.map(([label, value]) => (
          <div key={label} className="security-tile">
            <span>{label}</span>
            <strong>{value}</strong>
          </div>
        ))}
      </section>

      <article className="truth-card compact">
        <strong>No Gold Proof</strong>
        <span>No Depth</span>
        <span>No 100%</span>
      </article>
    </section>
  );
}
