import React, { useEffect, useState } from "react";
import { getLocalGroundGridStatus, readLastLocalGroundReading } from "./bouh/localGroundGrid";

type GridStatus = {
  ground_cells: number;
  truth_status: string;
  min_lat: number;
  max_lat: number;
  min_lng: number;
  max_lng: number;
};

const systems = [
  ["رادار التحليل", "تشغيلي", "خريطة → مركز الشاشة → بحث محلي → Ground Score"],
  ["قاعدة التحليل", "تشغيلي", "4303 خلية محفوظة داخل APK"],
  ["التقارير", "تشغيلي", "تقرير نقطة و JSON من آخر قراءة محلية"],
  ["المكتبة", "تشغيلي", "حالة التغطية والنطاقات واختبار أقرب خلية"],
  ["السلامة", "تشغيلي", "لوحة تشغيل آمن مختصرة Offline-first"],
  ["الإعدادات", "تشغيلي", "radius والطبقة وتتبع المركز و cache"],
  ["مصادر خارجية", "اختيارية", "غير مطلوبة لحساب Ground Score"]
];

export default function SystemsPage({ onMessage }: { onMessage: (message: string) => void }) {
  const [status, setStatus] = useState<GridStatus | null>(null);
  const [lastMode, setLastMode] = useState("لا توجد قراءة بعد");

  useEffect(() => {
    refresh();
  }, []);

  async function refresh() {
    const grid = await getLocalGroundGridStatus();
    const last = readLastLocalGroundReading();
    setStatus(grid);
    setLastMode(last ? `${last.mode}${last.result ? ` · ${last.result.class} · ${last.result.final_ground_score}` : ""}` : "لا توجد قراءة بعد");
    onMessage("تم تحديث لوحة الأنظمة المحلية.");
  }

  return (
    <section className="screen concise-page operational-systems">
      <article className="hero-card compact clean-card">
        <span className="eyebrow">مركز الأنظمة</span>
        <h2>النسخة الاحترافية التشغيلية</h2>
        <p>كل الأنظمة الأساسية تعمل من داخل APK، و API الخارجي اختياري وليس مصدر الحساب.</p>
        <button className="primary full" type="button" onClick={refresh}>فحص كل الأنظمة</button>
      </article>

      <article className="panel clean-card">
        <h3>حالة التشغيل</h3>
        <div className="status-list">
          <div><span>قاعدة التحليل</span><strong>{status?.ground_cells ?? 4303} خلية</strong></div>
          <div><span>truth_status</span><strong dir="ltr">{status?.truth_status ?? "partial_raw_grid_landsat_dem_not_full_spectral"}</strong></div>
          <div><span>آخر قراءة</span><strong>{lastMode}</strong></div>
          <div><span>وضع API</span><strong>اختياري / ليس مطلوبًا</strong></div>
        </div>
      </article>

      <article className="panel clean-card">
        <h3>الأنظمة</h3>
        <div className="system-grid-pro">
          {systems.map(([name, state, detail]) => (
            <div key={name}>
              <strong>{name}</strong>
              <span>{state}</span>
              <p>{detail}</p>
            </div>
          ))}
        </div>
      </article>

      <article className="truth-card compact">
        <strong>No Gold Proof</strong>
        <span>No Depth</span>
        <span>No 100%</span>
        <span>Field-check</span>
      </article>
    </section>
  );
}
