import React, { useEffect, useState } from "react";
import RadarPage from "./RadarPage";
import ReportPage from "./ReportPage";
import LibraryPage from "./LibraryPage";
import { getLocalGroundGridStatus } from "./bouh/localGroundGrid";

type Screen = "radar" | "reports" | "library";

const navItems: Array<{ id: Screen; label: string; icon: string }> = [
  { id: "radar", label: "الرادار", icon: "◎" },
  { id: "reports", label: "التقارير", icon: "▤" },
  { id: "library", label: "البيانات", icon: "▥" }
];

export default function App() {
  const [screen, setScreen] = useState<Screen>("radar");
  const [lat, setLat] = useState(19.41022162800518);
  const [lng, setLng] = useState(36.86820999932388);
  const [message, setMessage] = useState("BOUH Radar يعمل محليًا.");
  const [defaultRadius, setDefaultRadius] = useState<number>(() => Number(localStorage.getItem("bouh.default_radius") ?? 300));
  const [followCenterDefault] = useState<boolean>(() => localStorage.getItem("bouh.follow_center") !== "false");

  useEffect(() => {
    getLocalGroundGridStatus()
      .then((status) => setMessage(`BOUH Radar جاهز · ${status.ground_cells} خلية محلية`))
      .catch(() => setMessage("تعذر تحميل طبقة البيانات المحلية."));
  }, []);

  return (
    <main className="app-shell operational-shell radar-only-shell" dir="rtl">
      <header className="operational-topbar radar-only-topbar">
        <div className="brand">
          <div className="brand-mark bouh-icon-mini" aria-hidden="true" />
          <div>
            <h1>BOUH Radar</h1>
            <p>رادار التحليل الميداني · Offline-first</p>
          </div>
        </div>
        <button className="local-pill" type="button" onClick={() => setDefaultRadius(nextRadius(defaultRadius))}>{defaultRadius}m</button>
      </header>

      <div className="status-line compact-status">{message}</div>

      {screen === "radar" && (
        <RadarPage
          lat={lat}
          lng={lng}
          defaultRadius={defaultRadius}
          defaultFollowCenter={followCenterDefault}
          onCoords={(nextLat, nextLng) => {
            setLat(nextLat);
            setLng(nextLng);
          }}
          onMessage={setMessage}
        />
      )}

      {screen === "reports" && <ReportPage onMessage={setMessage} />}
      {screen === "library" && <LibraryPage currentLat={lat} currentLng={lng} onMessage={setMessage} />}

      <nav className="bottom-nav operational-bottom-nav radar-only-nav" aria-label="أقسام BOUH Radar">
        {navItems.map((item) => (
          <button key={item.id} type="button" className={screen === item.id ? "active" : ""} onClick={() => setScreen(item.id)}>
            <span>{item.icon}</span>
            <small>{item.label}</small>
          </button>
        ))}
      </nav>
    </main>
  );
}

function nextRadius(radius: number) {
  const options = [100, 300, 500, 1000];
  const current = options.indexOf(radius);
  const next = options[(current + 1) % options.length];
  localStorage.setItem("bouh.default_radius", String(next));
  return next;
}
