import { describe, expect, it } from "vitest";
import { buildBoundsFromRadius, lngLatToTile } from "./offlineTileMath";

describe("offline tile math", () => {
  it("builds a valid radius bbox", () => {
    const bounds = buildBoundsFromRadius(24.7, 46.6, 1000);
    expect(bounds.west).toBeLessThan(46.6);
    expect(bounds.east).toBeGreaterThan(46.6);
    expect(bounds.south).toBeLessThan(24.7);
    expect(bounds.north).toBeGreaterThan(24.7);
  });

  it("converts lng lat to web mercator tile", () => {
    const tile = lngLatToTile(0, 0, 1);
    expect(tile.x).toBe(1);
    expect(tile.y).toBe(1);
  });
});
