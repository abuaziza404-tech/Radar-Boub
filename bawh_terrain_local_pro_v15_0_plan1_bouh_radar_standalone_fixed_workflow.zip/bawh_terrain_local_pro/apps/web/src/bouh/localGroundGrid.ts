export type LocalGroundCell = {
  cell_id: string;
  latitude: number;
  longitude: number;
  final_ground_score: number | null;
  class: string;
  evidence_count: number | null;
  truth_status: string;
  limitation_ar: string;
  refl_brightness: number | null;
  refl_red_green_proxy: number | null;
  tir_brightness: number | null;
  dem_elevation: number | null;
  slope_proxy: number | null;
  terrain_score: number | null;
  alteration_proxy_score: number | null;
  dryness_exposure_score: number | null;
  structure_score: number | null;
};

export type LocalGroundGridPayload = {
  ok: boolean;
  dataset: string;
  version: string;
  ground_cells: number;
  truth_status: string;
  cells: LocalGroundCell[];
};

export type LocalGroundScoreResult = {
  ok: boolean;
  mode: "ground_grid" | "no_data";
  source: "local_ground_grid";
  lat: number;
  lng: number;
  radius: number;
  truth_status: string;
  limitation_ar: string;
  result?: LocalGroundCell & { distance_m: number };
};

let cachedGrid: LocalGroundGridPayload | null = null;
let loadingGrid: Promise<LocalGroundGridPayload> | null = null;

const GRID_URL = "/data/bouh_ground_grid_compact.json";
const EXPECTED_CELLS = 4303;
const EXPECTED_TRUTH = "partial_raw_grid_landsat_dem_not_full_spectral";

export async function loadLocalGroundGrid(): Promise<LocalGroundGridPayload> {
  if (cachedGrid) return cachedGrid;
  if (loadingGrid) return loadingGrid;

  loadingGrid = fetch(GRID_URL, { cache: "force-cache" })
    .then(async (response) => {
      if (!response.ok) {
        throw new Error(`Local ground grid unavailable: HTTP ${response.status}`);
      }

      const payload = (await response.json()) as LocalGroundGridPayload;

      if (!payload?.cells || !Array.isArray(payload.cells)) {
        throw new Error("Invalid local ground grid payload.");
      }

      if (payload.cells.length !== EXPECTED_CELLS || payload.ground_cells !== EXPECTED_CELLS) {
        throw new Error(`Local ground grid count mismatch: ${payload.cells.length}`);
      }

      if (payload.truth_status !== EXPECTED_TRUTH) {
        throw new Error(`Local ground grid truth_status mismatch: ${payload.truth_status}`);
      }

      cachedGrid = payload;
      return payload;
    })
    .finally(() => {
      loadingGrid = null;
    });

  return loadingGrid;
}

export async function calculateLocalGroundScore(lat: number, lng: number, radius: number): Promise<LocalGroundScoreResult> {
  const grid = await loadLocalGroundGrid();
  return calculateLocalGroundScoreFromCells(grid.cells, lat, lng, radius, grid.truth_status);
}

export function calculateLocalGroundScoreFromCells(
  cells: LocalGroundCell[],
  lat: number,
  lng: number,
  radius: number,
  truthStatus = EXPECTED_TRUTH
): LocalGroundScoreResult {
  let nearest: (LocalGroundCell & { distance_m: number }) | null = null;

  for (const cell of cells) {
    const distance = haversineMeters(lat, lng, cell.latitude, cell.longitude);
    if (!nearest || distance < nearest.distance_m) {
      nearest = { ...cell, distance_m: distance };
    }
  }

  if (!nearest || nearest.distance_m > radius) {
    return {
      ok: true,
      mode: "no_data",
      source: "local_ground_grid",
      lat,
      lng,
      radius,
      truth_status: truthStatus,
      limitation_ar: "لا توجد خلية تحليل قريبة ضمن النطاق المحدد. حرّك الخريطة أو زد نصف القطر.",
    };
  }

  return {
    ok: true,
    mode: "ground_grid",
    source: "local_ground_grid",
    lat,
    lng,
    radius,
    truth_status: nearest.truth_status,
    limitation_ar: nearest.limitation_ar,
    result: nearest,
  };
}

export async function getLocalGroundGridStatus() {
  const grid = await loadLocalGroundGrid();
  const lats = grid.cells.map((cell) => cell.latitude);
  const lngs = grid.cells.map((cell) => cell.longitude);

  return {
    ok: true,
    ground_cells: grid.cells.length,
    truth_status: grid.truth_status,
    min_lat: Math.min(...lats),
    max_lat: Math.max(...lats),
    min_lng: Math.min(...lngs),
    max_lng: Math.max(...lngs),
  };
}

export async function calculateNearestForLibrarySample() {
  const grid = await loadLocalGroundGrid();
  const best = grid.cells.reduce((top, cell) => {
    const topScore = typeof top.final_ground_score === "number" ? top.final_ground_score : -Infinity;
    const cellScore = typeof cell.final_ground_score === "number" ? cell.final_ground_score : -Infinity;
    return cellScore > topScore ? cell : top;
  }, grid.cells[0]);

  return calculateLocalGroundScore(best.latitude, best.longitude, 300);
}

export function persistLocalGroundReading(reading: LocalGroundScoreResult) {
  const stored = {
    ...reading,
    saved_at: new Date().toISOString(),
  };
  localStorage.setItem("bouh.last_live_ground_score", JSON.stringify(stored));
  window.dispatchEvent(new CustomEvent("bouh:last-live-score", { detail: stored }));
}

export function readLastLocalGroundReading(): LocalGroundScoreResult | null {
  try {
    const raw = localStorage.getItem("bouh.last_live_ground_score");
    return raw ? (JSON.parse(raw) as LocalGroundScoreResult) : null;
  } catch {
    return null;
  }
}

function haversineMeters(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const earthRadius = 6371008.8;
  const phi1 = toRadians(lat1);
  const phi2 = toRadians(lat2);
  const deltaPhi = toRadians(lat2 - lat1);
  const deltaLambda = toRadians(lng2 - lng1);

  const a = Math.sin(deltaPhi / 2) ** 2
    + Math.cos(phi1) * Math.cos(phi2) * Math.sin(deltaLambda / 2) ** 2;

  return 2 * earthRadius * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function toRadians(value: number): number {
  return (value * Math.PI) / 180;
}


export function deriveOperationalIndicators(reading: LocalGroundScoreResult | null) {
  const result = reading?.result;
  const score = typeof result?.final_ground_score === "number" ? result.final_ground_score : 0;
  const terrain = typeof result?.terrain_score === "number" ? result.terrain_score : 0;
  const alteration = typeof result?.alteration_proxy_score === "number" ? result.alteration_proxy_score : 0;
  const dryness = typeof result?.dryness_exposure_score === "number" ? result.dryness_exposure_score : 0;
  const structure = typeof result?.structure_score === "number" ? result.structure_score : 0;

  return {
    radarScore: clampRound(score),
    terrainSignal: clampRound(terrain),
    spectralSignal: clampRound(alteration),
    thermalSignal: clampRound(dryness),
    structureSignal: clampRound(structure),
    confidence: clampRound((score * 0.55) + ((result?.evidence_count ?? 0) * 7.5)),
    priorityLabel: result?.class ?? "No Data",
  };
}

function clampRound(value: number): number {
  if (!Number.isFinite(value)) return 0;
  return Math.max(0, Math.min(100, Math.round(value)));
}
