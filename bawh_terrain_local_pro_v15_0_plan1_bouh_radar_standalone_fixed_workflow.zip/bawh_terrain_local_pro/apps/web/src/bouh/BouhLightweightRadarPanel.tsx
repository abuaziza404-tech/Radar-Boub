import React, { useEffect, useState } from "react";
import { getBouhRadarBootstrap } from "./api";
import type { BouhRadarBootstrap, BouhScreeningPoint, BouhTarget } from "./types";

type Props = {
  onMessage: (message: string) => void;
  onFlyTo?: (lat: number, lng: number, label: string) => void;
};

export default function BouhLightweightRadarPanel({ onMessage, onFlyTo }: Props) {
  const [data, setData] = useState<BouhRadarBootstrap | null>(null);

  useEffect(() => {
    load();
  }, []);

  async function load() {
    try {
      const payload = await getBouhRadarBootstrap();
      setData(payload);
      onMessage(`تم تحميل بيانات بوح الخفيفة: ${payload.official_targets.length} أهداف رسمية و${payload.regional_zones.length} نطاقات.`);
    } catch (error) {
      onMessage(error instanceof Error ? error.message : "فشل تحميل بيانات بوح.");
    }
  }

  if (!data) {
    return <section className="bouh-panel" data-testid="bouh-lightweight-radar-panel">جاري تحميل بيانات بوح...</section>;
  }

  return (
    <section className="bouh-panel" data-testid="bouh-lightweight-radar-panel">
      <header>
        <h3>بيانات بوح الجذرية الخفيفة</h3>
        <p>{data.heavy_data_policy}</p>
      </header>

      <div className="bouh-warning">
        هذه النقاط للفحص الميداني والدعم النسبي فقط، وليست إثبات ذهب أو دفائن.
      </div>

      <h4>الممر الإقليمي</h4>
      <div className="bouh-zone-grid">
        {data.regional_zones.map((zone) => (
          <article key={zone.role} className={zone.role === "regional_center" ? "active" : ""}>
            <strong>{zone.label_ar}</strong>
            <small>{zone.source_zip}</small>
            <p>{zone.priority_note_ar ?? zone.analysis_use}</p>
          </article>
        ))}
      </div>

      <h4>الأهداف الرسمية Field-check</h4>
      <div className="bouh-list">
        {data.official_targets.map((target) => (
          <TargetRow key={target.target_id} target={target} onFlyTo={onFlyTo} />
        ))}
      </div>

      <h4>أفضل نقاط الدعم النسبي</h4>
      <div className="bouh-list">
        {data.screening_points.universal_top10.slice(0, 5).map((point) => (
          <PointRow key={`u-${point.rank}`} point={point} onFlyTo={onFlyTo} />
        ))}
      </div>
    </section>
  );
}

function TargetRow({ target, onFlyTo }: { target: BouhTarget; onFlyTo?: Props["onFlyTo"] }) {
  return (
    <button type="button" onClick={() => onFlyTo?.(target.latitude, target.longitude, target.name)}>
      <strong>{target.target_id} — {target.name}</strong>
      <span>{target.final_status}</span>
      <small>{target.proof_status}</small>
      <em>{target.source} · {target.truth_status}</em>
      <em>{target.limitation_ar}</em>
    </button>
  );
}

function PointRow({ point, onFlyTo }: { point: BouhScreeningPoint; onFlyTo?: Props["onFlyTo"] }) {
  const score = point.score ?? point.score_relative;
  return (
    <button type="button" onClick={() => onFlyTo?.(point.latitude, point.longitude, `Relative point #${point.rank}`)}>
      <strong>#{point.rank} — {score?.toFixed(3) ?? "—"}</strong>
      <span>{point.latitude.toFixed(4)}, {point.longitude.toFixed(4)}</span>
      <small>{point.truth_status}</small>
      <em>{point.source} · {point.evidence_class}</em>
      <em>{point.limitation_ar}</em>
    </button>
  );
}
