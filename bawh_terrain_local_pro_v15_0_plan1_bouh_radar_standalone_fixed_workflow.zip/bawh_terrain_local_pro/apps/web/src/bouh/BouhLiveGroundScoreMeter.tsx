import React, { useEffect, useState } from "react";
import {
  LocalGroundScoreResult,
  calculateLocalGroundScore,
  persistLocalGroundReading
} from "./localGroundGrid";

export default function BouhLiveGroundScoreMeter({
  lat,
  lng,
  radius,
}: {
  lat: number;
  lng: number;
  radius: number;
}) {
  const [data, setData] = useState<LocalGroundScoreResult | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    let cancelled = false;

    async function run() {
      setLoading(true);
      try {
        const payload = await calculateLocalGroundScore(lat, lng, radius);
        if (!cancelled) {
          setData(payload);
          persistLocalGroundReading(payload);
        }
      } catch {
        if (!cancelled) {
          const payload: LocalGroundScoreResult = {
            ok: true,
            mode: "no_data",
            source: "local_ground_grid",
            lat,
            lng,
            radius,
            truth_status: "partial_raw_grid_landsat_dem_not_full_spectral",
            limitation_ar: "تعذر تحميل طبقة البيانات المحلية داخل الواجهة. أعد فتح التطبيق أو حدّث الحزمة.",
          };
          setData(payload);
          persistLocalGroundReading(payload);
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    }

    if (Number.isFinite(lat) && Number.isFinite(lng)) run();
    return () => { cancelled = true; };
  }, [lat, lng, radius]);

  const score = data?.result?.final_ground_score;
  const className = data?.result?.class ?? "No Data";
  const mode = data?.mode ?? "no_data";
  const truth = data?.truth_status ?? "partial_raw_grid_landsat_dem_not_full_spectral";
  const limitation = data?.limitation_ar ?? "تحليل سطحي يحتاج فحصًا ميدانيًا.";
  const statusClass = mode === "ground_grid" ? "ground" : "nodata";

  return (
    <section className={`bouh-live-meter pro operational ${statusClass}`}>
      <header>
        <div>
          <span>Local Ground Score</span>
          <strong>درجة الأرض المحلية</strong>
        </div>
        <small>{loading ? "جاري الحساب..." : mode}</small>
      </header>

      <div className="score-summary">
        <div className="meter-value">{typeof score === "number" ? score.toFixed(1) : "—"}</div>
        <div>
          <b className={className === "Reject" ? "reject-class" : ""}>{className}</b>
          <span>mode: {mode}</span>
          <span>source: local ground grid</span>
        </div>
      </div>

      <div className="coord-box">
        <span>Lat</span>
        <strong dir="ltr">{lat.toFixed(6)}</strong>
        <span>Lng</span>
        <strong dir="ltr">{lng.toFixed(6)}</strong>
      </div>

      <div className="score-facts">
        <Fact label="evidence_count" value={data?.result?.evidence_count ?? "—"} />
        <Fact label="truth_status" value={truth} />
        <Fact label="distance" value={typeof data?.result?.distance_m === "number" ? `${data.result.distance_m.toFixed(1)} m` : "—"} />
      </div>

      <p className="meter-note">{limitation}</p>

      <details className="indicator-details">
        <summary>تفاصيل المؤشرات</summary>
        <div className="meter-grid">
          <Metric label="refl_brightness" value={data?.result?.refl_brightness} />
          <Metric label="refl_red_green_proxy" value={data?.result?.refl_red_green_proxy} />
          <Metric label="tir_brightness" value={data?.result?.tir_brightness} />
          <Metric label="dem_elevation" value={data?.result?.dem_elevation} />
          <Metric label="slope_proxy" value={data?.result?.slope_proxy} />
          <Metric label="terrain_score" value={data?.result?.terrain_score} />
          <Metric label="alteration_proxy_score" value={data?.result?.alteration_proxy_score} />
          <Metric label="dryness_exposure_score" value={data?.result?.dryness_exposure_score} />
          <Metric label="structure_score" value={data?.result?.structure_score} />
        </div>
      </details>

      <div className="truth-policy">
        partial ready analyzed ground grid from Landsat/DEM · No Gold Proof · No Depth · No 100% · Surface Screening · Field-check
      </div>
    </section>
  );
}

function Fact({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div>
      <span>{label}</span>
      <strong>{value}</strong>
    </div>
  );
}

function Metric({ label, value }: { label: string; value: unknown }) {
  return (
    <span>
      <b>{label}</b>
      <em>{typeof value === "number" ? value.toFixed(3) : "—"}</em>
    </span>
  );
}
