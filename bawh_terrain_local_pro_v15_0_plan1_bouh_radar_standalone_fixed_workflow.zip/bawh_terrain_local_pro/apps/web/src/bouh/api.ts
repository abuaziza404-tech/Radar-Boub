import type { BouhRadarBootstrap } from "./types";

const API_BASE = import.meta.env.VITE_API_BASE ?? "http://localhost:8000";
const BOUH_RADAR_BOOTSTRAP_CACHE_KEY = "bouh.radar.bootstrap.v12_1.cache";

export async function getBouhRadarBootstrap(): Promise<BouhRadarBootstrap> {
  try {
    const response = await fetch(`${API_BASE}/bouh/radar/bootstrap`, {
      headers: { "Accept": "application/json" }
    });

    if (!response.ok) {
      throw new Error("فشل تحميل بيانات بوح الخفيفة للرادار من API");
    }

    const payload = await response.json() as BouhRadarBootstrap;
    localStorage.setItem(BOUH_RADAR_BOOTSTRAP_CACHE_KEY, JSON.stringify({
      cached_at: new Date().toISOString(),
      payload
    }));
    return payload;
  } catch (error) {
    const cached = localStorage.getItem(BOUH_RADAR_BOOTSTRAP_CACHE_KEY);

    if (cached) {
      const parsed = JSON.parse(cached) as { cached_at: string; payload: BouhRadarBootstrap };
      return {
        ...parsed.payload,
        heavy_data_policy: `${parsed.payload.heavy_data_policy} — تم التحميل من آخر cache محلي بتاريخ ${parsed.cached_at}.`
      };
    }

    throw new Error("فشل تحميل /bouh/radar/bootstrap ولا يوجد cache محلي سابق.");
  }
}

export async function getBouhImportStatus(): Promise<unknown> {
  const response = await fetch(`${API_BASE}/bouh/imports/status`);
  if (!response.ok) {
    throw new Error("فشل تحميل حالة imports");
  }
  return response.json();
}
