export type TruthStatus =
  | "field_check_only"
  | "relative_support_only"
  | "relative_sentinel_support_only"
  | "metadata_until_import"
  | string;

export type BouhRegionalZone = {
  role: string;
  label_ar: string;
  source_zip: string;
  drive_url?: string;
  visual_folder?: string;
  status: string;
  analysis_use: string;
  truth_status: TruthStatus;
  can_render_on_radar: boolean;
  can_calculate_new_pixels_without_import: boolean;
  priority_note_ar?: string;
};

export type BouhTarget = {
  target_id: string;
  name: string;
  latitude: number;
  longitude: number;
  model_type: string;
  final_status: string;
  proof_status: string;
  radar_layer: string;
  priority_class: string;
  source: string;
  evidence_class: string;
  truth_status: TruthStatus;
  limitation_ar: string;
  calculation_allowed: boolean;
};

export type BouhScreeningPoint = {
  rank: number;
  latitude: number;
  longitude: number;
  score?: number;
  score_relative?: number;
  evidence_count?: number;
  NDVI?: number;
  IRON_B04_B02?: number;
  SWIR_B11_B12?: number;
  truth_status: TruthStatus;
  source: string;
  evidence_class: string;
  limitation_ar: string;
  calculation_allowed: boolean;
  proof_status: string;
};

export type BouhRadarBootstrap = {
  ok: boolean;
  pack_name: string;
  pack_version: string;
  truth_policy: Record<string, unknown>;
  regional_zones: BouhRegionalZone[];
  official_targets: BouhTarget[];
  screening_points: {
    universal_top10: BouhScreeningPoint[];
    sentinel2_top10: BouhScreeningPoint[];
  };
  universal_summary: Record<string, unknown>;
  data_definitions: Record<string, unknown>;
  heavy_data_policy: string;
};
