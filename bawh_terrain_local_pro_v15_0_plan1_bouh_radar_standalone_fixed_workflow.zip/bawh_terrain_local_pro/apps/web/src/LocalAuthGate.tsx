import React, { useEffect, useState } from "react";

const PIN_HASH_KEY = "bawh.pin.sha256.v1";
const PIN_ENABLED_KEY = "bawh.pin.enabled.v1";
const WEBAUTHN_ENABLED_KEY = "bawh.webauthn.enabled.v1";
const WEBAUTHN_CREDENTIAL_KEY = "bawh.webauthn.credential.v1";

export default function LocalAuthGate({
  children,
  onMessage
}: {
  children: React.ReactNode;
  onMessage: (message: string) => void;
}) {
  const [isUnlocked, setIsUnlocked] = useState(false);
  const [pinEnabled, setPinEnabled] = useState(false);
  const [pin, setPin] = useState("");
  const [newPin, setNewPin] = useState("");
  const [mode, setMode] = useState<"unlock" | "setup">("unlock");

  useEffect(() => {
    const enabled = localStorage.getItem(PIN_ENABLED_KEY) === "true";
    setPinEnabled(enabled);
    setIsUnlocked(!enabled);
    setMode(enabled ? "unlock" : "setup");
  }, []);

  async function setupPin() {
    if (!/^\d{4,8}$/.test(newPin)) {
      onMessage("PIN يجب أن يكون من 4 إلى 8 أرقام.");
      return;
    }

    const hash = await sha256(newPin);
    localStorage.setItem(PIN_HASH_KEY, hash);
    localStorage.setItem(PIN_ENABLED_KEY, "true");
    setPinEnabled(true);
    setIsUnlocked(true);
    setNewPin("");
    onMessage("تم تفعيل قفل PIN المحلي.");
  }

  async function unlockWithPin() {
    const stored = localStorage.getItem(PIN_HASH_KEY);

    if (!stored) {
      setMode("setup");
      return;
    }

    const hash = await sha256(pin);

    if (hash === stored) {
      setIsUnlocked(true);
      setPin("");
      onMessage("تم فتح التطبيق.");
    } else {
      onMessage("PIN غير صحيح.");
    }
  }

  async function setupBiometric() {
    if (!window.PublicKeyCredential) {
      onMessage("المتصفح لا يدعم WebAuthn/Biometrics.");
      return;
    }

    try {
      const challenge = crypto.getRandomValues(new Uint8Array(32));
      const userId = crypto.getRandomValues(new Uint8Array(16));
      const credential = await navigator.credentials.create({
        publicKey: {
          challenge,
          rp: { name: "بوح التضاريس" },
          user: {
            id: userId,
            name: "bawh-local-user",
            displayName: "Bawh Local User"
          },
          pubKeyCredParams: [
            { type: "public-key", alg: -7 },
            { type: "public-key", alg: -257 }
          ],
          authenticatorSelection: {
            authenticatorAttachment: "platform",
            userVerification: "preferred"
          },
          timeout: 60000,
          attestation: "none"
        }
      }) as PublicKeyCredential | null;

      if (!credential) {
        onMessage("لم يتم إنشاء اعتماد بصمة.");
        return;
      }

      localStorage.setItem(WEBAUTHN_CREDENTIAL_KEY, arrayBufferToBase64Url(credential.rawId));
      localStorage.setItem(WEBAUTHN_ENABLED_KEY, "true");
      onMessage("تم تفعيل بصمة/قفل الجهاز كخيار فتح محلي.");
    } catch {
      onMessage("تعذر تفعيل البصمة. استخدم PIN المحلي.");
    }
  }

  async function unlockWithBiometric() {
    const credentialId = localStorage.getItem(WEBAUTHN_CREDENTIAL_KEY);

    if (!credentialId || !window.PublicKeyCredential) {
      onMessage("لم يتم إعداد البصمة بعد.");
      return;
    }

    try {
      const challenge = crypto.getRandomValues(new Uint8Array(32));
      const rawId = base64UrlToArrayBuffer(credentialId);

      const assertion = await navigator.credentials.get({
        publicKey: {
          challenge,
          allowCredentials: [
            {
              type: "public-key",
              id: rawId
            }
          ],
          userVerification: "preferred",
          timeout: 60000
        }
      });

      if (assertion) {
        setIsUnlocked(true);
        onMessage("تم فتح التطبيق بالبصمة/قفل الجهاز.");
      }
    } catch {
      onMessage("فشل فتح البصمة.");
    }
  }

  function disableLock() {
    localStorage.removeItem(PIN_HASH_KEY);
    localStorage.removeItem(PIN_ENABLED_KEY);
    localStorage.removeItem(WEBAUTHN_ENABLED_KEY);
    localStorage.removeItem(WEBAUTHN_CREDENTIAL_KEY);
    setPinEnabled(false);
    setIsUnlocked(true);
    onMessage("تم تعطيل القفل المحلي.");
  }

  if (isUnlocked) {
    return (
      <>
        {children}
        <button type="button" className="local-lock-button" onClick={() => setIsUnlocked(false)}>
          قفل
        </button>
      </>
    );
  }

  return (
    <main className="local-auth-shell" dir="rtl">
      <section className="local-auth-card">
        <div className="brand-mark auth-mark" />
        <span>بوح التضاريس</span>
        <h1>{mode === "setup" ? "إعداد قفل محلي" : "فتح التطبيق"}</h1>
        <p>
          القفل محلي على الجهاز فقط. لا يتم إرسال PIN إلى الخادم. يمكن إضافة بصمة/قفل الجهاز عند دعم المتصفح.
        </p>

        {mode === "setup" && (
          <>
            <input
              type="password"
              inputMode="numeric"
              pattern="[0-9]*"
              maxLength={8}
              placeholder="PIN من 4 إلى 8 أرقام"
              value={newPin}
              onChange={(event) => setNewPin(event.target.value)}
            />
            <button className="primary" type="button" onClick={setupPin}>تفعيل PIN</button>
            <button className="secondary" type="button" onClick={setupBiometric}>تفعيل البصمة</button>
            <button className="secondary" type="button" onClick={() => setIsUnlocked(true)}>تخطي الآن</button>
          </>
        )}

        {mode === "unlock" && pinEnabled && (
          <>
            <input
              type="password"
              inputMode="numeric"
              pattern="[0-9]*"
              maxLength={8}
              placeholder="أدخل PIN"
              value={pin}
              onChange={(event) => setPin(event.target.value)}
              onKeyDown={(event) => {
                if (event.key === "Enter") {
                  unlockWithPin();
                }
              }}
            />
            <button className="primary" type="button" onClick={unlockWithPin}>فتح PIN</button>
            {localStorage.getItem(WEBAUTHN_ENABLED_KEY) === "true" && (
              <button className="secondary" type="button" onClick={unlockWithBiometric}>فتح بالبصمة</button>
            )}
            <button className="secondary danger" type="button" onClick={disableLock}>تعطيل القفل المحلي</button>
          </>
        )}
      </section>
    </main>
  );
}

async function sha256(value: string) {
  const data = new TextEncoder().encode(value);
  const digest = await crypto.subtle.digest("SHA-256", data);
  return arrayBufferToBase64Url(digest);
}

function arrayBufferToBase64Url(buffer: ArrayBuffer) {
  const bytes = new Uint8Array(buffer);
  let binary = "";

  for (const byte of bytes) {
    binary += String.fromCharCode(byte);
  }

  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}

function base64UrlToArrayBuffer(value: string) {
  const padded = value.replace(/-/g, "+").replace(/_/g, "/") + "===".slice((value.length + 3) % 4);
  const binary = atob(padded);
  const bytes = new Uint8Array(binary.length);

  for (let index = 0; index < binary.length; index += 1) {
    bytes[index] = binary.charCodeAt(index);
  }

  return bytes.buffer;
}
