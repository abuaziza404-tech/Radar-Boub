import React from "react";

export default function PWAInstallPrompt({ onMessage }: { onMessage: (message: string) => void }) {
  React.useEffect(() => {
    onMessage("واجهة Android تعمل بوضع ميداني محلي.");
  }, [onMessage]);

  return null;
}
