import React, { useState } from "react";
import { getLocalGroundGridStatus } from "./bouh/localGroundGrid";

export default function SecurityPage({
  defaultRadius,
  defaultLayer,
  followCenterDefault,
  onDefaultRadiusChange,
  onDefaultLayerChange,
  onFollowCenterChange,
  onMessage
}: {
  defaultRadius: number;
  defaultLayer: string;
  followCenterDefault: boolean;
  onDefaultRadiusChange: (value: number) => void;
  onDefaultLayerChange: (value: string) => void;
  onFollowCenterChange: (value: boolean) => void;
  onMessage: (message: string) => void;
}) {
  const [status, setStatus] = useState<string>("v14.1 professional operational suite");

  async function showStatus() {
    const grid = await getLocalGroundGridStatus();
    setStatus(`v14.1 · ${grid.ground_cells} cells · ${grid.truth_status} · local operational suite`);
    onMessage("تم عرض حالة التطبيق.");
  }

  function clearLocalCache() {
    localStorage.removeItem("bouh.last_live_ground_score");
    onMessage("تم مسح آخر قراءة محلية من cache.");
  }

  return (
    <section className="screen concise-page operational-settings">
      <article className="hero-card compact clean-card">
        <span className="eyebrow">الإعدادات</span>
        <h2>إعدادات التشغيل المحلي</h2>
        <p>تحكم في تجربة الرادار داخل APK دون الاعتماد على API خارجي.</p>
      </article>

      <article className="panel clean-card settings-panel">
        <label>
          <span>radius الافتراضي</span>
          <select value={defaultRadius} onChange={(event) => onDefaultRadiusChange(Number(event.target.value))}>
            <option value={100}>100m</option>
            <option value={300}>300m</option>
            <option value={500}>500m</option>
            <option value={1000}>1000m</option>
          </select>
        </label>

        <label>
          <span>الطبقة الافتراضية</span>
          <select value={defaultLayer} onChange={(event) => onDefaultLayerChange(event.target.value)}>
            <option value="esri">Esri</option>
            <option value="hybrid">Hybrid</option>
            <option value="streets">Streets</option>
          </select>
        </label>

        <label className="switch-row">
          <span>تتبع مركز الخريطة</span>
          <input type="checkbox" checked={followCenterDefault} onChange={(event) => onFollowCenterChange(event.target.checked)} />
        </label>
      </article>

      <div className="action-row">
        <button className="secondary" type="button" onClick={clearLocalCache}>مسح cache المحلي</button>
        <button className="primary" type="button" onClick={showStatus}>عرض حالة التطبيق</button>
      </div>

      <article className="panel clean-card">
        <h3>نسخة التطبيق</h3>
        <p dir="ltr">{status}</p>
      </article>
    </section>
  );
}
