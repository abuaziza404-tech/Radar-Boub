# BOUH v12.5 Analytical Authority Ground Grid Pack

هذه الحزمة هي حزمة التحليل التي يجب أن يأخذها المطور كما هي.

## الهدف
تحويل الرادار من:
خريطة + نقاط
إلى:
Live Ground Score عند تحريك الدبوس

## أهم الملفات
- `configs/ground_score_model_v12_5.json`
- `data/precomputed/bouh_seed_cells_v12_5.sqlite`
- `scripts/build_bouh_ground_grid.py`
- `apps/api/app/bouh_core/live_score_repository.py`
- `apps/web/src/bouh/BouhLiveGroundScoreMeter.tsx`
- `docs/GRIMOIRE_V12_5_GROUND_GRID_PROMPT.md`

## تشغيل التحقق
```bash
python scripts/validate_v12_5_analytical_pack.py
pytest tests/test_live_score_repository.py
```

## ملاحظة حاسمة
هذه الحزمة لا تدّعي أنها استخرجت كل البيكسلات الخام من Drive داخل هذه الجلسة.
هي تضع منطق التحليل الرسمي، seed موثق، وسكربت بناء Ground Grid من الراسترات عند توفرها محليًا في data/imports.
