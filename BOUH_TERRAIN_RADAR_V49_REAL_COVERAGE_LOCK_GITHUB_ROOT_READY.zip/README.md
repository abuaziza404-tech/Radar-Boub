# بوح التضاريس V49 Live Field Refined

هذه الحزمة جاهزة للرفع إلى GitHub Actions وبناء APK مباشرة.

## أهم تطويرات V49
- رفع الإصدار الداخلي إلى `versionCode 44` و `versionName 45.0.0-alpine-command-interface`.
- تثبيت اسم التطبيق الظاهر بعد التثبيت: **بوح التضاريس**.
- تحديث GitHub Actions ليبحث عن حزمة V49 فقط ويعرض اسم V49 في صفحة Actions.
- إضافة فحص جاهزية الميدان V49:
  - GPS
  - قاعدة البيانات
  - الإنترنت / Offline
  - الأهداف المحفوظة
  - نقاط المسار
  - حالة التصدير
- إضافة خطة مهمة ذكية V49 ترتب الأهداف حسب الدرجة ثم القرب.
- إضافة خريطة حرارية Heatmap للنتائج من قاعدة الخلايا.
- إضافة تقرير HTML احترافي قابل للمشاركة بجانب JSON/CSV/KML/GPX/GeoJSON.
- تحسين رسائل الواجهة لتعرض V49 Live Field Refined.
- الحفاظ على بنية WebView + Android Bridge الحالية لتثبيت التطوير بسرعة دون كسر النظام.

## طريقة الرفع إلى GitHub
1. ارفع هذا الملف في جذر المستودع:
   `BOUH_TERRAIN_RADAR_V49_PRO_FIELD_INTELLIGENCE_GITHUB_ROOT_READY.zip`
2. أنشئ الملف:
   `.github/workflows/build-apk.yml`
3. استخدم ملف workflow الموجود داخل الحزمة أو انسخ محتواه من `.github/workflows/build-apk.yml`.
4. ادخل تبويب Actions وشغل:
   `Build BOUH Terrain Radar V49 APK`

## ملاحظة
`applicationId` بقي كما هو `com.bouh.terrainradar.v41` حتى يمكن تثبيت V49 كتحديث فوق النسخ السابقة. الاسم الظاهر للمستخدم هو **بوح التضاريس**.

## V49 Live Field Refined
- تطبيق الواجهة المطلوبة بصرياً: بطاقة إحداثيات علوية، شريحة هوية بوح التضاريس، رادار ثلاثي الحلقات، ملخص رادار دائم، وشريط أوامر سفلي عربي.
- تحديث حي للـ Score / Structure / Alteration / FeOx / Drainage من قاعدة البيانات.
- HUD ميداني: UTM تقريبي، ارتفاع، دقة GPS، وحالة Online/Offline.
- الإبقاء على أنظمة الأهداف والمسارات والتصدير والتقارير وHeatmap وKML/GPX/CSV/GeoJSON/HTML.


## V49 Live Field Refined
- Compact coordinate header and raised placement.
- Smaller radar summary with live score/meta updates while moving the map.
- Polished footer with developer signature.
- Security and field readiness notes added in docs/V49_LIVE_FIELD_REFINED_SECURITY.md.


## V49 Target Range Header
- عرض النطاق المستهدف داخل بطاقة الإحداثيات العلوية.
- إزاحة شريحة اسم التطبيق عن الإحداثيات.
- تقليل حجم عناصر الواجهة وتحسين ترتيبها.


## V49 Real Coverage Lock
- قفل التحليل خارج التغطية الحقيقية.
- تصغير دائرة الرادار وتحسين السلاسة.
- إضافة طبقة حدود التغطية الحقيقية.
- زر انتقال إلى أقرب خلية تغطية.
