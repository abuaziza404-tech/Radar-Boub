# KNOWN_LIMITATIONS

## حدود الإصدار الحالي

1. لم يتم بناء APK داخل بيئة ChatGPT الحالية بسبب غياب Android SDK و Gradle المحلي.
2. الحزمة ملتزمة بسقف 25MB، لذلك تم حذف طبقات heatmap الإضافية من التسليم الحالي.
3. الخرائط الظاهرة مقتصرة على Satellite و Hybrid Map حسب طلب المستخدم.
4. API/AI الخارجي غير مفعل افتراضياً للحفاظ على التشغيل الأوفلاين وعدم تغيير قرار SQLite.
5. الرادار يعمل كـ Candidate & Field-check Engine ولا يثبت الذهب نهائياً.
6. لا يوجد Gold Confirmed أو Target-B إلا بدليل ميداني مثل GPZ/sample/assay/recovered_gold.
7. دقة المعاينة القريبة تعتمد على دقة البلاطات المتوفرة.
