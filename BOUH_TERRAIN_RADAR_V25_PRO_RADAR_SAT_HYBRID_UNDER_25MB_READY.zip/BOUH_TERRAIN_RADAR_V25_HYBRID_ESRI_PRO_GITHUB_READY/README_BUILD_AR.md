# README_BUILD_AR

## بوح التضاريس V25

تطبيق خرائط وملاحة ميداني أوفلاين مزود برادار استشعار جيولوجي لترشيح مؤشرات الذهب السطحي وشبه السطحي.

- اسم التطبيق: BOUH Terrain Radar V25 Hybrid Esri Pro
- الاسم العربي: بوح التضاريس V25
- Package: `com.bouh.terrainradar`
- المطور: أحمد أبوعزيزه الرشيدي
- Developer: Ahmed Abu Aziza Al-Rashidi

## نسخة أقل من 25MB

تم تجهيز هذه النسخة للالتزام بسقف 25MB.

## الخرائط
الخرائط الظاهرة في هذا الإصدار:
- Satellite
- Hybrid Map

لا توجد طبقات إضافية ظاهرة في واجهة الخريطة.

## الرادار
الرادار:
- يقرأ من قواعد SQLite الأصلية.
- لا يستخدم نتائج عشوائية.
- لا يستخدم `Math.random`.
- لا يثبت الذهب.
- يعمل كـ Candidate & Field-check Engine.

## البناء
```bash
chmod +x ./gradlew
./gradlew assembleDebug --no-daemon
```

المخرج المتوقع:
```text
app/build/outputs/apk/debug/app-debug.apk
```

## GitHub Actions
يوجد workflow جاهز في:
`.github/workflows/build-apk.yml`
