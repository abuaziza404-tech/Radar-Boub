# CHANGELOG_MANUS_V25

## V25 Pro Radar Satellite/Hybrid Under 25MB

- الالتزام بسقف 25MB لحزمة التسليم.
- إبقاء الخرائط الأساسية فقط: Satellite و Hybrid Map.
- إزالة MBTiles heatmap من الحزمة لأنها طبقات إضافية وليست مطلوبة في هذا الإصدار.
- حذف JSON الخام الكبير غير المستخدم في قرار الرادار.
- إبقاء قواعد SQLite الأصلية الثلاث.
- إبقاء BOUH Gold Terrain Radar Pro مربوطاً بالبيانات الأصلية.
- تحديث تقارير QA و Build و Known Limitations.
- تحديث MapServer status ليعرض Satellite/Hybrid فقط كخرائط مرئية.
