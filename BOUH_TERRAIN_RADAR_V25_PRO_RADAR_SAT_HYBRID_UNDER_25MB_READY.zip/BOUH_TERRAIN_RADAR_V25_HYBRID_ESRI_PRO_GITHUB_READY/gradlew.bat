@echo off
setlocal
set APP_HOME=%~dp0
where gradle >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  gradle %*
  exit /b %ERRORLEVEL%
)
echo Gradle is not installed on PATH.
echo Open this project in Android Studio or run GitHub Actions. The workflow installs Gradle 8.7 automatically.
exit /b 127
