# SIZE_BUDGET_25MB_REPORT

تاريخ التنفيذ: 2026-05-31 06:32:54

## الهدف
الالتزام بأن حزمة التسليم لا تتجاوز 25MB مع الحفاظ على الرادار الاحترافي وقواعد البيانات الأصلية الأساسية.

## النتيجة
- ZIP النهائي: `BOUH_TERRAIN_RADAR_V25_PRO_RADAR_SAT_HYBRID_UNDER_25MB_READY.zip`
- الحجم النهائي: 8.05 MB
- الحالة: مطابق لشرط أقل من 25MB

## ما تم الحفاظ عليه
- تطبيق Android كامل.
- Package name: `com.bouh.terrainradar`
- App label: `بوح التضاريس V25`
- Gradle launcher/wrapper files.
- GitHub Actions.
- WebView + MapServer.
- قواعد SQLite الأصلية:
  - `BOUH_V21_NORTH_MOBILE.db`
  - `BOUH_V21_CENTER_MOBILE.db`
  - `BOUH_V21_SOUTH_MOBILE.db`
- رادار BOUH Gold Terrain Radar Pro.
- Satellite و Hybrid Map فقط كخرائط أساسية ظاهرة.
- الأيقونة وواجهة البداية.
- ملفات QA والتوثيق.

## ما تم عزله/حذفه لتقليل الحجم
- ملف JSON خام قديم كبير غير مطلوب لتشغيل الرادار لأن القرار أصبح من SQLite.
- MBTiles heatmap لأنها طبقات إضافية، والمطلوب الحالي Satellite + Hybrid Map فقط.
- نسخة `assets/www/index.html` المكررة الكبيرة واستبدالها بملف تحويل صغير.
- أرشيف ملفات الإصدارات القديمة V13/V14/V15/V19/V20 غير المستخدمة تشغيلياً.

## سبب الحذف
الرادار الاحترافي لا يعتمد على هذه الملفات في القرار النهائي. القرار يقرأ من SQLite الأصلية فقط.

## ملاحظة APK
لم يتم بناء APK داخل بيئة ChatGPT الحالية لعدم توفر Android SDK/Gradle محلياً.
المشروع جاهز للبناء عبر GitHub Actions أو Android Studio.
