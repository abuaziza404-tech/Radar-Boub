package com.bouh.terrainradar;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.security.MessageDigest;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends Activity {
    private static final int REQ_LOCATION = 120;
    private WebView webView;
    private GeolocationPermissions.Callback geoCallback;
    private String geoOrigin;
    private MapServer mapServer;
    private RadarEngine radarEngine;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE);

        radarEngine = new RadarEngine(this);
        mapServer = new MapServer(this);
        mapServer.start();

        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setGeolocationEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);

        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");

        webView.setWebViewClient(new WebViewClient());

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                geoOrigin = origin;
                geoCallback = callback;

                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                        checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    callback.invoke(origin, true, false);
                } else {
                    requestPermissions(new String[]{
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION
                    }, REQ_LOCATION);
                }
            }

            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> request.grant(request.getResources()));
            }
        });

        webView.loadUrl("file:///android_asset/index.html");
    }

    public class AndroidBridge {
        @JavascriptInterface
        public String appInfo() {
            return "{\"version\":\"25.1.0-hybrid-esri-pro\",\"app_ar\":\"بوح التضاريس V25\",\"app_en\":\"BOUH Terrain Radar V25 Hybrid Esri Pro\",\"developer_ar\":\"أحمد أبوعزيزه الرشيدي\",\"developer_en\":\"Ahmed Abu Aziza Al-Rashidi\",\"offline\":true,\"decision_engine\":\"native_sqlite_only\",\"random\":false}";
        }

        @JavascriptInterface
        public String radarAnalyze(double lat, double lon) {
            return radarEngine.analyze(lat, lon);
        }

        @JavascriptInterface
        public String nearestTarget(double lat, double lon, double maxKm) {
            return radarEngine.nearestTarget(lat, lon, maxKm);
        }

        @JavascriptInterface
        public String professionalRadarAnalyze(double lat, double lon) {
            return radarEngine.professionalAnalyze(lat, lon);
        }

        @JavascriptInterface
        public String aiApiStatus() {
            return radarEngine.aiApiStatus();
        }

        @JavascriptInterface
        public String professionalRadarAnalyzeV2(double lat, double lon) {
            return radarEngine.professionalAnalyzeV2(lat, lon);
        }

        @JavascriptInterface
        public String aiAssistant(String question, double lat, double lon) {
            return radarEngine.aiAssistant(question, lat, lon);
        }

        @JavascriptInterface
        public String satelliteIntelligence(double lat, double lon) {
            return radarEngine.satelliteIntelligence(lat, lon);
        }

        @JavascriptInterface
        public String diagnostics() {
            return radarEngine.diagnostics(mapServer);
        }

        @JavascriptInterface
        public boolean saveTextFile(String fileName, String content) {
            try {
                String safe = fileName.replaceAll("[^a-zA-Z0-9_\\-.]", "_");
                File baseDir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                if (baseDir == null) baseDir = getFilesDir();
                File dir = new File(baseDir, "BOUH");
                if (!dir.exists()) dir.mkdirs();
                File out = new File(dir, safe);
                FileOutputStream fos = new FileOutputStream(out);
                fos.write(content.getBytes("UTF-8"));
                fos.flush();
                fos.close();
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "تم الحفظ داخل مجلد التطبيق Downloads/BOUH/" + safe, Toast.LENGTH_LONG).show());
                return true;
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "تعذر حفظ الملف: " + e.getMessage(), Toast.LENGTH_LONG).show());
                return false;
            }
        }
    }

    static class RadarEngine {
        private static final String[][] REGION_DBS = new String[][]{
                {"NORTH", "BOUH_V21_NORTH_MOBILE.db"},
                {"CENTER", "BOUH_V21_CENTER_MOBILE.db"},
                {"SOUTH", "BOUH_V21_SOUTH_MOBILE.db"}
        };

        private final Activity activity;
        private final Map<String, SQLiteDatabase> dbs = new LinkedHashMap<>();
        private final Map<String, JSONObject> regions = new LinkedHashMap<>();
        private String lastError = "";

        RadarEngine(Activity activity) {
            this.activity = activity;
            prepare();
        }

        private synchronized void prepare() {
            for (String[] item : REGION_DBS) {
                String code = item[0];
                String fileName = item[1];
                try {
                    File f = copyAssetIfNeeded("databases/" + fileName, fileName);
                    SQLiteDatabase db = SQLiteDatabase.openDatabase(f.getAbsolutePath(), null, SQLiteDatabase.OPEN_READONLY);
                    dbs.put(code, db);
                    JSONObject r = readRegion(db, code, fileName);
                    regions.put(code, r);
                } catch (Exception e) {
                    lastError = "DB " + fileName + ": " + e.getMessage();
                }
            }
        }

        private File copyAssetIfNeeded(String assetPath, String fileName) throws Exception {
            File dir = new File(activity.getFilesDir(), "databases");
            if (!dir.exists()) dir.mkdirs();
            File out = new File(dir, fileName);
            if (!out.exists() || out.length() == 0) {
                try (InputStream in = activity.getAssets().open(assetPath);
                     FileOutputStream fos = new FileOutputStream(out)) {
                    byte[] buf = new byte[1024 * 64];
                    int n;
                    while ((n = in.read(buf)) != -1) fos.write(buf, 0, n);
                    fos.flush();
                }
            }
            return out;
        }

        private JSONObject readRegion(SQLiteDatabase db, String code, String dbName) throws Exception {
            JSONObject r = new JSONObject();
            Cursor c = db.rawQuery("SELECT name,min_lon,min_lat,max_lon,max_lat,width,height,crs FROM regions LIMIT 1", null);
            try {
                if (c.moveToFirst()) {
                    r.put("code", code);
                    r.put("name", c.getString(0));
                    r.put("min_lon", c.getDouble(1));
                    r.put("min_lat", c.getDouble(2));
                    r.put("max_lon", c.getDouble(3));
                    r.put("max_lat", c.getDouble(4));
                    r.put("width", c.getInt(5));
                    r.put("height", c.getInt(6));
                    r.put("crs", c.getString(7));
                    r.put("db", dbName);
                    JSONArray bounds = new JSONArray();
                    bounds.put(c.getDouble(1)); bounds.put(c.getDouble(2)); bounds.put(c.getDouble(3)); bounds.put(c.getDouble(4));
                    r.put("bounds", bounds);
                }
            } finally {
                c.close();
            }
            return r;
        }

        private boolean inside(JSONObject r, double lat, double lon) {
            return lon >= r.optDouble("min_lon") && lon <= r.optDouble("max_lon")
                    && lat >= r.optDouble("min_lat") && lat <= r.optDouble("max_lat");
        }

        private String regionCodeFor(double lat, double lon) {
            for (Map.Entry<String, JSONObject> e : regions.entrySet()) {
                if (inside(e.getValue(), lat, lon)) return e.getKey();
            }
            return null;
        }

        @JavascriptInterface
        public synchronized String analyze(double lat, double lon) {
            JSONObject out = new JSONObject();
            try {
                if (dbs.isEmpty()) prepare();

                String code = regionCodeFor(lat, lon);
                if (code == null) {
                    out.put("inside", false);
                    out.put("target", false);
                    out.put("score", 0);
                    out.put("decision", "Reject");
                    out.put("type", "Outside coverage");
                    out.put("reason", "النقطة خارج حدود قواعد V21 الثلاث؛ لا توجد نتيجة رادار ولا يتم توليد هدف وهمي.");
                    out.put("why_down", "Outside local database coverage");
                    out.put("missing", "Local V21 cell coverage");
                    out.put("lat", lat);
                    out.put("lon", lon);
                    out.put("source", "native_sqlite_only");
                    return out.toString();
                }

                SQLiteDatabase db = dbs.get(code);
                JSONObject region = regions.get(code);

                JSONObject pixel = nearestPixel(db, lat, lon);
                JSONObject target = nearestTargetObject(db, lat, lon, 1.1);

                if (pixel == null) {
                    out.put("inside", false);
                    out.put("target", false);
                    out.put("region", region);
                    out.put("region_code", code);
                    out.put("score", 0);
                    out.put("decision", "Reject");
                    out.put("type", "No local pixel");
                    out.put("reason", "النقطة داخل النطاق ولكن لا توجد خلية محلية قابلة للقراءة في pixel_review_quick_grid.");
                    out.put("missing", "pixel_review_quick_grid");
                    out.put("lat", lat);
                    out.put("lon", lon);
                    out.put("source", "native_sqlite_only");
                    return out.toString();
                }

                String rawDecision = target != null ? target.optString("decision", pixel.optString("decision", "HOLD")) : pixel.optString("decision", "HOLD");
                double score = target != null ? target.optDouble("final_score", pixel.optDouble("final_score")) : pixel.optDouble("final_score");
                String safeDecision = enforceFieldDecision(rawDecision, pixel, target, score);
                JSONObject indicators = indicators(pixel);

                out.put("inside", true);
                out.put("target", target != null);
                out.put("region", region);
                out.put("region_code", code);
                out.put("lat", lat);
                out.put("lon", lon);
                out.put("nearest_lat", pixel.optDouble("lat"));
                out.put("nearest_lon", pixel.optDouble("lon"));
                out.put("distance_km", pixel.optDouble("distance_km"));
                out.put("score", Math.round(score));
                out.put("raw_score", score);
                out.put("decision", safeDecision);
                out.put("raw_decision", rawDecision);
                out.put("row", pixel.optInt("row"));
                out.put("col", pixel.optInt("col"));
                out.put("grid_id", pixel.optInt("grid_id"));
                out.put("type", target != null ? "قراءة SQLite: أقرب هدف + أقرب بكسل محلي" : "قراءة SQLite: أقرب بكسل محلي");
                out.put("why_up", mergeReason(pixel.optString("why_up"), target == null ? "" : target.optString("why_up")));
                out.put("why_down", enforceReason(pixel, target, safeDecision));
                out.put("missing", mergeReason(pixel.optString("missing_data"), target == null ? "" : target.optString("missing_data")));
                out.put("cluster", target == null ? "-" : target.optInt("cluster_id"));
                out.put("target_id", target == null ? JSONObject.NULL : target.optInt("target_id"));
                out.put("target_rank", target == null ? JSONObject.NULL : target.optInt("rank"));
                out.put("indicators", indicators);
                out.put("vals", indicators);
                out.put("evidence_policy", "لا تأكيد ذهب ولا ترقية ميدانية إلا عند وجود GPZ/sample/assay/recovered_gold داخل البيانات.");
                out.put("source", "native_sqlite_only");
                return out.toString();
            } catch (Exception e) {
                lastError = e.getMessage();
                try {
                    out.put("inside", false);
                    out.put("score", 0);
                    out.put("decision", "Reject");
                    out.put("type", "Engine error");
                    out.put("reason", "تعذر قراءة SQLite المحلي: " + e.getMessage());
                    out.put("source", "native_sqlite_only");
                    return out.toString();
                } catch (Exception ignored) {
                    return "{\"inside\":false,\"score\":0,\"decision\":\"Reject\",\"type\":\"Engine error\",\"source\":\"native_sqlite_only\"}";
                }
            }
        }

        private JSONObject nearestPixel(SQLiteDatabase db, double lat, double lon) throws Exception {
            Cursor c = db.rawQuery(
                    "SELECT grid_id,source_pixel_id,row,col,lon,lat,final_score,decision,feox,ferric_redness,clay_oh_proxy,silica_quartz_proxy,gossan_proxy,dark_regolith,bare_ground,ndvi_inverse,moisture_inverse,swir_support,lineament_texture_proxy,wadi_texture_proxy,surface_regolith,vein_proxy,placer_eluvial_proxy,alteration_composite,structure_proxy,pattern_proxy,noise_risk,why_up,why_down,missing_data,reading_type " +
                            "FROM pixel_review_quick_grid ORDER BY ((lat-?)*(lat-?) + (lon-?)*(lon-?)) ASC LIMIT 1",
                    new String[]{s(lat), s(lat), s(lon), s(lon)}
            );
            try {
                if (!c.moveToFirst()) return null;
                JSONObject o = new JSONObject();
                String[] names = {"grid_id","source_pixel_id","row","col","lon","lat","final_score","decision","feox","ferric_redness","clay_oh_proxy","silica_quartz_proxy","gossan_proxy","dark_regolith","bare_ground","ndvi_inverse","moisture_inverse","swir_support","lineament_texture_proxy","wadi_texture_proxy","surface_regolith","vein_proxy","placer_eluvial_proxy","alteration_composite","structure_proxy","pattern_proxy","noise_risk","why_up","why_down","missing_data","reading_type"};
                for (int i = 0; i < names.length; i++) {
                    int type = c.getType(i);
                    if (type == Cursor.FIELD_TYPE_INTEGER) o.put(names[i], c.getInt(i));
                    else if (type == Cursor.FIELD_TYPE_FLOAT) o.put(names[i], c.getDouble(i));
                    else if (type == Cursor.FIELD_TYPE_NULL) o.put(names[i], JSONObject.NULL);
                    else o.put(names[i], c.getString(i));
                }
                o.put("distance_km", km(lat, lon, o.optDouble("lat"), o.optDouble("lon")));
                return o;
            } finally {
                c.close();
            }
        }

        private JSONObject nearestTargetObject(SQLiteDatabase db, double lat, double lon, double maxKm) throws Exception {
            Cursor c = db.rawQuery(
                    "SELECT target_id,rank,cluster_id,row,col,lon,lat,final_score,decision,why_up,why_down,missing_data,source " +
                            "FROM targets ORDER BY ((lat-?)*(lat-?) + (lon-?)*(lon-?)) ASC LIMIT 1",
                    new String[]{s(lat), s(lat), s(lon), s(lon)}
            );
            try {
                if (!c.moveToFirst()) return null;
                double tLat = c.getDouble(6);
                double tLon = c.getDouble(5);
                double d = km(lat, lon, tLat, tLon);
                if (d > maxKm) return null;
                JSONObject o = new JSONObject();
                String[] names = {"target_id","rank","cluster_id","row","col","lon","lat","final_score","decision","why_up","why_down","missing_data","source"};
                for (int i = 0; i < names.length; i++) {
                    int type = c.getType(i);
                    if (type == Cursor.FIELD_TYPE_INTEGER) o.put(names[i], c.getInt(i));
                    else if (type == Cursor.FIELD_TYPE_FLOAT) o.put(names[i], c.getDouble(i));
                    else if (type == Cursor.FIELD_TYPE_NULL) o.put(names[i], JSONObject.NULL);
                    else o.put(names[i], c.getString(i));
                }
                o.put("distance_km", d);
                return o;
            } finally {
                c.close();
            }
        }


        public synchronized String professionalAnalyze(double lat, double lon) {
            JSONObject out = new JSONObject();
            try {
                JSONObject base = new JSONObject(analyze(lat, lon));
                out = new JSONObject(base.toString());
                out.put("engine_name", "BOUH Gold Terrain Radar Pro");
                out.put("engine_ar", "رادار بوح الاحترافي لاستشعار مؤشرات الذهب");
                out.put("engine_role", "Candidate & Field-check Engine");
                out.put("professional_mode", true);
                out.put("simulation", false);
                out.put("random", false);
                out.put("primary_data_source", "original_local_sqlite_v21");
                out.put("map_policy", "Satellite and Hybrid base maps only; no heatmap/target overlay is required for decision.");
                out.put("satellite_policy", "Sentinel/Landsat/visual tiles are treated as relative proxy support unless calibrated reflectance and QA metadata are present.");
                out.put("proof_policy", "No تأكيد ذهب نهائي and no ترقية ميدانية without GPZ/sample/assay/recovered_gold evidence.");

                if (!base.optBoolean("inside", false)) {
                    out.put("professional_decision", "Outside coverage");
                    out.put("confidence", 0);
                    out.put("confidence_class", "NONE");
                    out.put("field_action", "تحريك الخريطة داخل تغطية قواعد BOUH V21 أو استخدام GPS داخل النطاق.");
                    out.put("local_ai_explanation", "النقطة خارج حدود قواعد البيانات المحلية؛ لا يتم توليد نتيجة وهمية ولا تستخدم AI لتخمين هدف.");
                    out.put("api_ai", new JSONObject(aiApiStatus()));
                    return out.toString();
                }

                JSONObject v = base.optJSONObject("indicators");
                if (v == null) v = base.optJSONObject("vals");
                if (v == null) v = new JSONObject();

                double structure = safe(v, "structure");
                double pattern = safe(v, "pattern");
                double alteration = safe(v, "alteration");
                double clay = safe(v, "clay");
                double silica = safe(v, "silica");
                double gossan = safe(v, "gossan");
                double feox = safe(v, "feox");
                double lineament = safe(v, "lineament");
                double wadi = safe(v, "wadi");
                double surface = safe(v, "surface");
                double vein = safe(v, "vein");
                double placer = safe(v, "placer");
                double noise = safe(v, "noise");
                double dbScore = base.optDouble("raw_score", base.optDouble("score", 0));
                double distanceKm = base.optDouble("distance_km", 99);

                boolean hasStructure = structure > 0 || lineament > 0 || wadi > 0;
                boolean hasPattern = pattern > 0 || vein > 0 || placer > 0;
                boolean hasAlteration = alteration > 0 || clay > 0 || silica > 0 || gossan > 0;
                boolean feoxOnly = feox > 0 && !hasStructure && !hasPattern && !hasAlteration;
                boolean nearCell = distanceKm <= 0.35;
                boolean hasTarget = base.optBoolean("target", false);

                double evidence = 0;
                evidence += clamp(structure, 0, 100) * 0.18;
                evidence += clamp(pattern, 0, 100) * 0.18;
                evidence += clamp(alteration, 0, 100) * 0.16;
                evidence += Math.max(clamp(clay, 0, 100), clamp(silica, 0, 100)) * 0.10;
                evidence += clamp(gossan, 0, 100) * 0.07;
                evidence += Math.max(clamp(lineament, 0, 100), clamp(wadi, 0, 100)) * 0.10;
                evidence += Math.max(Math.max(clamp(surface, 0, 100), clamp(vein, 0, 100)), clamp(placer, 0, 100)) * 0.11;
                evidence += Math.min(10, Math.max(0, dbScore / 10.0));
                evidence -= clamp(noise, 0, 100) * 0.12;
                if (nearCell) evidence += 5;
                if (hasTarget) evidence += 5;
                if (feoxOnly) evidence = Math.min(evidence, 44);

                double confidence = clamp(evidence, 0, 100);
                String confidenceClass = confidence >= 78 ? "HIGH" : confidence >= 58 ? "MEDIUM" : confidence >= 35 ? "LOW" : "VERY_LOW";

                String safeDecision = base.optString("decision", "Reject");
                if (feoxOnly) safeDecision = "HOLD";
                if (!hasStructure && !hasPattern && dbScore < 70) safeDecision = "Reject";
                if (safeDecision.toLowerCase(Locale.US).contains("confirmed") || (safeDecision.toLowerCase(Locale.US).contains("target") && safeDecision.toLowerCase(Locale.US).contains("-b"))) safeDecision = "HOLD";

                JSONObject matrix = new JSONObject();
                matrix.put("structure_group", hasStructure);
                matrix.put("pattern_group", hasPattern);
                matrix.put("alteration_group", hasAlteration);
                matrix.put("feox_only_guard", feoxOnly);
                matrix.put("nearest_cell_distance_km", distanceKm);
                matrix.put("near_cell", nearCell);
                matrix.put("nearest_target_available", hasTarget);
                matrix.put("noise_penalty", noise);

                String action;
                if ("Candidate".equals(safeDecision)) action = "مرشح للفحص الميداني: تحقق GPS/GPZ، تصوير، عينة إن أمكن، ثم لا ترقية إلا بدليل.";
                else if ("HOLD".equals(safeDecision) || "LOW HOLD".equals(safeDecision)) action = "انتظار/فحص ميداني منخفض المخاطر؛ لا يعتبر هدفاً مؤكداً.";
                else action = "رفض مبدئي أو خارج أولوية الفحص؛ راجع البيانات الناقصة والتغطية.";

                out.put("professional_decision", safeDecision);
                out.put("decision", safeDecision);
                out.put("confidence", Math.round(confidence));
                out.put("confidence_class", confidenceClass);
                out.put("evidence_matrix", matrix);
                out.put("indicator_precision", "weighted_deterministic_fusion_from_original_sqlite_indicators");
                out.put("field_action", action);
                out.put("local_ai_explanation", buildLocalAiExplanation(safeDecision, confidenceClass, hasStructure, hasPattern, hasAlteration, feoxOnly, nearCell, hasTarget));
                out.put("api_ai", new JSONObject(aiApiStatus()));
                return out.toString();
            } catch (Exception e) {
                lastError = e.getMessage();
                try {
                    out.put("inside", false);
                    out.put("decision", "Reject");
                    out.put("professional_decision", "Reject");
                    out.put("confidence", 0);
                    out.put("engine_name", "BOUH Gold Terrain Radar Pro");
                    out.put("reason", "Professional radar error: " + e.getMessage());
                    out.put("random", false);
                    out.put("simulation", false);
                    return out.toString();
                } catch (Exception ignored) {
                    return "{\"inside\":false,\"decision\":\"Reject\",\"professional_decision\":\"Reject\",\"confidence\":0,\"random\":false,\"simulation\":false}";
                }
            }
        }

        public synchronized String aiApiStatus() {
            JSONObject o = new JSONObject();
            try {
                o.put("ai_mode", "local_explainable_rules");
                o.put("external_ai_api_enabled", false);
                o.put("external_satellite_api_enabled", false);
                o.put("reason", "لا يتم استدعاء API خارجي بدون مفاتيح وإعداد صريح من المستخدم. القرار الحالي يعتمد على SQLite الأصلي فقط.");
                o.put("supported_optional_connectors", new JSONArray()
                        .put("satellite_tile_api_adapter")
                        .put("field_assay_upload_adapter")
                        .put("gpz_sample_evidence_adapter")
                        .put("ai_explanation_api_adapter"));
                o.put("decision_override_by_api", false);
                o.put("offline_safe", true);
                return o.toString();
            } catch (Exception e) {
                return "{\"ai_mode\":\"local_explainable_rules\",\"external_ai_api_enabled\":false,\"offline_safe\":true}";
            }
        }

        private String buildLocalAiExplanation(String decision, String confidence, boolean hasStructure, boolean hasPattern, boolean hasAlteration, boolean feoxOnly, boolean nearCell, boolean hasTarget) {
            StringBuilder sb = new StringBuilder();
            sb.append("تحليل ذكي محلي قابل للتفسير: ");
            sb.append("القرار ").append(decision).append(" بثقة ").append(confidence).append(". ");
            sb.append(hasStructure ? "يوجد دعم بنيوي/خطيات. " : "الدعم البنيوي ضعيف أو غير موجود. ");
            sb.append(hasPattern ? "يوجد نمط مكاني داعم. " : "النمط المكاني غير كافٍ. ");
            sb.append(hasAlteration ? "توجد مؤشرات تحوير داعمة. " : "مؤشرات التحوير غير كافية. ");
            if (feoxOnly) sb.append("تحذير: FeOx وحده لا يرفع الهدف ولا يثبت الذهب. ");
            sb.append(nearCell ? "أقرب خلية مناسبة مكانياً. " : "المسافة لأقرب خلية تقلل الثقة. ");
            sb.append(hasTarget ? "يوجد هدف محلي قريب في قاعدة البيانات. " : "لا يوجد هدف قريب كافٍ ضمن حد البحث. ");
            sb.append("لا يوجد تأكيد ذهب دون GPZ/sample/assay/recovered_gold.");
            return sb.toString();
        }

        private double safe(JSONObject o, String key) {
            if (o == null) return 0;
            double v = o.optDouble(key, 0);
            if (Double.isNaN(v) || Double.isInfinite(v)) return 0;
            return v;
        }

        private double clamp(double x, double lo, double hi) {
            return Math.max(lo, Math.min(hi, x));
        }



        public synchronized String professionalAnalyzeV2(double lat, double lon) {
            JSONObject out = new JSONObject();
            try {
                JSONObject pro = new JSONObject(professionalAnalyze(lat, lon));
                out = new JSONObject(pro.toString());
                JSONObject sat = new JSONObject(satelliteIntelligence(lat, lon));
                JSONObject ai = new JSONObject(aiAssistant("قدّم تقييم رادار احترافي لهذه النقطة مع خطة فحص ميداني.", lat, lon));

                JSONObject precision = new JSONObject();
                JSONObject ind = pro.optJSONObject("indicators");
                if (ind == null) ind = pro.optJSONObject("vals");
                if (ind == null) ind = new JSONObject();

                double structure = safe(ind, "structure");
                double pattern = safe(ind, "pattern");
                double alteration = safe(ind, "alteration");
                double feox = safe(ind, "feox");
                double clay = safe(ind, "clay");
                double silica = safe(ind, "silica");
                double gossan = safe(ind, "gossan");
                double noise = safe(ind, "noise");
                double dbScore = pro.optDouble("raw_score", pro.optDouble("score", 0));

                double geologicalIndex = clamp(
                        dbScore * 0.34 +
                        Math.max(structure, 0) * 0.17 +
                        Math.max(pattern, 0) * 0.16 +
                        Math.max(alteration, 0) * 0.13 +
                        Math.max(Math.max(clay, silica), gossan) * 0.10 -
                        Math.max(noise, 0) * 0.10,
                        0, 100
                );

                boolean feoxOnly = feox > 0 && structure <= 0 && pattern <= 0 && alteration <= 0 && clay <= 0 && silica <= 0 && gossan <= 0;
                if (feoxOnly) geologicalIndex = Math.min(geologicalIndex, 44);

                precision.put("geological_index", Math.round(geologicalIndex));
                precision.put("db_score_weight", "34%");
                precision.put("structure_weight", "17%");
                precision.put("pattern_weight", "16%");
                precision.put("alteration_weight", "13%");
                precision.put("clay_silica_gossan_weight", "10%");
                precision.put("noise_penalty", "10%");
                precision.put("feox_only_cap", feoxOnly ? "active_cap_44" : "not_active");
                precision.put("precision_basis", "original SQLite V21 indicators + deterministic geological fusion");
                precision.put("not_a_detector", "الهاتف لا يتحول إلى جهاز كشف معدن؛ هذا محرك ترشيح جيولوجي وفحص ميداني.");

                out.put("engine_name", "BOUH Gold Terrain Radar Pro AI");
                out.put("engine_ar", "رادار بوح الاحترافي الذكي لاستشعار مؤشرات الذهب");
                out.put("pro_ai_version", "25.1-local-ai-adapter");
                out.put("precision_model", precision);
                out.put("satellite_intelligence", sat);
                out.put("ai_assistant", ai);
                out.put("api_policy", new JSONObject(aiApiStatus()));
                out.put("field_grade", geologicalIndex >= 78 ? "A: فحص ميداني عالي الأولوية" : geologicalIndex >= 58 ? "B: فحص ميداني متوسط" : geologicalIndex >= 35 ? "C: تحقق منخفض" : "D: رفض/أولوية منخفضة");
                out.put("final_guardrail", "لا Gold Confirmed ولا Target-B بدون GPZ/sample/assay/recovered_gold.");
                out.put("random", false);
                out.put("simulation", false);
                return out.toString();
            } catch (Exception e) {
                lastError = e.getMessage();
                try {
                    out.put("engine_name", "BOUH Gold Terrain Radar Pro AI");
                    out.put("decision", "Reject");
                    out.put("confidence", 0);
                    out.put("error", e.getMessage());
                    out.put("random", false);
                    out.put("simulation", false);
                    return out.toString();
                } catch (Exception ignored) {
                    return "{\"decision\":\"Reject\",\"confidence\":0,\"random\":false,\"simulation\":false}";
                }
            }
        }

        public synchronized String satelliteIntelligence(double lat, double lon) {
            JSONObject out = new JSONObject();
            try {
                out.put("module", "Satellite/API Intelligence Adapter");
                out.put("lat", lat);
                out.put("lon", lon);
                out.put("online_api_enabled", false);
                out.put("offline_first", true);
                out.put("base_maps", new JSONArray().put("Satellite").put("Hybrid Map"));
                out.put("supported_satellite_sources_optional", new JSONArray()
                        .put("Sentinel-2 MSI")
                        .put("Landsat 8/9 OLI")
                        .put("ASTER/SWIR optional")
                        .put("SRTM/DEM optional")
                        .put("Esri World Imagery tiles")
                        .put("local MBTiles cache"));
                out.put("calibration_policy", "أي بيانات Sentinel/Landsat visual/uint8 تعتبر relative proxy وليست calibrated reflectance إلا عند توفر metadata/QA صريح.");
                String code = regionCodeFor(lat, lon);
                if (code == null) {
                    out.put("coverage", "Outside coverage");
                    out.put("region_code", JSONObject.NULL);
                    out.put("metadata", new JSONArray());
                    out.put("layer_registry", new JSONArray());
                    return out.toString();
                }
                SQLiteDatabase db = dbs.get(code);
                out.put("coverage", "Inside local V21 coverage");
                out.put("region_code", code);
                out.put("metadata", readTablePreview(db, "metadata", 10));
                out.put("layer_registry", readTablePreview(db, "layer_registry", 25));
                out.put("decision_rule_count", tableCount(db, "decision_rules"));
                out.put("target_count", tableCount(db, "targets"));
                out.put("cluster_count", tableCount(db, "clusters"));
                out.put("quick_grid_count", tableCount(db, "pixel_review_quick_grid"));
                return out.toString();
            } catch (Exception e) {
                lastError = e.getMessage();
                try {
                    out.put("module", "Satellite/API Intelligence Adapter");
                    out.put("error", e.getMessage());
                    out.put("online_api_enabled", false);
                    out.put("offline_first", true);
                    return out.toString();
                } catch (Exception ignored) {
                    return "{\"module\":\"Satellite/API Intelligence Adapter\",\"online_api_enabled\":false,\"offline_first\":true}";
                }
            }
        }

        public synchronized String aiAssistant(String question, double lat, double lon) {
            JSONObject out = new JSONObject();
            try {
                String q = question == null ? "" : question.trim();
                JSONObject pro = new JSONObject(professionalAnalyze(lat, lon));
                String decision = pro.optString("professional_decision", pro.optString("decision", "Reject"));
                int confidence = pro.optInt("confidence", 0);
                String cclass = pro.optString("confidence_class", "NONE");
                boolean inside = pro.optBoolean("inside", false);
                String region = pro.optString("region_code", "-");
                double score = pro.optDouble("raw_score", pro.optDouble("score", 0));
                String whyUp = pro.optString("why_up", "-");
                String whyDown = pro.optString("why_down", "-");
                String missing = pro.optString("missing", "-");

                JSONArray steps = new JSONArray();
                if (!inside) {
                    steps.put("النقطة خارج تغطية قواعد BOUH V21؛ لا يمكن إصدار ترشيح حقيقي.");
                    steps.put("انقل المؤشر داخل أحد نطاقات NORTH/CENTER/SOUTH أو استخدم GPS داخل التغطية.");
                } else {
                    steps.put("ثبّت الموقع بالـ GPS وسجل الإحداثيات والصورة الميدانية.");
                    steps.put("راجع البنية: lineaments / wadi texture / structure proxy.");
                    steps.put("راجع النمط: pattern / vein / placer-eluvial proxies.");
                    steps.put("راجع التحوير: clay/SWIR, silica/quartz, gossan, FeOx.");
                    steps.put("إذا بقي القرار Candidate أو HOLD اجمع عينة فقط عند وجود دليل ميداني مناسب.");
                    steps.put("لا ترقّي النتيجة إلى Gold Confirmed دون assay أو recovered gold.");
                }

                StringBuilder answer = new StringBuilder();
                answer.append("مساعد بوح AI المحلي: ");
                if (q.length() > 0) answer.append("سؤالك: ").append(q).append(". ");
                answer.append("القرار الحالي: ").append(decision).append("، الثقة: ").append(confidence).append("/100 ").append(cclass).append(". ");
                answer.append("النطاق: ").append(region).append("، score: ").append(Math.round(score)).append(". ");
                answer.append("الدعم الإيجابي: ").append(whyUp.length() == 0 ? "-" : whyUp).append(". ");
                answer.append("عوامل التخفيض: ").append(whyDown.length() == 0 ? "-" : whyDown).append(". ");
                answer.append("البيانات الناقصة: ").append(missing.length() == 0 ? "-" : missing).append(". ");
                answer.append("هذا مساعد تفسير وتحليل، وليس إثبات ذهب.");

                out.put("assistant_name", "BOUH AI Field Assistant");
                out.put("assistant_ar", "مساعد بوح الذكي للفحص الميداني");
                out.put("mode", "local_explainable_ai");
                out.put("external_api_used", false);
                out.put("question", q);
                out.put("answer", answer.toString());
                out.put("recommended_field_steps", steps);
                out.put("decision", decision);
                out.put("confidence", confidence);
                out.put("region_code", region);
                out.put("guardrails", new JSONArray()
                        .put("لا Gold Confirmed بدون recovered_gold/assay.")
                        .put("لا Target-B بدون GPZ/sample/assay.")
                        .put("FeOx-only لا يصنع هدفاً قوياً.")
                        .put("Klemm/KCL مرجع فقط.")
                        .put("القرار من SQLite المحلي وليس من تخمين AI."));
                return out.toString();
            } catch (Exception e) {
                lastError = e.getMessage();
                try {
                    out.put("assistant_name", "BOUH AI Field Assistant");
                    out.put("mode", "local_explainable_ai");
                    out.put("external_api_used", false);
                    out.put("answer", "تعذر تحليل السؤال: " + e.getMessage());
                    out.put("decision", "Reject");
                    return out.toString();
                } catch (Exception ignored) {
                    return "{\"assistant_name\":\"BOUH AI Field Assistant\",\"external_api_used\":false,\"decision\":\"Reject\"}";
                }
            }
        }

        private JSONArray readTablePreview(SQLiteDatabase db, String table, int limit) throws Exception {
            JSONArray arr = new JSONArray();
            Cursor c = db.rawQuery("SELECT * FROM " + table + " LIMIT " + Math.max(1, Math.min(50, limit)), null);
            try {
                String[] cols = c.getColumnNames();
                while (c.moveToNext()) {
                    JSONObject row = new JSONObject();
                    for (int i = 0; i < cols.length; i++) {
                        int type = c.getType(i);
                        if (type == Cursor.FIELD_TYPE_INTEGER) row.put(cols[i], c.getLong(i));
                        else if (type == Cursor.FIELD_TYPE_FLOAT) row.put(cols[i], c.getDouble(i));
                        else if (type == Cursor.FIELD_TYPE_NULL) row.put(cols[i], JSONObject.NULL);
                        else row.put(cols[i], c.getString(i));
                    }
                    arr.put(row);
                }
            } finally {
                c.close();
            }
            return arr;
        }

        private long tableCount(SQLiteDatabase db, String table) {
            Cursor c = null;
            try {
                c = db.rawQuery("SELECT COUNT(*) FROM " + table, null);
                if (c.moveToFirst()) return c.getLong(0);
            } catch (Exception ignored) {
            } finally {
                if (c != null) c.close();
            }
            return 0;
        }


        public synchronized String nearestTarget(double lat, double lon, double maxKm) {
            JSONObject empty = new JSONObject();
            try {
                String code = regionCodeFor(lat, lon);
                if (code == null) {
                    empty.put("found", false);
                    return empty.toString();
                }
                JSONObject target = nearestTargetObject(dbs.get(code), lat, lon, maxKm);
                if (target == null) {
                    empty.put("found", false);
                    return empty.toString();
                }
                target.put("found", true);
                target.put("region_code", code);
                return target.toString();
            } catch (Exception e) {
                lastError = e.getMessage();
                try {
                    empty.put("found", false);
                    empty.put("error", e.getMessage());
                    return empty.toString();
                } catch (Exception ignored) {
                    return "{\"found\":false}";
                }
            }
        }

        private JSONObject indicators(JSONObject p) throws Exception {
            JSONObject v = new JSONObject();
            v.put("structure", scale(p.optDouble("structure_proxy")));
            v.put("pattern", scale(p.optDouble("pattern_proxy")));
            v.put("alteration", scale(p.optDouble("alteration_composite")));
            v.put("noise", scale(p.optDouble("noise_risk")));
            v.put("feox", scale(p.optDouble("feox")));
            v.put("ferric_redness", scale(p.optDouble("ferric_redness")));
            v.put("clay", scale(p.optDouble("clay_oh_proxy")));
            v.put("silica", scale(p.optDouble("silica_quartz_proxy")));
            v.put("gossan", scale(p.optDouble("gossan_proxy")));
            v.put("dark_regolith", scale(p.optDouble("dark_regolith")));
            v.put("bare_ground", scale(p.optDouble("bare_ground")));
            v.put("ndvi_inverse", scale(p.optDouble("ndvi_inverse")));
            v.put("moisture_inverse", scale(p.optDouble("moisture_inverse")));
            v.put("swir_support", scale(p.optDouble("swir_support")));
            v.put("lineament", scale(p.optDouble("lineament_texture_proxy")));
            v.put("wadi", scale(p.optDouble("wadi_texture_proxy")));
            v.put("surface", scale(p.optDouble("surface_regolith")));
            v.put("vein", scale(p.optDouble("vein_proxy")));
            v.put("placer", scale(p.optDouble("placer_eluvial_proxy")));
            return v;
        }

        private int scale(double x) {
            if (Double.isNaN(x) || Double.isInfinite(x)) return 0;
            return (int) Math.round(x > 100 ? x / 10.0 : x);
        }

        private String enforceFieldDecision(String raw, JSONObject pixel, JSONObject target, double score) {
            String d = raw == null ? "" : raw.trim();
            boolean hasFieldEvidence = containsFieldEvidence(pixel.optString("missing_data")) || (target != null && containsFieldEvidence(target.optString("missing_data")));
            boolean feoxOnly = pixel.optInt("feox") > 0
                    && pixel.optInt("clay_oh_proxy") == 0
                    && pixel.optInt("silica_quartz_proxy") == 0
                    && pixel.optInt("gossan_proxy") == 0
                    && pixel.optInt("lineament_texture_proxy") == 0
                    && pixel.optInt("wadi_texture_proxy") == 0
                    && pixel.optInt("vein_proxy") == 0
                    && pixel.optInt("placer_eluvial_proxy") == 0
                    && pixel.optInt("structure_proxy") == 0
                    && pixel.optInt("pattern_proxy") == 0;

            String lower = d.toLowerCase(Locale.US);
            if ((lower.contains("field-upgrade") || d.contains("ذهب") || lower.contains("confirmed")) && !hasFieldEvidence) return "HOLD";
            if (feoxOnly) return "HOLD";
            if (lower.contains("reject")) return "Reject";
            if (lower.contains("hold")) return "HOLD";
            if (lower.contains("gpz") && hasFieldEvidence) return "Candidate";
            if (score >= 70) return "Candidate";
            if (score >= 45) return "HOLD";
            return "Reject";
        }

        private boolean containsFieldEvidence(String text) {
            if (text == null) return false;
            String t = text.toLowerCase(Locale.US);
            if (t.contains("missing") || t.contains("no field") || t.contains("no gold") || t.contains("no field upgrade")) return false;
            return t.contains("gpz") || t.contains("sample") || t.contains("assay") || t.contains("geochem") || t.contains("field evidence") || t.contains("recovered_gold") || t.contains("recovered gold");
        }

        private String enforceReason(JSONObject pixel, JSONObject target, String decision) {
            String base = mergeReason(pixel.optString("why_down"), target == null ? "" : target.optString("why_down"));
            StringBuilder sb = new StringBuilder();
            if (base != null && base.trim().length() > 0) sb.append(base.trim());
            if (sb.length() > 0) sb.append(" | ");
            sb.append("Decision Engine uses only local SQLite V21 DB. No confirmed gold and no field upgrade without GPZ/sample/assay/geochem. Klemm/KCL is reference only. FeOx-only is not a strong target.");
            if ("HOLD".equals(decision)) sb.append(" Field check required before any upgrade.");
            return sb.toString();
        }

        private String mergeReason(String a, String b) {
            String aa = a == null ? "" : a.trim();
            String bb = b == null ? "" : b.trim();
            if (aa.length() == 0) return bb;
            if (bb.length() == 0 || aa.contains(bb)) return aa;
            return aa + " | " + bb;
        }

        public synchronized String diagnostics(MapServer mapServer) {
            JSONObject out = new JSONObject();
            try {
                out.put("app", "BOUH Terrain Radar V25.1");
                out.put("engine", "native_sqlite_only");
                out.put("random", false);
                out.put("offline", true);
                out.put("last_error", lastError == null ? "" : lastError);
                JSONArray dbArr = new JSONArray();
                int totalTargets = 0;
                int totalCells = 0;
                for (String[] item : REGION_DBS) {
                    String code = item[0];
                    String fileName = item[1];
                    JSONObject d = new JSONObject();
                    d.put("region_code", code);
                    d.put("file", fileName);
                    d.put("open", dbs.containsKey(code));
                    d.put("region", regions.containsKey(code) ? regions.get(code) : JSONObject.NULL);
                    File f = new File(new File(activity.getFilesDir(), "databases"), fileName);
                    d.put("bytes", f.exists() ? f.length() : 0);
                    d.put("sha256_16", f.exists() ? sha256Prefix(f) : "");
                    SQLiteDatabase db = dbs.get(code);
                    if (db != null) {
                        int targets = count(db, "targets");
                        int cells = count(db, "pixel_review_quick_grid");
                        d.put("targets", targets);
                        d.put("cells", cells);
                        d.put("clusters", count(db, "clusters"));
                        d.put("quick_grid", count(db, "scores_quick_grid"));
                        d.put("layers", count(db, "layer_registry"));
                        totalTargets += targets;
                        totalCells += cells;
                    }
                    dbArr.put(d);
                }
                out.put("databases", dbArr);
                out.put("target_count", totalTargets);
                out.put("cell_count", totalCells);

                JSONArray maps = new JSONArray();
                String[] mapFiles = {"v21_north_heatmap.mbtiles", "v21_center_heatmap.mbtiles", "v21_south_heatmap.mbtiles"};
                for (String mf : mapFiles) {
                    JSONObject m = new JSONObject();
                    m.put("file", mf);
                    try {
                        InputStream in = activity.getAssets().open("maps/" + mf);
                        int available = in.available();
                        in.close();
                        m.put("asset", true);
                        m.put("asset_available_bytes_hint", available);
                    } catch (Exception e) {
                        m.put("asset", false);
                    }
                    maps.put(m);
                }
                out.put("maps", maps);
                if (mapServer != null) out.put("map_server", new JSONObject(mapServer.statusJson()));
                return out.toString();
            } catch (Exception e) {
                lastError = e.getMessage();
                return "{\"app\":\"BOUH Terrain Radar V25.1\",\"engine\":\"native_sqlite_only\",\"last_error\":\"" + escape(e.getMessage()) + "\"}";
            }
        }

        private int count(SQLiteDatabase db, String table) {
            Cursor c = null;
            try {
                c = db.rawQuery("SELECT COUNT(*) FROM " + table, null);
                return c.moveToFirst() ? c.getInt(0) : 0;
            } catch (Exception e) {
                return -1;
            } finally {
                if (c != null) c.close();
            }
        }

        private String sha256Prefix(File f) {
            try (InputStream in = new java.io.FileInputStream(f)) {
                MessageDigest digest = MessageDigest.getInstance("SHA-256");
                byte[] buf = new byte[1024 * 64];
                int n;
                while ((n = in.read(buf)) != -1) digest.update(buf, 0, n);
                byte[] hash = digest.digest();
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < Math.min(8, hash.length); i++) sb.append(String.format(Locale.US, "%02x", hash[i]));
                return sb.toString();
            } catch (Exception e) {
                return "";
            }
        }

        private double km(double lat1, double lon1, double lat2, double lon2) {
            double r = 6371.0088;
            double p1 = Math.toRadians(lat1);
            double p2 = Math.toRadians(lat2);
            double dp = Math.toRadians(lat2 - lat1);
            double dl = Math.toRadians(lon2 - lon1);
            double a = Math.sin(dp / 2) * Math.sin(dp / 2) + Math.cos(p1) * Math.cos(p2) * Math.sin(dl / 2) * Math.sin(dl / 2);
            return r * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        }

        private String s(double x) {
            return String.format(Locale.US, "%.12f", x);
        }

        private String escape(String x) {
            return x == null ? "" : x.replace("\\", "\\\\").replace("\"", "\\\"");
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_LOCATION) {
            boolean ok = false;
            for (int r : grantResults) {
                if (r == PackageManager.PERMISSION_GRANTED) { ok = true; break; }
            }
            if (geoCallback != null && geoOrigin != null) geoCallback.invoke(geoOrigin, ok, false);
            if (!ok) Toast.makeText(this, "GPS مرفوض. فعّل إذن الموقع من إعدادات التطبيق.", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onDestroy() {
        if (mapServer != null) mapServer.stop();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
