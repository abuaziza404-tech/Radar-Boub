# تقرير بناء رادار استشعار الذهب + مساعد AI

التاريخ: 2026-05-31 08:56 UTC

## الهدف
تحويل نسخة بوح التضاريس إلى نظام رادار احترافي ذكي يعتمد على البيانات الأصلية المرفوعة داخل التطبيق:
- قواعد SQLite المحلية V21.
- طبقات الخرائط الأساسية فقط: Satellite + Hybrid Map.
- نظام AI محلي قابل للتفسير.
- محولات API اختيارية آمنة بدون مفاتيح مدمجة.

## ما تم إضافته داخل AndroidBridge
- `professionalRadarAnalyzeV2(lat, lon)`
- `aiAssistant(question, lat, lon)`
- `satelliteIntelligence(lat, lon)`

## ما تم إضافته داخل RadarEngine
- `professionalAnalyzeV2`
- `satelliteIntelligence`
- `aiAssistant`
- `readTablePreview`
- `tableCount`

## مصادر القرار
الرادار لا يعتمد على تخمين ولا عشوائية. مصادر القرار:
- `BOUH_V21_NORTH_MOBILE.db`
- `BOUH_V21_CENTER_MOBILE.db`
- `BOUH_V21_SOUTH_MOBILE.db`
- `pixel_review_quick_grid`
- `targets`
- `clusters`
- `metadata`
- `layer_registry`
- `decision_rules`

## نموذج الدقة
تمت إضافة نموذج دمج جيولوجي حتمي:
- DB score: 34%
- Structure: 17%
- Pattern: 16%
- Alteration: 13%
- Clay/Silica/Gossan: 10%
- Noise penalty: 10%
- FeOx-only cap: لا يتجاوز أولوية قوية

## مساعد AI
المساعد الحالي يعمل محلياً:
- يفسر القرار.
- يشرح أسباب الرفع والتخفيض.
- يقترح خطوات فحص ميداني.
- لا يغيّر قرار SQLite.
- لا يثبت الذهب.
- لا يستخدم API خارجي افتراضياً.

## API والأنظمة الحديثة
تم تجهيز محول API كهيكل آمن يدعم لاحقاً:
- Sentinel-2 MSI
- Landsat 8/9 OLI
- ASTER/SWIR optional
- SRTM/DEM optional
- Esri World Imagery tiles
- GPZ/sample/assay evidence adapter
- AI explanation API adapter

لا توجد مفاتيح API مدمجة داخل التطبيق. أي API خارجي يجب تفعيله صراحةً لاحقاً، ولا يسمح له بتأكيد الذهب دون دليل ميداني.

## القيود الحاكمة
- لا Gold Confirmed.
- لا Target-B.
- لا FeOx-only كهدف قوي.
- Klemm/KCL مرجع فقط.
- Sentinel/Landsat visual/uint8 = relative proxy وليس calibrated reflectance.
- الهاتف لا يتحول إلى جهاز كشف معدن؛ النظام Candidate & Field-check Engine.

## QA
- Math.random = 0
- SQLite integrity_check = ok لكل قواعد V21
- targets = 600
- clusters = 416
- quick-grid cells = 14900
- ZIP أقل من 25MB
