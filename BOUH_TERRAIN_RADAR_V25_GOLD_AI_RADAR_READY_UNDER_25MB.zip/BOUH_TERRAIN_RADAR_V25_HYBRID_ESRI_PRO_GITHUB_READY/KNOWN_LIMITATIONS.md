# KNOWN_LIMITATIONS

## حدود الإصدار الحالي

1. لم يتم بناء APK داخل بيئة ChatGPT الحالية بسبب غياب Android SDK و Gradle المحلي.
2. الحزمة ملتزمة بسقف 25MB، لذلك تم حذف طبقات heatmap الإضافية من التسليم الحالي.
3. الخرائط الظاهرة مقتصرة على Satellite و Hybrid Map حسب طلب المستخدم.
4. API/AI الخارجي غير مفعل افتراضياً للحفاظ على التشغيل الأوفلاين وعدم تغيير قرار SQLite.
5. الرادار يعمل كـ Candidate & Field-check Engine ولا يثبت الذهب نهائياً.
6. لا يوجد Gold Confirmed أو Target-B إلا بدليل ميداني مثل GPZ/sample/assay/recovered_gold.
7. دقة المعاينة القريبة تعتمد على دقة البلاطات المتوفرة.


# GitHub Build Notes

Date: 2026-05-31 06:51:37 UTC

- This sandbox cannot produce APK because Android SDK/Gradle are unavailable locally.
- GitHub Actions should build using `.github/workflows/build-apk.yml`.
- The workflow now enforces `app-debug.apk` <= 25MB.
- The application remains a geological candidate/field-check engine, not a phone-based physical metal detector.


## حدود رادار الذهب + AI
- لا يحوّل الهاتف إلى جهاز كشف ذهب مباشر.
- AI المحلي يشرح ويقترح ولا يثبت الذهب.
- API الخارجي غير مفعل افتراضياً ولا توجد مفاتيح مدمجة.
- مصادر Sentinel/Landsat/Esri تعامل كدعم بصري/نسبي ما لم تتوفر بيانات calibrated reflectance و QA.
- القرار النهائي يعتمد على SQLite المحلي وقواعد بوح الجيولوجية.
