# GITHUB_ACTIONS_SETUP_GRADLE_FIX_REPORT

## المشكلة التي ظهرت في الصورة

فشل البناء في خطوة:

```text
Set up Gradle
```

قبل الوصول إلى خطوة:

```text
Build APK
```

لذلك الخطأ لم يكن من Java أو AndroidManifest أو WebView، بل من GitHub Action:

```yaml
uses: gradle/actions/setup-gradle@v4
```

## الإصلاح المنفذ

تم حذف خطوة `gradle/actions/setup-gradle@v4` بالكامل من workflow.

السبب: المشروع يحتوي launcher `./gradlew` مخصص، وهذا launcher قادر على:
1. استخدام Gradle من PATH إذا كان موجوداً.
2. تشغيل wrapper jar إذا كان صالحاً.
3. تنزيل Gradle 8.7 مباشرة من `services.gradle.org` إذا لم يكن Gradle مثبتاً.

وبالتالي لم تعد هناك حاجة إلى action خارجي لتجهيز Gradle.

## workflow الجديد

الترتيب الجديد:

```text
Checkout repository
Set up JDK 17
Set up Android SDK
Install Android SDK packages
Show build environment
chmod +x ./gradlew
./gradlew assembleDebug --no-daemon --stacktrace
Verify APK under 25MB
Upload APK artifact
```

## شرط الحجم

لا يزال شرط APK أقل من 25MB مفعلاً داخل GitHub Actions:

```bash
BYTES="$(stat -c%s "$APK")"
MAX=$((25 * 1024 * 1024))
if [ "$BYTES" -gt "$MAX" ]; then
  echo "APK exceeds 25MB limit"
  exit 1
fi
```

## النتيجة المتوقعة

بعد رفع هذه الحزمة إلى GitHub وتشغيل Actions، يجب أن يتجاوز البناء خطوة Set up Gradle ويبدأ فعلياً في:

```text
Build debug APK
```

إذا ظهر خطأ جديد، سيكون غالباً من Gradle/Android plugin/Java وليس من setup-gradle.
